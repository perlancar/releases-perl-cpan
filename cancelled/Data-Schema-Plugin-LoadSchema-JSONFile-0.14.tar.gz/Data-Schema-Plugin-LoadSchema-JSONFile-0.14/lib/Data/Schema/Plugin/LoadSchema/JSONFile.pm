package Data::Schema::Plugin::LoadSchema::JSONFile;
our $VERSION = '0.14';
# ABSTRACT: Plugin to load schemas from JSON files

use Any::Moose;
use File::Slurp;
use Log::Any qw($log);
use JSON;

extends 'Data::Schema::Plugin::LoadSchema::Base';


sub get_it {
    my ($self, $name) = @_;
    my $path;
    my $found;

    my $sp = $self->main->config->schema_search_path;
    for my $dir (ref($sp) eq 'ARRAY' ? @$sp : $sp) {
        my $path0 = "$dir/$name";
        while (1) {
            $path = $path0;
            (-f $path) and do { $found++; last };
            for my $ext (qw(json jsn)) {
                $path = "$path0.$ext";
                (-f $path) and do { $found++; last };
            }
            last;
        }
        last if $found;
    }

    if ($found) {
	$log->tracef("Loading JSON file %s ...", $path);
        my $content = read_file($path);
	($content) = $content =~ /(.*)/s; # untaint
	return from_json($content);
    }
    return;
}

__PACKAGE__->meta->make_immutable;
no Any::Moose;
1;

__END__
=pod

=head1 NAME

Data::Schema::Plugin::LoadSchema::JSONFile - Plugin to load schemas from JSON files

=head1 VERSION

version 0.14

=head1 SYNOPSIS


    # in schemadir/even_int.json
    ["int", {"divisible_by":2}]

    # in your code
    use Data::Schema -plugins => ['LoadSchema::JSONFile'];
    my $ds = Data::Schema->new;
    $ds->config->schema_search_path(["schemadir"]);

    my $res;
    $res = $ds->validate(2, 'even_int'); # success
    $res = $ds->validate(3, 'even_int'); # fails

=head1 METHODS


=head2 get_it($name)


Return schema loaded from JSON file, or C<undef> if not found. List of
directories to search for is specified in Data::Schema's
C<schema_search_path> config variable. "$name", "$name.{json,jsn}"
files will be searched for.

=head1 AUTHOR

  Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2010 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

