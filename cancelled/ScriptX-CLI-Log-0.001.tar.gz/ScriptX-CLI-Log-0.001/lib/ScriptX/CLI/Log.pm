package ScriptX::CLI::Log;

use parent 'ScriptX::Base';
use Log::ger::App;

sub meta {
    return {
        summary => 'Show logs for CLI scripts',
        description => <<'_',

This plugin basically just loads <pm:Log::ger::App>.

_
    };
}

1;
# ABSTRACT: Show logs for CLI scripts

__END__

=pod

=encoding UTF-8

=head1 NAME

ScriptX::CLI::Log - Show logs for CLI scripts

=head1 VERSION

This document describes version 0.001 of ScriptX::CLI::Log (from Perl distribution ScriptX-CLI-Log), released on 2020-04-16.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/ScriptX-CLI-Log>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-ScriptX-CLI-Log>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=ScriptX-CLI-Log>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2020 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
