package Rias::Object::Metadata;

use 5.010;
use strict;
use warnings;

our $VERSION = '0.04'; # VERSION

sub new {
    my ($class, $meta) = @_;
    $meta //= {};
    my $obj = \$meta;
    bless $obj, $class;
}

sub v {
    my $self = shift;
    ${$self}->{v} // 1.0;
}

sub type {
    die "BUG: type() must be subclassed";
}

sub as_struct {
    my $self = shift;
    ${$self};
}

1;
# ABSTRACT: Base class for Rias::Object metadata classes

__END__
=pod

=head1 NAME

Rias::Object::Metadata - Base class for Rias::Object metadata classes

=head1 VERSION

version 0.04

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2012 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

