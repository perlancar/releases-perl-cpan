package Rias::Object::variable;

use 5.010;
use strict;
use warnings;

our $VERSION = '0.04'; # VERSION

use parent qw(Rias::Object::Metadata);

sub type { "variable" }

1;
# Represent variable metadata

__END__
=pod

=head1 NAME

Rias::Object::variable

=head1 VERSION

version 0.04

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2012 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

