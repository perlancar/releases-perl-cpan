package Log::ger::Manual;

our $DATE = '2019-10-29'; # DATE
our $VERSION = '0.028.002'; # VERSION

1;
# ABSTRACT: Manual for Log::ger

__END__

=pod

=encoding UTF-8

=head1 NAME

Log::ger::Manual - Manual for Log::ger

=head1 VERSION

version 0.028.002

=head1 DESCRIPTION

This distribution contains the following documentation pages:

=over

=item * L<Log::ger::Manual::FAQ>

=item * L<Log::ger::Manual::ForLog4perl>

=item * L<Log::ger::Manual::ForLogAny>

=item * L<Log::ger::Manual::ForLogContextual>

=item * L<Log::ger::Manual::ForLogDispatch>

=item * L<Log::ger::Manual::ForLogDispatchouli>

=item * L<Log::ger::Manual::Internals>

=item * L<Log::ger::Manual::Tips>

=item * L<Log::ger::Manual::Tutorial>

=item * L<Log::ger::Manual::Tutorial::100_WhatIsLogging>

=item * L<Log::ger::Manual::Tutorial::200_LoggingWithLogGer>

=item * L<Log::ger::Manual::Tutorial::300_Level>

=item * L<Log::ger::Manual::Tutorial::400_Output>

=item * L<Log::ger::Manual::Tutorial::41_Output_Screen>

=item * L<Log::ger::Manual::Tutorial::420_Output_File>

=item * L<Log::ger::Manual::Tutorial::421_Output_SimpleFile>

=item * L<Log::ger::Manual::Tutorial::422_Output_FileWriteRotate>

=item * L<Log::ger::Manual::Tutorial::43_Output_Syslog>

=item * L<Log::ger::Manual::Tutorial::47_Output_DirwriteRotate>

=item * L<Log::ger::Manual::Tutorial::481_Output_Composite>

=item * L<Log::ger::Manual::Tutorial::49_WritingAnOutputPlugin>

=item * L<Log::ger::Manual::Tutorial::500_Category>

=item * L<Log::ger::Manual::Tutorial::600_Format>

=item * L<Log::ger::Manual::Tutorial::61_Format_Block>

=item * L<Log::ger::Manual::Tutorial::69_WritingAFormatPlugin>

=item * L<Log::ger::Manual::Tutorial::700_Layout>

=item * L<Log::ger::Manual::Tutorial::79_WritingALayoutPlugin>

=item * L<Log::ger::Manual::Tutorial::800_Other_Plugin>

=item * L<Log::ger::Manual::Tutorial::81_Plugin_OptAway>

=item * L<Log::ger::Manual::Tutorial::89_WritingAPlugin>

=item * L<Log::ger::Manual::Tutorial::900_OtherTopics>

=item * L<Log::ger::Manual::Tutorial::91_Performance>

=item * L<Log::ger::Manual::Tutorial::92_Security>

=item * L<Log::ger::Manual::Tutorial::931_UsingInApplication>

=item * L<Log::ger::Manual::Tutorial::932_UsingWithLogGerApp>

=item * L<Log::ger::Manual::Tutorial::933_UsingWithPerinciCmdLine>

=item * L<Log::ger::Manual::Tutorial::934_UsingWithMooMoose>

=back

Start with L<Log::ger::Manual::Tutorial>.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2019, 2018, 2017 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
