package Log::ger::Screen::ColorScheme::AspirinC;

our $DATE = '2017-08-03'; # DATE
our $VERSION = '0.001'; # VERSION

use strict;
use warnings;
use Color::ANSI::Util qw(ansifg);
use Log::ger::Output::Screen ();

our %colors = (
    1 => "EB7F00", # fatal
    2 => "F3FFE2", # error
    3 => "ACF0F2", # warn
    4 => "1695A3", # info
    5 => "",       # debug
    6 => "225378", # trace
);

for (keys %colors) {
    $Log::ger::Output::Screen::colors{$_} =
        $colors{$_} ? ansifg($colors{$_}) : "";
}

1;
# ABSTRACT: AspirinC color scheme

__END__

=pod

=encoding UTF-8

=head1 NAME

Log::ger::Screen::ColorScheme::AspirinC - AspirinC color scheme

=head1 VERSION

version 0.001

=head1 SYNOPSIS

 use Log::ger::Output 'Screen';
 use Log::ger::Screen::ColorScheme::AspirinC;
 use Log::ger;

 log_error("error");
 log_warn("warn");

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2017 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
