package # hide from PAUSE
    Local::C1;

use Class::Accessor::PackedString {
    accessors => {
        foo => "f",
        bar => "c",
    },
};

1;
