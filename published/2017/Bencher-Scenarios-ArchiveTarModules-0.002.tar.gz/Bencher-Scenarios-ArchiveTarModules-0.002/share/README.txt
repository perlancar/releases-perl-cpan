archive.tar.gz is a sample archive containing 10 files, ~10MB each.
