package # hide from PAUSE
    Local::C1;

use Class::Accessor::PackedString::Set {
    accessors => [
        foo => "f",
        bar => "c",
    ],
};

1;
