# just to make PodWeaver happy atm
package Sub::Spec::Manual::Spec;
BEGIN {
  $Sub::Spec::Manual::Spec::VERSION = '0.02';
}
# ABSTRACT: Specification for Sub::Spec


1;

__END__
=pod

=head1 NAME

Sub::Spec::Manual::Spec - Specification for Sub::Spec

=head1 VERSION

version 0.02

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

