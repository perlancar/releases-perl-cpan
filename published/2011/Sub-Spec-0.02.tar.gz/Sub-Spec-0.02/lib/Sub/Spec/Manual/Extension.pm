# just to make PodWeaver happy atm
package Sub::Spec::Manual::Extension;
BEGIN {
  $Sub::Spec::Manual::Extension::VERSION = '0.02';
}
# ABSTRACT: Extending Sub::Spec


1;

__END__
=pod

=head1 NAME

Sub::Spec::Manual::Extension - Extending Sub::Spec

=head1 VERSION

version 0.02

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

