package Dies;
# just to make sure that it is not loaded. when not yet needed, Sub::Spec::URI
# should not require() the module.
die;
1;
