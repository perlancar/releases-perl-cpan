package Data::Sah::Filter::perl::Nutrient::canonicalize_nutrient_symbol;

use 5.010001;
use strict;
use warnings;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2025-11-03'; # DATE
our $DIST = 'Sah-SchemaBundle-Nutrient'; # DIST
our $VERSION = '0.003'; # VERSION

our %aliases; # key=alias, value=official symbol
# load and cache the table
{
    require TableData::Health::Nutrient;
    my $td = TableData::Health::Nutrient->new;
    my @rows = $td->get_all_rows_hashref;
    for my $row (@rows) {
        if ($row->{aliases}) {
            for my $alias (@{ $row->{aliases} }) {
                $aliases{ $alias} = $row->{symbol};
            }
        }
    }
}

sub meta {
    +{
        v => 1,
        summary => 'Canonicalize nutrient symbol (alias to official symbol name)',
        description => <<'MARKDOWN',

Aliases e.g. `VB7` will be changed to its official symbol name e.g. `Biotin`.
Other strings will remain unchanged.

MARKDOWN
    };
}

sub filter {
    my %args = @_;

    my $dt = $args{data_term};

    my $res = {};

    $res->{expr_filter} = join(
        "",
        "do { my \$tmp = $dt; ", (
            "if (defined(my \$sym = \$".__PACKAGE__."::aliases{\$tmp})) { \$sym } else { \$tmp } "),
        "}",
    );

    $res;
}

1;
# ABSTRACT:

__END__

=pod

=encoding UTF-8

=head1 NAME

Data::Sah::Filter::perl::Nutrient::canonicalize_nutrient_symbol

=head1 VERSION

This document describes version 0.003 of Data::Sah::Filter::perl::Nutrient::canonicalize_nutrient_symbol (from Perl distribution Sah-SchemaBundle-Nutrient), released on 2025-11-03.

=head1 DESCRIPTION

This prefilter rule canonicalize nutrient symbol. If input is one of known
aliases, e.g. C<VB7>, it will be changed to its canonical symbol name e.g.
C<Biotin>. Otherwise, input is left unmodified.

=for Pod::Coverage ^(meta|filter)$

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Sah-SchemaBundle-Nutrient>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Sah-SchemaBundle-Nutrient>.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2025 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Sah-SchemaBundle-Nutrient>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
