package Data::Schema::Type::MyType1;
our $VERSION = '0.13';



#use Moose;
#extends 'Data::Schema::Type::Base';

sub new { {} }

our $DS_TYPE = 'mytype1';

#no Moose;
1;
