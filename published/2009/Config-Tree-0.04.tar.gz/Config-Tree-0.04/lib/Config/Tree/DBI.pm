package Config::Tree::DBI;

die "Not yet implemented";

1;
