package Config::Tree::Env;

die "Not yet implemented";

1;
