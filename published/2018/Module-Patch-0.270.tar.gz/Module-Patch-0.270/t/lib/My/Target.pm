package My::Target;

our $VERSION = '0.12';

sub foo { "original foo" }
sub bar { "original bar" }

1;
# ABSTRACT: Sample target module
