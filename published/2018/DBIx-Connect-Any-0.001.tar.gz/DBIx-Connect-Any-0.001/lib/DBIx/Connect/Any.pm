package DBIx::Connect::Any;

our $DATE = '2018-12-03'; # DATE
our $VERSION = '0.001'; # VERSION

use strict;
use warnings;
#use Log::ger;

sub connect {
    my $pkg  = shift;
    my $dsn  = shift;
    my $user = shift;
    my $pass = shift;

    if ($dsn =~ /\A\QDBI:mysql:\E/) {
        require DBIx::Connect::MySQL;
        DBIx::Connect::MySQL->connect($dsn, $user, $pass, @_);
    } else {
        require DBI;
        DBI->connect($dsn, $user, $pass, @_);
    }
}

1;
# ABSTRACT: Connect to DBI using DBIx::Connect::*

__END__

=pod

=encoding UTF-8

=head1 NAME

DBIx::Connect::Any - Connect to DBI using DBIx::Connect::*

=head1 VERSION

This document describes version 0.001 of DBIx::Connect::Any (from Perl distribution DBIx-Connect-Any), released on 2018-12-03.

=head1 SYNOPSIS

Instead of:

 use DBI;
 my $dbh = DBI->connect("dbi:mysql:database=mydb", ...);

you can now do:

 use DBIx::Connect::Any;
 my $dbh = DBIx::Connect::Any->connect("dbi:mysql:database=mydb", ...);

and connecting will be handled by L<DBIx::Connect::MySQL>.

=head1 DESCRIPTION

This is a wrapper for L<DBIx::Connect::MySQL> and other future DBIx::Connect::*.

=head1 METHODS

=head2 connect($dsn, $user, $pass, ...)

Currently will pass to L<DBI::Connect::MySQL> if C<$dsn> starts with
"DBI:mysql:". Otherwise will pass to C<< DBI->connect >>.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/DBIx-Connect-Any>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-DBIx-Connect-Any>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=DBIx-Connect-Any>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2018 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
