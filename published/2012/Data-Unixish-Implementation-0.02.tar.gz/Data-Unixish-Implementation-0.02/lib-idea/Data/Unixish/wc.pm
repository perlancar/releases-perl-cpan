package Data::Unixish::wc;

use 5.010;
use strict;
use warnings;

# VERSION

our %SPEC;

$SPEC{wc} = {
    v => 1.1,
    args => {
    },
};
sub wc {
}

1;
# ABSTRACT: Count lines, words, and characters
