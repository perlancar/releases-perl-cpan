package IOD;

our $VERSION = '0.9.0'; # VERSION

1;
# ABSTRACT: IOD file format specification

__END__
=pod

=head1 NAME

IOD - IOD file format specification

=head1 VERSION

version 0.9.0

=head1 FUNCTIONS

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2012 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

