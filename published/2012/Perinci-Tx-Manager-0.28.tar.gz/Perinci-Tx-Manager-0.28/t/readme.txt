The tests for transaction functionality currently live in the
Perinci-Access-InProcess distribution, as we test via Riap.

Our own test suite would be ideal.
