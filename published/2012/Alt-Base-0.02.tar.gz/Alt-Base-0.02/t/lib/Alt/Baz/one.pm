package Alt::Baz::one;
# Baz defines incorrect $ALT
use base qw(Alt::Base);
1;
