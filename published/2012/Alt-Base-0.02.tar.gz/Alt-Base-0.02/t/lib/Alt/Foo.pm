package Alt::Foo;
# this Alt is badly named (no phrase)
use base qw(Alt::Base);
1;
