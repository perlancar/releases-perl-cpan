package Bar;
# does not define $ALT
1;
