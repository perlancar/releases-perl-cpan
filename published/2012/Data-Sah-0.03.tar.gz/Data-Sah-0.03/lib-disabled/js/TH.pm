package Data::Sah::Compiler::perl::TH;

use Moo;
extends 'Data::Sah::Compiler::BaseProg::TH';

# VERSION

1;
# ABSTRACT: Base class for perl type handlers

=cut
