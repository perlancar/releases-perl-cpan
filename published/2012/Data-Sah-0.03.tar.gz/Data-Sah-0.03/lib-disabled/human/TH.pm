package Data::Sah::Compiler::human::TH;

use Moo;
extends 'Data::Sah::Compiler::BaseCompiler::TH';

# VERSION

sub clause_name {}
sub clause_summary {}
sub clause_description {}
sub clause_comment {}
sub clause_tags {}

1;
# ABSTRACT: Base class for human-language compiler's type handlers

=cut
