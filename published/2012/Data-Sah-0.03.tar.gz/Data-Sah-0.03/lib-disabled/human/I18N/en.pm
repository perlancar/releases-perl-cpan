package Data::Sah::Compiler::human::I18N::en;
use parent qw(Data::Sah::Compiler::perl::I18N);

use Locale::Maketext::Lexicon::Gettext;
our %Lexicon = %{ Locale::Maketext::Lexicon::Gettext->parse(<DATA>) };

# VERSION

#use Data::Dump; dd \%Lexicon;

1;
# ABSTRACT: English translation
__DATA__
msgid  ""
msgstr ""

