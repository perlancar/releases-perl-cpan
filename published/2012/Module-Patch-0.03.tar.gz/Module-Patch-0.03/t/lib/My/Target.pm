package My::Target;

our $VERSION = '0.12';

sub foo { "foo from My::Target" }
sub bar { "bar from My::Target" }

1;
# ABSTRACT: Sample target module
