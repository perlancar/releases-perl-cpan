# width (int)
# ellipsis (bool)
# ansi (bool) - don't cut ansi codes in the middle, don't count as width
