# alignment = left, middle, right
# min_width
# ansi (interpret ansi codes when calculating width)
