# style Yes/No, True/False, On/Off, 1/0, (localized)
# undef = -, ?, N/A  ...

# module on CPAN to detect language?
