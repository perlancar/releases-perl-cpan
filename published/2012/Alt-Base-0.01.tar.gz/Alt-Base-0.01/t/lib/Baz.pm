package Baz;
# define an incorrect $ALT
our $ALT = 'blah';
1;
