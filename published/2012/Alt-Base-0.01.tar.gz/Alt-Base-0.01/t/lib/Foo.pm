package Foo;
our $ALT = 'one';
1;
