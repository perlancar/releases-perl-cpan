package Alt::Foo::one;
# this alt is correct
use base qw(Alt::Base);
1;
