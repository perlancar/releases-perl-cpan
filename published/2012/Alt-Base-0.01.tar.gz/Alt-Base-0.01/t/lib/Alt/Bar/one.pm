package Alt::Bar::one;
# Bar does not define $ALT
use base qw(Alt::Base);
1;
