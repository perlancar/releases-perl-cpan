package Rinci;

our $VERSION = '1.1.14'; # VERSION

1;
# ABSTRACT: Language-neutral metadata for your code

__END__
=pod

=head1 NAME

Rinci - Language-neutral metadata for your code

=head1 VERSION

version 1.1.14

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2012 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

