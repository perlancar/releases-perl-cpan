package Foo;

our $VERSION = 0.12;

1;
