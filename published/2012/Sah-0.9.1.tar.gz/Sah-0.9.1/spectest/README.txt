This spec test suite is written in YAML so that other Sah implementations can
easily read it.
