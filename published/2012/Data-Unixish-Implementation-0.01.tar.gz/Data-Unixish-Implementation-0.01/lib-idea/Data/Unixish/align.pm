# arg = left, middle, right
# min_width