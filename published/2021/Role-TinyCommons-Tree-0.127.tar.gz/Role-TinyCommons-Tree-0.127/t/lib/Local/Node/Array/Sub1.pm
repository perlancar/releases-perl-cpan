package # hide from PAUSE
    Local::Node::Array::Sub1;

use parent qw(Local::Node::Array);

1;
