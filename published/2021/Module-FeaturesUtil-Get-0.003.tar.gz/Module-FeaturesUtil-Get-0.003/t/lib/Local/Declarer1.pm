package Local::Declarer1;

use strict;
use warnings;

our %FEATURES = (
    features => {
        Dummy => {
            feature2 => 1,
            feature3 => 'a',
        },
    },
);

1;
# ABSTRACT: An example feature declarer
