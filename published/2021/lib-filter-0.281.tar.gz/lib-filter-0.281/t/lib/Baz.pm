# just an empty module for testing
package Baz;

1;
