package # hide from PAUSE
    Local::TOH2;

use parent qw(Local::TOH);

1;
