package Tree::From::FS;

use strict;
use warnings;
use Exporter qw(import);

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2021-10-07'; # DATE
our $DIST = 'Tree-From-FS'; # DIST
our $VERSION = '0.000.2'; # VERSION

our @EXPORT_OK = qw(create_tree_from_dir);

sub create_tree_from_dir {
    die "Not yet implemented";
}

1;
# ABSTRACT: Create a tree object from directory structure on the filesystem

__END__

=pod

=encoding UTF-8

=head1 NAME

Tree::From::FS - Create a tree object from directory structure on the filesystem

=head1 VERSION

This document describes version 0.000.2 of Tree::From::FS (from Perl distribution Tree-From-FS), released on 2021-10-07.

=head1 SYNOPSIS

=head1 DESCRIPTION

B<PLACEHOLDER. NOT YET IMPLEMENTED.>

=head1 FUNCTIONS

=head2 create_tree_from_dir($path) => obj

This module provides a convenience function to build a tree of objects that
mirrors a directory structure on the filesystem. Each node will represent a file
or a subdirectory.

The class can be any class that provides C<parent> and C<children> methods. See
L<Role::TinyCommons::Tree::Node> for more details on the requirement.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Tree-From-FS>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Tree-FromFS>.

=head1 SEE ALSO

L<RoleBundle::TinyCommons::Tree>

Other ways to create tree: L<Tree::From::Struct>, L<Tree::From::ObjArray>,
L<Tree::From::Text>, L<Tree::From::TextLines>, L<Tree::Create::Callback>,
L<Tree::Create::Size>.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla plugin and/or Pod::Weaver::Plugin. Any additional steps required
beyond that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2021, 2020, 2016 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Tree-From-FS>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
