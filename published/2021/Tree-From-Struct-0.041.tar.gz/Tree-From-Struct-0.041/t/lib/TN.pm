package # hide from PAUSE
    TN;

use parent qw(TN0);

1;
