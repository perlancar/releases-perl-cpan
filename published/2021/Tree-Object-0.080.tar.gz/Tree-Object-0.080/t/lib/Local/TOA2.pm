package # hide from PAUSE
    Local::TOA2;

use parent qw(Local::TOA);

1;
