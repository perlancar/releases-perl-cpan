package # hide from PAUSE
    Local::TOAG;

use Tree::Object::Array::Glob qw(id);

1;
