package # hide from PAUSE
    Local::Node::Moo::Sub2;

use parent qw(Local::Node::Moo);

1;
