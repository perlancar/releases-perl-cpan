package # hide from PAUSE
    Local::Node::Moose::Sub1;

use Moose;
extends 'Local::Node::Moose';

1;
