package # hide from PAUSE
    Local::TOAG1;

use parent qw(Local::TOAG);

1;
