package # hide from PAUSE
    Local::TOH1;

use parent qw(Local::TOH);

1;
