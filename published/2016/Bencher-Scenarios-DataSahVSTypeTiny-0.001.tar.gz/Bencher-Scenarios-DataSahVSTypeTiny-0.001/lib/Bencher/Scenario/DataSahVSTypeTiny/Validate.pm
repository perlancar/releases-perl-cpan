package Bencher::Scenario::DataSahVSTypeTiny::Validate;

use 5.010001;

our $DATE = '2016-05-24'; # DATE
our $VERSION = '0.001'; # VERSION

eval "package main; use Types::Standard qw(ArrayRef Int)";

our $scenario = {
    summary => 'Benchmark validation',
    participants => [
        {
            name => 'dsah',
            module => 'Data::Sah',
            code_template => 'state $v = Data::Sah::gen_validator(<schema>); $v->(<data>)',
            tags => ['dsah'],
        },
        {
            name => 'tt',
            #module => 'Types::Standard',
            code_template => 'state $v = <type:raw>; $v->check(<data>)',
            tags => ['tt'],
        },
    ],
    datasets => [
        {
            name => 'int(dsah)',
            include_participant_tags => ['dsah'],
            args => {
                schema => 'int*',
                'data@' => [undef, 1, "a"],
            },
        },
        {
            name => 'int(tt)',
            include_participant_tags => ['tt'],
            args => {
                type => 'Int',
                'data@' => [undef, 1, "a"],
            },
        },

        {
            name => 'array10(dsah)',
            include_participant_tags => ['dsah'],
            args => {
                schema => ['array', of=>'int*'],
                'data' => [1..10],
            },
        },
        {
            name => 'array10(tt)',
            include_participant_tags => ['tt'],
            args => {
                type => 'ArrayRef[Int]',
                'data' => [1..10],
            },
        },
    ],
};

1;
# ABSTRACT: Benchmark validation

__END__

=pod

=encoding UTF-8

=head1 NAME

Bencher::Scenario::DataSahVSTypeTiny::Validate - Benchmark validation

=head1 VERSION

This document describes version 0.001 of Bencher::Scenario::DataSahVSTypeTiny::Validate (from Perl distribution Bencher-Scenarios-DataSahVSTypeTiny), released on 2016-05-24.

=head1 SYNOPSIS

To run benchmark with default option:

 % bencher -m DataSahVSTypeTiny::Validate

To run module startup overhead benchmark:

 % bencher --module-startup -m DataSahVSTypeTiny::Validate

For more options (dump scenario, list/include/exclude/add participants, list/include/exclude/add datasets, etc), see L<bencher> or run C<bencher --help>.

=head1 BENCHMARKED MODULES

Version numbers shown below are the versions used when running the sample benchmark.

L<Data::Sah> 0.78

=head1 BENCHMARK PARTICIPANTS

=over

=item * dsah (perl_code) [dsah]

Code template:

 state $v = Data::Sah::gen_validator(<schema>); $v->(<data>)



=item * tt (perl_code) [tt]

Code template:

 state $v = <type:raw>; $v->check(<data>)



=back

=head1 BENCHMARK DATASETS

=over

=item * int(dsah)

=item * int(tt)

=item * array10(dsah)

=item * array10(tt)

=back

=head1 SAMPLE BENCHMARK RESULTS

Run on: perl: I<< v5.22.1 >>, CPU: I<< Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz (4 cores) >>, OS: I<< GNU/Linux Debian version 8.0 >>, OS kernel: I<< Linux version 3.16.0-4-amd64 >>.

Benchmark with default options (C<< bencher -m DataSahVSTypeTiny::Validate >>):

 +-------------+---------------+----------+-----------+-----------+------------+---------+---------+
 | participant | dataset       | arg_data | rate (/s) | time (μs) | vs_slowest | errors  | samples |
 +-------------+---------------+----------+-----------+-----------+------------+---------+---------+
 | dsah        | array10(dsah) |          | 2.01e+05  | 4.98      | 1          | 1.5e-09 | 24      |
 | tt          | array10(tt)   |          | 1.07e+06  | 0.931     | 5.36       | 4.5e-10 | 30      |
 | tt          | int(tt)       | a        | 2.5e+06   | 0.41      | 12         | 3.5e-09 | 20      |
 | dsah        | int(dsah)     | 1        | 2.53e+06  | 0.395     | 12.6       | 4.6e-11 | 20      |
 | tt          | int(tt)       | 1        | 2.58e+06  | 0.387     | 12.9       | 1.9e-10 | 20      |
 | dsah        | int(dsah)     | a        | 2.6e+06   | 0.38      | 13         | 6.3e-10 | 20      |
 | tt          | int(tt)       |          | 2.8e+06   | 0.36      | 14         | 1.1e-09 | 20      |
 | dsah        | int(dsah)     |          | 3.21e+06  | 0.312     | 16         | 2.4e-10 | 22      |
 +-------------+---------------+----------+-----------+-----------+------------+---------+---------+


Benchmark module startup overhead (C<< bencher -m DataSahVSTypeTiny::Validate --module-startup >>):

 +---------------------+-----------+------------------------+------------+---------+---------+
 | participant         | time (ms) | mod_overhead_time (ms) | vs_slowest | errors  | samples |
 +---------------------+-----------+------------------------+------------+---------+---------+
 | Data::Sah           | 12        | 7.4                    | 1          | 2.4e-05 | 20      |
 | perl -e1 (baseline) | 4.6       | 0                      | 2.6        | 4.4e-05 | 20      |
 +---------------------+-----------+------------------------+------------+---------+---------+

=head1 DESCRIPTION

Packaging a benchmark script as a Bencher scenario makes it convenient to include/exclude/add participants/datasets (either via CLI or Perl code), send the result to a central repository, among others . See L<Bencher> and L<bencher> (CLI) for more details.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Bencher-Scenarios-DataSahVSTypeTiny>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Bencher-Scenarios-DataSahVSTypeTiny>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Bencher-Scenarios-DataSahVSTypeTiny>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2016 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
