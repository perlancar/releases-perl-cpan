package # hide from PAUSE
    TN;

use parent qw(TN0);

use Role::Tiny::With;

with 'Role::TinyCommons::Tree::FromStruct';

1;
