package # hide from PAUSE
    Local::Node::InsideOut::Sub1;

use parent qw(Local::Node::InsideOut);

1;
