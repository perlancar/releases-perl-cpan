package App::SahUtils;

our $DATE = '2016-05-30'; # DATE
our $VERSION = '0.30'; # VERSION

use 5.010001;

1;
# ABSTRACT: Collection of CLI utilities for Sah and Data::Sah

__END__

=pod

=encoding UTF-8

=head1 NAME

App::SahUtils - Collection of CLI utilities for Sah and Data::Sah

=head1 VERSION

This document describes version 0.30 of App::SahUtils (from Perl distribution App-SahUtils), released on 2016-05-30.

=head1 SYNOPSIS

This distribution provides the following command-line utilities related to
L<Sah> and L<Data::Sah>:

=over

=item * L<coerce-with-sah>

=item * L<list-sah-coerce-rule-modules>

=item * L<list-sah-schema-modules>

=item * L<list-sah-type-modules>

=item * L<normalize-sah-schema>

=item * L<sah-to-human>

=item * L<show-sah-schema-module>

=item * L<validate-with-sah>

=back

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/App-SahUtils>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-App-SahUtils>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=App-SahUtils>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 SEE ALSO

L<Data::Sah>

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2016 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
