package # hide from PAUSE
    TN2;

use parent qw(TN);

1;
