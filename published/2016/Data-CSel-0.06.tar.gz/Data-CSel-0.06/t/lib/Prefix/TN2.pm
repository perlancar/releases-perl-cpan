package # hide from PAUSE
    Prefix::TN2;

use parent 'TN';

1;
