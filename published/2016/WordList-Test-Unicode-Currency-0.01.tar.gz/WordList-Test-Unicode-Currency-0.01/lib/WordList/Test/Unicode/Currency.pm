package WordList::Test::Unicode::Currency;

our $DATE = '2016-01-12'; # DATE
our $VERSION = '0.01'; # VERSION

use WordList;
our @ISA = qw(WordList);

1;
# ABSTRACT: Currency symbols



=pod

=encoding UTF-8

=head1 NAME

WordList::Test::Unicode::Currency - Currency symbols

=head1 VERSION

This document describes version 0.01 of WordList::Test::Unicode::Currency (from Perl distribution WordList-Test-Unicode-Currency), released on 2016-01-12.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/WordList-Test-Unicode-Currency>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-WordList-Test-Unicode-Currency>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=WordList-Test-Unicode-Currency>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2016 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut


__DATA__
IDR Rp
USD $
GBP £
EUR €
JPY ¥
