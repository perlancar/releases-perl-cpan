package Acme::PERLANCAR::Test::ScriptNameSameAsModuleName;

our $DATE = '2016-02-10'; # DATE
our $VERSION = '0.02'; # VERSION

1;
# ABSTRACT: Test script name that is the same as a known module name

__END__

=pod

=encoding UTF-8

=head1 NAME

Acme::PERLANCAR::Test::ScriptNameSameAsModuleName - Test script name that is the same as a known module name

=head1 VERSION

This document describes version 0.02 of Acme::PERLANCAR::Test::ScriptNameSameAsModuleName (from Perl distribution Acme-PERLANCAR-Test-ScriptNameSameAsModuleName), released on 2016-02-10.

=head1 DESCRIPTION

This distribution contains the following scripts:

=over

=item * L<strict>

=item * L<warnings>

=back

which have the same name as some known module names. This distribution is for
testing purposes only.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Acme-PERLANCAR-Test-ScriptNameSameAsModuleName>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Acme-PERLANCAR-Test-ScriptNameSameAsModuleName>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Acme-PERLANCAR-Test-ScriptNameSameAsModuleName>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2016 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
