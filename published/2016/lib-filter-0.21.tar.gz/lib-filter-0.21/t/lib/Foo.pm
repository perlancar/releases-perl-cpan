# just an empty module for testing
package Foo;

1;
