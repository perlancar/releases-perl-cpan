package # hide from PAUSE
    Local::TOAG2;

use parent qw(Local::TOAG);

1;
