package # hide from PAUSE
    Local::TOA1;

use parent qw(Local::TOA);

1;
