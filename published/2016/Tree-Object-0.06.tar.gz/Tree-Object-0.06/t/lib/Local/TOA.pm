package # hide from PAUSE
    Local::TOA;

use Tree::Object::Array qw(id);

1;
