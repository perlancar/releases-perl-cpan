package # hide from PAUSE
    Local::C1;

use Class::Accessor::Array {
    accessors => {
        foo => 0,
        bar => 1,
    },
};

1;
