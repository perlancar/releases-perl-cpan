package Bencher::Scenario::IOFilterModules::Writing;

our $DATE = '2016-10-12'; # DATE
our $VERSION = '0.001'; # VERSION

use strict;
use warnings;
use File::Temp qw(tempfile);

our $scenario = {
    summary => 'Benchmark writing with filter that does nothing',

    description => <<'_',

Each participant will write `chunk_size` bytes (0, 1, and 1024) for 1000 times.

_

    modules => {
    },

    participants => [
        {
            module => 'Tie::Handle::Filter',
            code_template => <<'_',
open *FH0, ">", <tempfile> or die "Can't open: $!";
tie  *FH , "Tie::Handle::Filter", *FH0, sub { @_ };
my $chunk = "a" x <chunk_size>;
for (1..1000) { print FH $chunk }
close FH;
die "Incorrect file size" unless (-s <tempfile>) == <chunk_size> * 1000;
_
        },
        {
            name => 'PerlIO::via',
            module => 'PerlIO::via::as_is',
            code_template => <<'_',
open my($fh), ">:via(as_is)", <tempfile>;
my $chunk = "a" x <chunk_size>;
for (1..1000) { print $fh $chunk }
close $fh;
die "Incorrect file size" unless (-s <tempfile>) == <chunk_size> * 1000;
_
        },
        {
            name => 'raw',
            code_template => <<'_',
open my($fh), ">", <tempfile>;
my $chunk = "a" x <chunk_size>;
for (1..1000) { print $fh $chunk }
close $fh;
die "Incorrect file size" unless (-s <tempfile>) == <chunk_size> * 1000;
_
        },
    ],

    # generate datasets
    before_list_datasets => sub {
        my %args = @_;
        my $scenario = $args{scenario};
        my $seq = 0;
        for my $chunk_size (0, 1, 1024) {
            my ($fh, $filename) = tempfile();
            push @{ $scenario->{datasets} }, {
                name => "chunk_size=$chunk_size",
                args => {chunk_size => $chunk_size, tempfile => $filename},
                seq => $seq++,
            };
        }
    },

    # generated dynamically
    datasets => undef,
};

1;
# ABSTRACT: Benchmark writing with filter that does nothing

__END__

=pod

=encoding UTF-8

=head1 NAME

Bencher::Scenario::IOFilterModules::Writing - Benchmark writing with filter that does nothing

=head1 VERSION

This document describes version 0.001 of Bencher::Scenario::IOFilterModules::Writing (from Perl distribution Bencher-Scenarios-IOFilterModules), released on 2016-10-12.

=head1 SYNOPSIS

To run benchmark with default option:

 % bencher -m IOFilterModules::Writing

To run module startup overhead benchmark:

 % bencher --module-startup -m IOFilterModules::Writing

For more options (dump scenario, list/include/exclude/add participants, list/include/exclude/add datasets, etc), see L<bencher> or run C<bencher --help>.

=head1 DESCRIPTION

Each participant will write C<chunk_size> bytes (0, 1, and 1024) for 1000 times.


Packaging a benchmark script as a Bencher scenario makes it convenient to include/exclude/add participants/datasets (either via CLI or Perl code), send the result to a central repository, among others . See L<Bencher> and L<bencher> (CLI) for more details.

=head1 BENCHMARKED MODULES

Version numbers shown below are the versions used when running the sample benchmark.

L<PerlIO::via::as_is> 0.001

L<Tie::Handle::Filter> 0.008

=head1 BENCHMARK PARTICIPANTS

=over

=item * Tie::Handle::Filter (perl_code)

Code template:

 open *FH0, ">", <tempfile> or die "Can't open: $!";
 tie  *FH , "Tie::Handle::Filter", *FH0, sub { @_ };
 my $chunk = "a" x <chunk_size>;
 for (1..1000) { print FH $chunk }
 close FH;
 die "Incorrect file size" unless (-s <tempfile>) == <chunk_size> * 1000;




=item * PerlIO::via (perl_code)

Code template:

 open my($fh), ">:via(as_is)", <tempfile>;
 my $chunk = "a" x <chunk_size>;
 for (1..1000) { print $fh $chunk }
 close $fh;
 die "Incorrect file size" unless (-s <tempfile>) == <chunk_size> * 1000;




=item * raw (perl_code)

Code template:

 open my($fh), ">", <tempfile>;
 my $chunk = "a" x <chunk_size>;
 for (1..1000) { print $fh $chunk }
 close $fh;
 die "Incorrect file size" unless (-s <tempfile>) == <chunk_size> * 1000;




=back

=head1 SAMPLE BENCHMARK RESULTS

Run on: perl: I<< v5.24.0 >>, CPU: I<< Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz (4 cores) >>, OS: I<< GNU/Linux Debian version 8.0 >>, OS kernel: I<< Linux version 3.16.0-4-amd64 >>.

Benchmark with default options (C<< bencher -m IOFilterModules::Writing >>):

 #table1#
 +---------------------+-----------------+-----------+-----------+------------+---------+---------+
 | participant         | dataset         | rate (/s) | time (ms) | vs_slowest |  errors | samples |
 +---------------------+-----------------+-----------+-----------+------------+---------+---------+
 | Tie::Handle::Filter | chunk_size=1024 |       460 |  2.2      |      1     | 6.6e-06 |      21 |
 | PerlIO::via         | chunk_size=1024 |       510 |  2        |      1.1   | 6.5e-06 |      20 |
 | raw                 | chunk_size=1024 |       850 |  1.2      |      1.8   | 5.4e-06 |      20 |
 | Tie::Handle::Filter | chunk_size=1    |      1100 |  0.9      |      2.4   | 2.5e-06 |      20 |
 | Tie::Handle::Filter | chunk_size=0    |      1100 |  0.88     |      2.5   | 3.4e-06 |      20 |
 | PerlIO::via         | chunk_size=1    |      1700 |  0.6      |      3.6   | 2.9e-06 |      20 |
 | raw                 | chunk_size=1    |      9400 |  0.11     |     20     | 2.7e-07 |      20 |
 | PerlIO::via         | chunk_size=0    |     12000 |  0.082    |     26     | 2.1e-07 |      21 |
 | raw                 | chunk_size=0    |     14329 |  0.069789 |     31.042 |   1e-10 |      20 |
 +---------------------+-----------------+-----------+-----------+------------+---------+---------+


Benchmark module startup overhead (C<< bencher -m IOFilterModules::Writing --module-startup >>):

 #table2#
 +---------------------+-----------+------------------------+------------+---------+---------+
 | participant         | time (ms) | mod_overhead_time (ms) | vs_slowest |  errors | samples |
 +---------------------+-----------+------------------------+------------+---------+---------+
 | Tie::Handle::Filter |      20   |                   15.2 |        1   | 6.2e-05 |      20 |
 | PerlIO::via::as_is  |       5   |                    0.2 |        4   | 1.9e-05 |      20 |
 | perl -e1 (baseline) |       4.8 |                    0   |        4.2 | 2.7e-05 |      20 |
 +---------------------+-----------+------------------------+------------+---------+---------+

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Bencher-Scenarios-IOFilterModules>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Bencher-Scenarios-IOFilterModules>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Bencher-Scenarios-IOFilterModules>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 SEE ALSO

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2016 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
