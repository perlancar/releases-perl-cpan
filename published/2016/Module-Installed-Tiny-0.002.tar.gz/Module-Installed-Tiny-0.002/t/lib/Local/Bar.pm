package Local::Bar;
1;
