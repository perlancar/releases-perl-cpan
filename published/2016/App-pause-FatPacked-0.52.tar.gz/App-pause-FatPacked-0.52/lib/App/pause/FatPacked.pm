package App::pause::FatPacked;

our $DATE = '2016-01-17'; # DATE
our $VERSION = '0.52'; # VERSION

our %PACKED_MODULES = %{ {"Algorithm::Dependency"=>1.110,"Algorithm::Dependency::Item"=>1.110,"Algorithm::Dependency::Ordered"=>1.110,"Algorithm::Dependency::Source"=>1.110,"Algorithm::Dependency::Source::File"=>1.110,"Algorithm::Dependency::Source::HoA"=>1.110,"Algorithm::Dependency::Source::Invert"=>1.110,"Algorithm::Dependency::Weight"=>1.110,"App::pause::FatPacked"=>0.52,"Clone::PP"=>1.06,"Color::ANSI::Util"=>0.14,"Complete::Bash"=>0.24,"Complete::Common"=>0.22,"Complete::Env"=>0.38,"Complete::File"=>0.39,"Complete::Fish"=>0.04,"Complete::Getopt::Long"=>0.39,"Complete::Path"=>0.21,"Complete::Tcsh"=>0.02,"Complete::Util"=>0.45,"Complete::Zsh"=>0.02,"Config::IOD::Base"=>0.19,"Config::IOD::Expr"=>0.19,"Config::IOD::Reader"=>0.19,"Data::Check::Structure"=>0.03,"Data::Clean::Base"=>0.28,"Data::Clean::FromJSON"=>0.28,"Data::Clean::JSON"=>0.28,"Data::Dmp"=>0.14,"Data::Dump"=>1.23,"Data::Dump::FilterContext"=>undef,"Data::Dump::Filtered"=>undef,"Data::Dump::Trace"=>0.02,"Data::ModeMerge"=>0.32,"Data::ModeMerge::Config"=>0.32,"Data::ModeMerge::Mode::ADD"=>0.32,"Data::ModeMerge::Mode::Base"=>0.32,"Data::ModeMerge::Mode::CONCAT"=>0.32,"Data::ModeMerge::Mode::DELETE"=>0.32,"Data::ModeMerge::Mode::KEEP"=>0.32,"Data::ModeMerge::Mode::NORMAL"=>0.32,"Data::ModeMerge::Mode::SUBTRACT"=>0.32,"Data::Sah"=>0.74,"Data::Sah::Compiler"=>0.74,"Data::Sah::Compiler::Prog"=>0.74,"Data::Sah::Compiler::Prog::TH"=>0.74,"Data::Sah::Compiler::Prog::TH::all"=>0.74,"Data::Sah::Compiler::Prog::TH::any"=>0.74,"Data::Sah::Compiler::TH"=>0.74,"Data::Sah::Compiler::TextResultRole"=>0.74,"Data::Sah::Compiler::human"=>0.74,"Data::Sah::Compiler::human::TH"=>0.74,"Data::Sah::Compiler::human::TH::Comparable"=>0.74,"Data::Sah::Compiler::human::TH::HasElems"=>0.74,"Data::Sah::Compiler::human::TH::Sortable"=>0.74,"Data::Sah::Compiler::human::TH::all"=>0.74,"Data::Sah::Compiler::human::TH::any"=>0.74,"Data::Sah::Compiler::human::TH::array"=>0.74,"Data::Sah::Compiler::human::TH::bool"=>0.74,"Data::Sah::Compiler::human::TH::buf"=>0.74,"Data::Sah::Compiler::human::TH::cistr"=>0.74,"Data::Sah::Compiler::human::TH::code"=>0.74,"Data::Sah::Compiler::human::TH::date"=>0.74,"Data::Sah::Compiler::human::TH::duration"=>0.74,"Data::Sah::Compiler::human::TH::float"=>0.74,"Data::Sah::Compiler::human::TH::hash"=>0.74,"Data::Sah::Compiler::human::TH::int"=>0.74,"Data::Sah::Compiler::human::TH::num"=>0.74,"Data::Sah::Compiler::human::TH::obj"=>0.74,"Data::Sah::Compiler::human::TH::re"=>0.74,"Data::Sah::Compiler::human::TH::str"=>0.74,"Data::Sah::Compiler::human::TH::undef"=>0.74,"Data::Sah::Compiler::js"=>0.74,"Data::Sah::Compiler::js::TH"=>0.74,"Data::Sah::Compiler::js::TH::all"=>0.74,"Data::Sah::Compiler::js::TH::any"=>0.74,"Data::Sah::Compiler::js::TH::array"=>0.74,"Data::Sah::Compiler::js::TH::bool"=>0.74,"Data::Sah::Compiler::js::TH::buf"=>0.74,"Data::Sah::Compiler::js::TH::cistr"=>0.74,"Data::Sah::Compiler::js::TH::code"=>0.74,"Data::Sah::Compiler::js::TH::date"=>0.74,"Data::Sah::Compiler::js::TH::float"=>0.74,"Data::Sah::Compiler::js::TH::hash"=>0.74,"Data::Sah::Compiler::js::TH::int"=>0.74,"Data::Sah::Compiler::js::TH::num"=>0.74,"Data::Sah::Compiler::js::TH::obj"=>0.74,"Data::Sah::Compiler::js::TH::re"=>0.74,"Data::Sah::Compiler::js::TH::str"=>0.74,"Data::Sah::Compiler::js::TH::undef"=>0.74,"Data::Sah::Compiler::perl"=>0.74,"Data::Sah::Compiler::perl::TH"=>0.74,"Data::Sah::Compiler::perl::TH::all"=>0.74,"Data::Sah::Compiler::perl::TH::any"=>0.74,"Data::Sah::Compiler::perl::TH::array"=>0.74,"Data::Sah::Compiler::perl::TH::bool"=>0.74,"Data::Sah::Compiler::perl::TH::buf"=>0.74,"Data::Sah::Compiler::perl::TH::cistr"=>0.74,"Data::Sah::Compiler::perl::TH::code"=>0.74,"Data::Sah::Compiler::perl::TH::date"=>0.74,"Data::Sah::Compiler::perl::TH::duration"=>0.74,"Data::Sah::Compiler::perl::TH::float"=>0.74,"Data::Sah::Compiler::perl::TH::hash"=>0.74,"Data::Sah::Compiler::perl::TH::int"=>0.74,"Data::Sah::Compiler::perl::TH::num"=>0.74,"Data::Sah::Compiler::perl::TH::obj"=>0.74,"Data::Sah::Compiler::perl::TH::re"=>0.74,"Data::Sah::Compiler::perl::TH::str"=>0.74,"Data::Sah::Compiler::perl::TH::undef"=>0.74,"Data::Sah::Human"=>0.74,"Data::Sah::JS"=>0.74,"Data::Sah::Lang"=>0.74,"Data::Sah::Lang::fr_FR"=>0.74,"Data::Sah::Lang::id_ID"=>0.74,"Data::Sah::Lang::zh_CN"=>0.74,"Data::Sah::Normalize"=>0.04,"Data::Sah::Type::BaseType"=>0.74,"Data::Sah::Type::Comparable"=>0.74,"Data::Sah::Type::HasElems"=>0.74,"Data::Sah::Type::Sortable"=>0.74,"Data::Sah::Type::all"=>0.74,"Data::Sah::Type::any"=>0.74,"Data::Sah::Type::array"=>0.74,"Data::Sah::Type::bool"=>0.74,"Data::Sah::Type::buf"=>0.74,"Data::Sah::Type::cistr"=>0.74,"Data::Sah::Type::code"=>0.74,"Data::Sah::Type::date"=>0.74,"Data::Sah::Type::duration"=>0.74,"Data::Sah::Type::float"=>0.74,"Data::Sah::Type::hash"=>0.74,"Data::Sah::Type::int"=>0.74,"Data::Sah::Type::num"=>0.74,"Data::Sah::Type::obj"=>0.74,"Data::Sah::Type::re"=>0.74,"Data::Sah::Type::str"=>0.74,"Data::Sah::Type::undef"=>0.74,"Data::Sah::Util::Func"=>0.74,"Data::Sah::Util::Role"=>0.74,"Data::Sah::Util::Type"=>0.43,"Data::Sah::Util::Type::Date"=>0.74,"Data::Sah::Util::TypeX"=>0.74,"Date::Format"=>2.24,"Date::Parse"=>2.30,"Exporter::Shiny"=>0.042,"Exporter::Tiny"=>0.042,"File::Which"=>1.18,"Function::Fallback::CoreOrPP"=>0.07,"Getopt::Long::Negate::EN"=>0.03,"Getopt::Long::Util"=>0.84,"HTTP::Tiny"=>0.054,"HTTP::Tiny::UNIX"=>0.04,JSON=>2.90,"JSON::PP"=>2.27300,"JSON::PP::Boolean"=>undef,"Lingua::EN::Numbers::Ordinate"=>1.04,"Lingua::EN::PluralToSingular"=>0.14,"List::MoreUtils"=>0.413,"List::MoreUtils::PP"=>0.413,"List::MoreUtils::XS"=>0.413,"Log::Any"=>1.032,"Log::Any::Adapter"=>1.032,"Log::Any::Adapter::Base"=>1.032,"Log::Any::Adapter::File"=>1.032,"Log::Any::Adapter::Null"=>1.032,"Log::Any::Adapter::Screen"=>0.11,"Log::Any::Adapter::Stderr"=>1.032,"Log::Any::Adapter::Stdout"=>1.032,"Log::Any::Adapter::Test"=>1.032,"Log::Any::Adapter::Util"=>1.032,"Log::Any::IfLOG"=>0.07,"Log::Any::Manager"=>1.032,"Log::Any::Proxy"=>1.032,"Log::Any::Proxy::Test"=>1.032,"Log::Any::Test"=>1.032,Mo=>0.39,"Mo::Golf"=>0.39,"Mo::Inline"=>0.39,"Mo::Moose"=>0.39,"Mo::Mouse"=>0.39,"Mo::build"=>0.39,"Mo::builder"=>0.39,"Mo::chain"=>0.39,"Mo::coerce"=>0.39,"Mo::default"=>0.39,"Mo::exporter"=>0.39,"Mo::import"=>0.39,"Mo::importer"=>0.39,"Mo::is"=>0.39,"Mo::nonlazy"=>0.39,"Mo::option"=>0.39,"Mo::required"=>0.39,"Mo::xs"=>0.39,"Module::Path::More"=>0.30,"Monkey::Patch::Action"=>0.04,"Monkey::Patch::Action::Handle"=>0.04,"PERLANCAR::File::HomeDir"=>0.02,"Params::Util"=>1.07,"Perinci::Access::Lite"=>0.12,"Perinci::AccessUtil"=>0.06,"Perinci::CmdLine::Base"=>1.45,"Perinci::CmdLine::Help"=>0.08,"Perinci::CmdLine::Lite"=>1.45,"Perinci::CmdLine::Util::Config"=>1.45,"Perinci::CmdLine::pause"=>0.30,"Perinci::Object"=>0.24,"Perinci::Object::EnvResult"=>0.24,"Perinci::Object::EnvResultMulti"=>0.24,"Perinci::Object::Function"=>0.24,"Perinci::Object::Metadata"=>0.24,"Perinci::Object::Package"=>0.24,"Perinci::Object::ResMeta"=>0.24,"Perinci::Object::Variable"=>0.24,"Perinci::Result::Format::Lite"=>0.11,"Perinci::Sub::CoerceArgs"=>0.13,"Perinci::Sub::Complete"=>0.84,"Perinci::Sub::ConvertArgs::Argv"=>0.07,"Perinci::Sub::ConvertArgs::Array"=>0.08,"Perinci::Sub::GetArgs::Argv"=>0.70,"Perinci::Sub::GetArgs::Array"=>0.15,"Perinci::Sub::Normalize"=>0.15,"Perinci::Sub::To::CLIDocData"=>0.24,"Perinci::Sub::Util"=>0.44,"Perinci::Sub::Util::ResObj"=>0.44,"Perinci::Sub::Util::Sort"=>0.44,"Progress::Any"=>0.20,"Progress::Any::Output"=>0.20,"Progress::Any::Output::Null"=>0.20,"Progress::Any::Output::TermProgressBarColor"=>0.21,"Regexp::Stringify"=>0.04,"Regexp::Wildcards"=>1.05,Rinci=>"1.1.78","Role::Tiny"=>2.000001,"Role::Tiny::With"=>2.000001,"Sah::Schema::Rinci"=>"1.1.78","Scalar::Util::Numeric::PP"=>0.03,"String::Elide::Parts"=>0.01,"String::Indent"=>0.03,"String::LineNumber"=>0.01,"String::PerlQuote"=>0.01,"String::ShellQuote"=>1.04,"String::Trim::More"=>0.02,"String::Wildcard::Bash"=>0.03,"Sub::Delete"=>1.00002,"Sub::Install"=>0.928,"Test::Config::IOD::Common"=>0.19,"Test::Data::Sah"=>0.74,"Text::ANSI::BaseUtil"=>0.21,"Text::ANSI::NonWideUtil"=>0.21,"Text::ANSI::Util"=>0.21,"Text::Table::Tiny"=>0.04,"Text::sprintfn"=>0.08,"Tie::IxHash"=>1.23,"Time::Duration"=>1.20,"Time::Duration::Parse::AsHash"=>"0.10.2","Time::Zone"=>2.24,"Version::Util"=>0.71,"WWW::PAUSE::Simple"=>0.29,experimental=>0.013} }; # PACKED_MODULES
our @PACKED_DISTS = @{["Algorithm-Dependency","App-pause-FatPacked","Clone-PP","Color-ANSI-Util","Complete-Bash","Complete-Common","Complete-Env","Complete-File","Complete-Fish","Complete-Getopt-Long","Complete-Path","Complete-Tcsh","Complete-Util","Complete-Zsh","Config-IOD-Reader","Data-Check-Structure","Data-Clean-JSON","Data-Dmp","Data-Dump","Data-ModeMerge","Data-Sah","Data-Sah-Normalize","Data-Sah-Util-Type","Exporter-Tiny","File-Which","Function-Fallback-CoreOrPP","Getopt-Long-Negate-EN","Getopt-Long-Util","HTTP-Tiny","HTTP-Tiny-UNIX","JSON","JSON-PP","Lingua-EN-Numbers-Ordinate","Lingua-EN-PluralToSingular","List-MoreUtils","Log-Any","Log-Any-Adapter-Screen","Log-Any-IfLOG","Mo","Module-Path-More","Monkey-Patch-Action","PERLANCAR-File-HomeDir","Params-Util","Perinci-Access-Lite","Perinci-AccessUtil","Perinci-CmdLine-Help","Perinci-CmdLine-Lite","Perinci-CmdLine-pause","Perinci-Object","Perinci-Result-Format-Lite","Perinci-Sub-CoerceArgs","Perinci-Sub-Complete","Perinci-Sub-ConvertArgs-Argv","Perinci-Sub-ConvertArgs-Array","Perinci-Sub-GetArgs-Argv","Perinci-Sub-GetArgs-Array","Perinci-Sub-Normalize","Perinci-Sub-To-CLIDocData","Perinci-Sub-Util","Progress-Any","Progress-Any-Output-TermProgressBarColor","Regexp-Stringify","Regexp-Wildcards","Rinci","Role-Tiny","Scalar-Util-Numeric-PP","String-Elide-Parts","String-Indent","String-LineNumber","String-PerlQuote","String-ShellQuote","String-Trim-More","String-Wildcard-Bash","Sub-Delete","Sub-Install","Text-ANSI-Util","Text-Table-Tiny","Text-sprintfn","Tie-IxHash","Time-Duration","Time-Duration-Parse-AsHash","TimeDate","Version-Util","WWW-PAUSE-Simple","experimental"]}; # PACKED_DISTS

1;
# ABSTRACT: A CLI for PAUSE (fatpacked version)

__END__

=pod

=encoding UTF-8

=head1 NAME

App::pause::FatPacked - A CLI for PAUSE (fatpacked version)

=head1 VERSION

This document describes version 0.52 of App::pause::FatPacked (from Perl distribution App-pause-FatPacked), released on 2016-01-17.

=head1 DESCRIPTION

This distribution is for testing/development purposes. Users should just install
the L<App::pause> distribution.

=head1 SEE ALSO

L<App::pause>

L<App::pause::Unpacked>

L<pause-fatpacked>

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/App-pause-FatPacked>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-App-pause-Fatpacked>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=App-pause-FatPacked>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2016 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
