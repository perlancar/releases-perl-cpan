package Sort::Sub::first_num_in_text;

our $DATE = '2016-12-16'; # DATE
our $VERSION = '0.002'; # VERSION

use 5.010001;
use strict;
use warnings;
require Sort::Sub::num_in_text;
*gen_sorter = \&Sort::Sub::num_in_text::gen_sorter;

1;
# ABSTRACT: Alias for Sort::Sub::num_in_text

__END__

=pod

=encoding UTF-8

=head1 NAME

Sort::Sub::first_num_in_text - Alias for Sort::Sub::num_in_text

=head1 VERSION

This document describes version 0.002 of Sort::Sub::first_num_in_text (from Perl distribution Sort-Sub-num_in_text), released on 2016-12-16.

=for Pod::Coverage ^(gen_sorter)$

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Sort-Sub-num_in_text>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Sort-Sub-num_in_text>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Sort-Sub-num_in_text>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 SEE ALSO

L<Sort::Sub::num_in_text>

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2016 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
