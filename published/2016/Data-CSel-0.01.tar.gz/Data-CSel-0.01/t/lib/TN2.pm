package # hide from PAUSE
    TN2;

use parent 'TN';

1;
