package # hide from PAUSE
    TN1;

use parent qw(TN);

1;
