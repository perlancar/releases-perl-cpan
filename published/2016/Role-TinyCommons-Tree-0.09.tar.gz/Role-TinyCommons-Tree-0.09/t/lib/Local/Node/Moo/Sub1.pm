package # hide from PAUSE
    Local::Node::Moo::Sub1;

use parent qw(Local::Node::Moo);

1;
