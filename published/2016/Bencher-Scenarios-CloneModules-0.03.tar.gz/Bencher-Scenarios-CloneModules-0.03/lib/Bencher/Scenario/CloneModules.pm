package Bencher::Scenario::CloneModules;

our $DATE = '2016-03-10'; # DATE
our $VERSION = '0.03'; # VERSION

use 5.010001;
use strict;
use warnings;

our $scenario = {
    summary => 'Benchmark various data cloning modules',
    participants => [
        {fcall_template=>'Clone::clone(<data>)'},
        {fcall_template=>'Clone::PP::clone(<data>)'},
        {fcall_template=>'Data::Clone::clone(<data>)'},
        {fcall_template=>'Sereal::Dclone::dclone(<data>)'},
        {fcall_template=>'Storable::dclone(<data>)'},
    ],
    datasets => [
        {name=>'array0'   , args=>{data=>[]}},
        {name=>'array1'   , args=>{data=>[1]}},
        {name=>'array10'  , args=>{data=>[1..10]}},
        {name=>'array100' , args=>{data=>[1..100]}},
        {name=>'array1k'  , args=>{data=>[1..1000]}},
        {name=>'array10k' , args=>{data=>[1..10_000]}},

        {name=>'hash1k'   , args=>{data=>{map {$_=>1} 1..1000}}},
        {name=>'hash10k'  , args=>{data=>{map {$_=>1} 1..10_000}}},
    ],
};

1;
# ABSTRACT: Benchmark various data cloning modules

__END__

=pod

=encoding UTF-8

=head1 NAME

Bencher::Scenario::CloneModules - Benchmark various data cloning modules

=head1 VERSION

This document describes version 0.03 of Bencher::Scenario::CloneModules (from Perl distribution Bencher-Scenarios-CloneModules), released on 2016-03-10.

=head1 SYNOPSIS

To run benchmark with default option:

 % bencher -m CloneModules

To run module startup overhead benchmark:

 % bencher --module-startup -m CloneModules

For more options (dump scenario, list/include/exclude/add participants, list/include/exclude/add datasets, etc), see L<bencher> or run C<bencher --help>.

=head1 BENCHMARKED MODULES

Version numbers shown below are the versions used when running the sample benchmark.

L<Clone> 0.38

L<Clone::PP> 1.06

L<Data::Clone> 0.004

L<Sereal::Dclone> 0.001

L<Storable> 2.53

=head1 BENCHMARK PARTICIPANTS

=over

=item * Clone::clone (perl_code)

Function call template:

 Clone::clone(<data>)



=item * Clone::PP::clone (perl_code)

Function call template:

 Clone::PP::clone(<data>)



=item * Data::Clone::clone (perl_code)

Function call template:

 Data::Clone::clone(<data>)



=item * Sereal::Dclone::dclone (perl_code)

Function call template:

 Sereal::Dclone::dclone(<data>)



=item * Storable::dclone (perl_code)

Function call template:

 Storable::dclone(<data>)



=back

=head1 BENCHMARK DATASETS

=over

=item * array0

=item * array1

=item * array10

=item * array100

=item * array1k

=item * array10k

=item * hash1k

=item * hash10k

=back

=head1 SAMPLE BENCHMARK RESULTS

Run on: perl: I<< v5.22.0 >>, CPU: I<< Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz (4 cores) >>, OS: I<< GNU/Linux Debian version 8.0 >>, OS kernel: I<< Linux version 3.16.0-4-amd64 >>.

Benchmark cloning a 10k-element array (C<< bencher -m CloneModules --include-datasets-json '["array10k"]' >>):

 +------------------------+-----------+-----------+------------+---------+---------+
 | participant            | rate (/s) | time (ms) | vs_slowest | errors  | samples |
 +------------------------+-----------+-----------+------------+---------+---------+
 | Clone::clone           | 2.9e+02   | 3.5       | 1          | 4.9e-06 | 20      |
 | Clone::PP::clone       | 615       | 1.63      | 2.14       | 1.3e-06 | 22      |
 | Storable::dclone       | 872       | 1.15      | 3.03       | 6.9e-07 | 20      |
 | Data::Clone::clone     | 1.79e+03  | 0.558     | 6.23       | 4.3e-07 | 20      |
 | Sereal::Dclone::dclone | 1.82e+03  | 0.55      | 6.31       | 2.7e-07 | 20      |
 +------------------------+-----------+-----------+------------+---------+---------+


Benchmark cloning a 10k-pair hash (C<< bencher -m CloneModules --include-datasets-json '["hash10k"]' >>):

 +------------------------+-----------+-----------+------------+---------+---------+
 | participant            | rate (/s) | time (ms) | vs_slowest | errors  | samples |
 +------------------------+-----------+-----------+------------+---------+---------+
 | Clone::clone           | 1.1e+02   | 8.8       | 1          | 1.4e-05 | 20      |
 | Clone::PP::clone       | 1.2e+02   | 8.3       | 1.1        | 1.9e-05 | 22      |
 | Storable::dclone       | 2e+02     | 5.1       | 1.7        | 1.3e-05 | 20      |
 | Data::Clone::clone     | 2.1e+02   | 4.8       | 1.8        | 1.2e-05 | 20      |
 | Sereal::Dclone::dclone | 2.5e+02   | 4         | 2.2        | 1.4e-05 | 20      |
 +------------------------+-----------+-----------+------------+---------+---------+


Benchmark module startup overhead (C<< bencher -m CloneModules --module-startup >>):

 +---------------------+-----------+------------------------+------------+---------+---------+
 | participant         | time (ms) | mod_overhead_time (ms) | vs_slowest | errors  | samples |
 +---------------------+-----------+------------------------+------------+---------+---------+
 | Sereal::Dclone      | 15        | 10.1                   | 1.1        | 4.1e-05 | 20      |
 | Storable            | 15        | 10.1                   | 1          | 7e-05   | 20      |
 | Clone               | 11        | 6.1                    | 1.3        | 2.5e-05 | 20      |
 | Data::Clone         | 9.7       | 4.8                    | 1.6        | 6.2e-05 | 20      |
 | Clone::PP           | 9.1       | 4.2                    | 1.7        | 3e-05   | 20      |
 | perl -e1 (baseline) | 4.9       | 0                      | 3.1        | 1.6e-05 | 20      |
 +---------------------+-----------+------------------------+------------+---------+---------+

=head1 DESCRIPTION

Packaging a benchmark script as a Bencher scenario makes it convenient to include/exclude/add participants/datasets (either via CLI or Perl code), send the result to a central repository, among others . See L<Bencher> and L<bencher> (CLI) for more details.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Bencher-Scenarios-CloneModules>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Bencher-Scenarios-CloneModules>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Bencher-Scenarios-CloneModules>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 SEE ALSO

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2016 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
