package Bencher::Scenario::Exporters::Exporting;

our $DATE = '2016-03-13'; # DATE
our $VERSION = '0.07'; # VERSION

use 5.010001;
use strict;
use warnings;

use File::Temp qw(tempdir);
use File::Slurper qw(write_text);

my $tempdir = tempdir(CLEANUP => 1);
write_text("$tempdir/ExampleExporter.pm", 'package ExampleExporter; use Exporter qw(import); our @EXPORT = qw(e1 e2 e3); sub e1{} sub e2{} sub e3{} 1;');
write_text("$tempdir/ExampleExporterLite.pm", 'package ExampleExporterLite; use Exporter::Lite qw(import); our @EXPORT = qw(e1 e2 e3); sub e1{} sub e2{} sub e3{} 1;');
write_text("$tempdir/ExamplePERLANCARExporterLite.pm", 'package ExamplePERLANCARExporterLite; use PERLANCAR::Exporter::Lite qw(import); our @EXPORT = qw(e1 e2 e3); sub e1{} sub e2{} sub e3{} 1;');

our $scenario = {
    summary => 'Benchmark overhead of exporting',

    modules => {
        'PERLANCAR::Exporter::Lite' => {version=>0.02},
    },

    participants => [
        {name=>"Exporter", cmdline => [$^X, "-I$tempdir", "-MExampleExporter", "-e1"]},
        {name=>"Exporter::Lite", cmdline => [$^X, "-I$tempdir", "-MExampleExporterLite", "-e1"]},
        {name=>"PERLANCAR::Exporter::Lite", cmdline => [$^X, "-I$tempdir", "-MExamplePERLANCARExporterLite", "-e1"]},
        {name=>"perl -e1 (baseline)", cmdline => [$^X, "-e1"]},
    ],
};

1;
# ABSTRACT: Benchmark overhead of exporting

__END__

=pod

=encoding UTF-8

=head1 NAME

Bencher::Scenario::Exporters::Exporting - Benchmark overhead of exporting

=head1 VERSION

This document describes version 0.07 of Bencher::Scenario::Exporters::Exporting (from Perl distribution Bencher-Scenarios-Exporters), released on 2016-03-13.

=head1 SYNOPSIS

To run benchmark with default option:

 % bencher -m Exporters::Exporting

For more options (dump scenario, list/include/exclude/add participants, list/include/exclude/add datasets, etc), see L<bencher> or run C<bencher --help>.

=head1 BENCHMARKED MODULES

Version numbers shown below are the versions used when running the sample benchmark.

L<PERLANCAR::Exporter::Lite> 0.02

=head1 BENCHMARK PARTICIPANTS

=over

=item * Exporter (command)

Command line:

 /zpool_host_mnt/mnt/home/s1/perl5/perlbrew/perls/perl-5.22.0/bin/perl -I/tmp/NB1luNyY3Z -MExampleExporter -e1



=item * Exporter::Lite (command)

Command line:

 /zpool_host_mnt/mnt/home/s1/perl5/perlbrew/perls/perl-5.22.0/bin/perl -I/tmp/NB1luNyY3Z -MExampleExporterLite -e1



=item * PERLANCAR::Exporter::Lite (command)

Command line:

 /zpool_host_mnt/mnt/home/s1/perl5/perlbrew/perls/perl-5.22.0/bin/perl -I/tmp/NB1luNyY3Z -MExamplePERLANCARExporterLite -e1



=item * perl -e1 (baseline) (command)

Command line:

 /zpool_host_mnt/mnt/home/s1/perl5/perlbrew/perls/perl-5.22.0/bin/perl -e1



=back

=head1 SAMPLE BENCHMARK RESULTS

Run on: perl: I<< v5.22.0 >>, CPU: I<< Intel(R) Core(TM) i7-4770 CPU @ 3.40GHz (4 cores) >>, OS: I<< GNU/Linux Debian version 8.0 >>, OS kernel: I<< Linux version 3.16.0-4-amd64 >>.

Benchmark with default options (C<< bencher -m Exporters::Exporting >>):

 +---------------------------+-----------+-----------+------------+---------+---------+
 | participant               | rate (/s) | time (ms) | vs_slowest | errors  | samples |
 +---------------------------+-----------+-----------+------------+---------+---------+
 | Exporter::Lite            | 2.4e+02   | 4.1       | 1          | 1.8e-05 | 20      |
 | Exporter                  | 3.5e+02   | 2.8       | 1.5        | 1.1e-05 | 20      |
 | PERLANCAR::Exporter::Lite | 3.7e+02   | 2.7       | 1.5        | 8e-06   | 20      |
 | perl -e1 (baseline)       | 4.3e+02   | 2.3       | 1.8        | 5e-06   | 20      |
 +---------------------------+-----------+-----------+------------+---------+---------+

=head1 DESCRIPTION

Packaging a benchmark script as a Bencher scenario makes it convenient to include/exclude/add participants/datasets (either via CLI or Perl code), send the result to a central repository, among others . See L<Bencher> and L<bencher> (CLI) for more details.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Bencher-Scenarios-Exporters>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Bencher-Scenarios-Exporters>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Bencher-Scenarios-Exporters>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2016 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
