package # hide from PAUSE
    Local::TOA;

use Tree::ObjectXS::Array qw(id);

1;
