package # hide from PAUSE
    Local::C1;

use Class::MaybeXSAccessor {
    accessors => [qw/foo bar/],
};

1;
