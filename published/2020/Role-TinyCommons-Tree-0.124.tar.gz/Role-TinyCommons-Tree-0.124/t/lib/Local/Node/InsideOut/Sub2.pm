package # hide from PAUSE
    Local::Node::InsideOut::Sub2;

use parent qw(Local::Node::InsideOut);

1;
