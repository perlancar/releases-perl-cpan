package Log::ger::Manual;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2020-03-06'; # DATE
our $DIST = 'Log-ger-Manual'; # DIST
our $VERSION = '0.032.000'; # VERSION

1;
# ABSTRACT: Manual for Log::ger

__END__

=pod

=encoding UTF-8

=head1 NAME

Log::ger::Manual - Manual for Log::ger

=head1 VERSION

version 0.032.000

=head1 DESCRIPTION

This distribution contains the following documentation pages:

=over

=item * L<Log::ger::Manual::FAQ>

=item * L<Log::ger::Manual::ForLog4perl>

=item * L<Log::ger::Manual::ForLogAny>

=item * L<Log::ger::Manual::ForLogContextual>

=item * L<Log::ger::Manual::ForLogDispatch>

=item * L<Log::ger::Manual::ForLogDispatchouli>

=item * L<Log::ger::Manual::Internals>

=item * L<Log::ger::Manual::Tips>

=item * L<Log::ger::Manual::Tutorial>

=item * L<Log::ger::Manual::Tutorial::100_WhatIsLogging>

=item * L<Log::ger::Manual::Tutorial::200_LoggingWithLogGer>

=item * L<Log::ger::Manual::Tutorial::300_Level>

=item * L<Log::ger::Manual::Tutorial::400_Output>

=item * L<Log::ger::Manual::Tutorial::410_Output_Screen>

=item * L<Log::ger::Manual::Tutorial::420_Output_File>

=item * L<Log::ger::Manual::Tutorial::421_Output_SimpleFile>

=item * L<Log::ger::Manual::Tutorial::422_Output_FileWriteRotate>

=item * L<Log::ger::Manual::Tutorial::430_Output_Syslog>

=item * L<Log::ger::Manual::Tutorial::470_Output_DirwriteRotate>

=item * L<Log::ger::Manual::Tutorial::481_Output_Composite>

=item * L<Log::ger::Manual::Tutorial::490_WritingAnOutputPlugin>

=item * L<Log::ger::Manual::Tutorial::500_Category>

=item * L<Log::ger::Manual::Tutorial::600_Format>

=item * L<Log::ger::Manual::Tutorial::610_Format_Block>

=item * L<Log::ger::Manual::Tutorial::690_WritingAFormatPlugin>

=item * L<Log::ger::Manual::Tutorial::700_Layout>

=item * L<Log::ger::Manual::Tutorial::790_WritingALayoutPlugin>

=item * L<Log::ger::Manual::Tutorial::800_Other_Plugin>

=item * L<Log::ger::Manual::Tutorial::810_Plugin_OptAway>

=item * L<Log::ger::Manual::Tutorial::890_WritingAPlugin>

=item * L<Log::ger::Manual::Tutorial::900_OtherTopics>

=item * L<Log::ger::Manual::Tutorial::910_Performance>

=item * L<Log::ger::Manual::Tutorial::920_Security>

=item * L<Log::ger::Manual::Tutorial::931_UsingInApplication>

=item * L<Log::ger::Manual::Tutorial::932_UsingWithLogGerApp>

=item * L<Log::ger::Manual::Tutorial::933_UsingWithPerinciCmdLine>

=item * L<Log::ger::Manual::Tutorial::934_UsingWithMooMoose>

=back

Start with L<Log::ger::Manual::Tutorial>.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2020, 2019, 2018, 2017 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
