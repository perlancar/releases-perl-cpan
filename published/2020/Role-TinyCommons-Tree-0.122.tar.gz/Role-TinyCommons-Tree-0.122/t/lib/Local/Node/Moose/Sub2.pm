package # hide from PAUSE
    Local::Node::Moose::Sub2;

use Moose;
extends 'Local::Node::Moose';

1;
