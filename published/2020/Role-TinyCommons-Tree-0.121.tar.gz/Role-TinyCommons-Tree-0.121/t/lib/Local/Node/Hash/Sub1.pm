package # hide from PAUSE
    Local::Node::Hash::Sub1;

use parent qw(Local::Node::Hash);

1;
