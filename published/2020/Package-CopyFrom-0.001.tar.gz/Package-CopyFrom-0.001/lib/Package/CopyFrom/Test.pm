package Package::CopyFrom::Test;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2020-02-15'; # DATE
our $DIST = 'Package-CopyFrom'; # DIST
our $VERSION = '0.001'; # VERSION

our $FOO = "foo";
our $BAR = "bar";
our @FOO = ("foo", "FOO");
our @BAR = ("bar", "BAR");
our %FOO = (foo=>1, FOO=>2);
our %BAR = (bar=>1, BAR=>2);

our @ISA = qw(Exporter);
our @EXPORT_OK = qw(f1);
our %EXPORT_TAGS = (T1 => [qw/f1 f2/], T2 => [qw/f2 f3/]);

sub f1 { return $_[0]**2 }
sub f2 { return $_[0]**3 }
sub f3 {}

1;

# ABTRACT: A dummy module for testing

__END__

=pod

=encoding UTF-8

=head1 NAME

Package::CopyFrom::Test

=head1 VERSION

This document describes version 0.001 of Package::CopyFrom::Test (from Perl distribution Package-CopyFrom), released on 2020-02-15.

=for Pod::Coverage ^(.+)$

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Package-CopyFrom>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Package-CopyFrom>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Package-CopyFrom>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2020 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
