package Acme::SHARYANTO::TestDevRelease;

our $VERSION = '0.01'; # VERSION

1;
# ABSTRACT: Test dev release

__END__
=pod

=head1 NAME

Acme::SHARYANTO::TestDevRelease - Test dev release

=head1 VERSION

version 0.01

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

