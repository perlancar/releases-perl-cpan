package Rinci;

our $VERSION = '1.1.36'; # VERSION

1;
# ABSTRACT: Language-neutral metadata for your code

__END__

=pod

=encoding utf-8

=head1 NAME

Rinci - Language-neutral metadata for your code

=head1 VERSION

version 1.1.36

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 DESCRIPTION

=head1 FUNCTIONS


None are exported by default, but they are exportable.

=cut
