package Borang;

use 5.010001;

our $VERSION = '0.00'; # VERSION

1;
# ABSTRACT: Yet another form handling module

__END__

=pod

=head1 NAME

Borang - Yet another form handling module

=head1 VERSION

version 0.00

=head1 DESCRIPTION

NOT YET IMPLEMENTED.

=head1 FAQ

=head2 Why the name?

Borang means form in Indonesian and is currently seldom used in daily
conversations.

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
