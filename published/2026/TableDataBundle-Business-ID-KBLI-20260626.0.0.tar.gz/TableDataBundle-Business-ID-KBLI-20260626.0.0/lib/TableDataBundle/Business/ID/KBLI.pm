# no code
## no critic: TestingAndDebugging::RequireUseStrict
package TableDataBundle::Business::ID::KBLI;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2026-06-26'; # DATE
our $DIST = 'TableDataBundle-Business-ID-KBLI'; # DIST
our $VERSION = '20260626.0.0'; # VERSION

1;
# ABSTRACT: Collection of TableData:: modules related to KBLI (Kode Baku Lapangan Usaha, a.k.a. Standard Code of Business Field)

__END__

=pod

=encoding UTF-8

=head1 NAME

TableDataBundle::Business::ID::KBLI - Collection of TableData:: modules related to KBLI (Kode Baku Lapangan Usaha, a.k.a. Standard Code of Business Field)

=head1 VERSION

This document describes version 20260626.0.0 of TableDataBundle::Business::ID::KBLI (from Perl distribution TableDataBundle-Business-ID-KBLI), released on 2026-06-26.

=head1 DESCRIPTION

This distribution contains the following L<TableData>:: modules:

=over

=item * L<TableData::Business::ID::KBLI::2020::Category>

=item * L<TableData::Business::ID::KBLI::2020::Code>

=item * L<TableData::Business::ID::KBLI::2025::Code>

=back

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/TableDataBundle-Business-ID-KBLI>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-TableDataBundle-Business-ID-KBLI>.

=head1 SEE ALSO

L<TableData>

L<https://oss.go.id/informasi/kbli-kode>

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTOR

=for stopwords perlancar (on netbook-dell-xps13)

perlancar (on netbook-dell-xps13) <perlancar@gmail.com>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2026 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=TableDataBundle-Business-ID-KBLI>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
