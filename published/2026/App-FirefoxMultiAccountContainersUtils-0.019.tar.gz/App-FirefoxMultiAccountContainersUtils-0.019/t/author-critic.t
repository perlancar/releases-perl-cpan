#!perl

BEGIN {
  unless ($ENV{AUTHOR_TESTING}) {
    print qq{1..0 # SKIP these tests are for testing by the author\n};
    exit
  }
}


use strict;
use warnings;

# this test was generated with Dist::Zilla::Plugin::Test::Perl::Critic::Subset 3.001.006

use Test::Perl::Critic (-profile => "") x!! -e "";

my $filenames = ['lib/App/FirefoxMultiAccountContainersUtils.pm','script/firefox-container','script/firefox-mua-add-container','script/firefox-mua-dump-identities-json','script/firefox-mua-list-containers','script/firefox-mua-modify-containers','script/firefox-mua-sort-containers','script/open-firefox-container'];
unless ($filenames && @$filenames) {
    $filenames = -d "blib" ? ["blib"] : ["lib"];
}

all_critic_ok(@$filenames);
