package App::FilenameKeyValueUtils;

use strict;
use warnings;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2026-05-28'; # DATE
our $DIST = 'App-FilenameKeyValueUtils'; # DIST
our $VERSION = '0.002'; # VERSION

our %SPEC;

1;
# ABSTRACT: CLIs for Filename::KeyValue

__END__

=pod

=encoding UTF-8

=head1 NAME

App::FilenameKeyValueUtils - CLIs for Filename::KeyValue

=head1 VERSION

This document describes version 0.002 of App::FilenameKeyValueUtils (from Perl distribution App-FilenameKeyValueUtils), released on 2026-05-28.

=head1 SYNOPSIS

=head1 DESCRIPTION

This distribution includes several utilities related to L<Filename::KeyValue>:

=over

=item * L<modify-keyvalue-filename>

=item * L<normalize-keyvalue-filename>

=item * L<parse-keyvalue-filename>

=item * L<rename-add-keyvalue-filenames>

=item * L<rename-remove-keyvalue-filenames>

=back

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/App-FilenameKeyValueUtils>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-App-FilenameKeyValueUtils>.

=head1 SEE ALSO

L<Filename::KeyValue>

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTOR

=for stopwords perlancar

perlancar <perlancar@gmail.com>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2026 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=App-FilenameKeyValueUtils>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
