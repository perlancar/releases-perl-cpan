package Business::ID::KTP;
our $VERSION = '0.02';
# ABSTRACT: See Business::ID::NIK instead


1;

__END__
=pod

=head1 NAME

Business::ID::KTP - See Business::ID::NIK instead

=head1 VERSION

version 0.02

=head1 SEE ALSO

L<Business::ID::NIK>

=head1 AUTHOR

  Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2010 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

