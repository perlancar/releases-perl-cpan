* TODO [2015-02-05 Thu] pausesimple: list: add filter option --del --nodel
* TODO [2015-02-05 Thu] pausesimple: list: add filter query, e.g. 'pause list Foo'
* TODO [2015-02-05 Thu] pausesimple: list: add sorting options
* TODO [2015-02-05 Thu] pausesimple: implement the rest of the functions: delete_files, undelete_files, reindex, set_password, set_account_info
* TODO [2015-02-05 Thu] pausesimple: implement clean_old_releases function
* TODO [2015-02-05 Thu] pausesimple: implement (get_)?account_info function
* TODO [2015-02-05 Thu] pausesimple: implement permission-related functions [#E]

  i seldom use this though
