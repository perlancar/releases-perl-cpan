* TODO [2015-01-03 Sat] wordlist: In -l --detail, show summary (extract from POD Name or # ABSTRACT).
* TODO [2015-01-03 Sat] wordlist: Option --random (plus -n) to generate (or n) random word(s).
* TODO [2015-01-03 Sat] wordlist: Option -v (--invert-match) like grep.
* TODO [2015-01-03 Sat] wordlist: Implement -n (max result).
* IDEA [2014-12-15 Mon] wordlist: implement opsi -U, -L, -I (pake xpan or later Complete::CPAN utk provide completion)
