* TODO [2015-01-09 Fri] cpansqlite-cm: recursive/multi-level should be breadth-first and not depth-first

  otherwise the output is slightly weird:
  

      $ cpandb-cpanmeta deps Rinci -l2
      +---------+----------+
      | module  | version  |
      | DefHash | v1.0.6   |
      |   perl  | 5.010001 |
      +---------+----------+
  
  while we would normally want:
  

      $ cpandb-cpanmeta deps Rinci -l2
      +---------+----------+
      | module  | version  |
      | DefHash | v1.0.6   |
      | perl    | 5.010001 |
      +---------+----------+
  

* TODO [2015-01-08 Thu] cpansqlite-cm: deps: numify/normalize version?
* TODO [2015-01-08 Thu] cpansqlite-cm: extract more data: distribution abstract, license, release status, resources.

  Perhaps put it in a separate table dist_infos or something.
