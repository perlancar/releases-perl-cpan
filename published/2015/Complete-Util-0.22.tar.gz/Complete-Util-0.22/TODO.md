* TODO [2015-01-09 Fri] compfile, compriap, computil: when Complete's OPT_DIG_LEAF option has been rethought and no longer experimental, expose it
* TODO [2014-12-01 Mon] computil: complete_file: opsi utk suffix atau wildcard (simpler than coderef)
