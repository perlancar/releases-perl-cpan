* TODO [2015-01-03 Sat] ansitable: Most color themes still look crappy on 256 colors (I develop on Konsole).
* TODO [2015-01-03 Sat] ansitable: Attributes: cell_wrap? (a shorter/nicer version for formats => [[wrap => {ansi=>1, mb=>1}]]).
* TODO [2015-01-03 Sat] ansitable: Column styles: show_{left,right}_border (shorter name? {l,r}border?)
* TODO [2015-01-03 Sat] ansitable: Row styles: show_{top,bottom}_border (shorter name? {t,b}border?)
* TODO [2015-01-03 Sat] ansitable: row span? column span?
* TODO [2014-12-12 Jum] ansitable: pod: lengkapi examples dengan sample output (gunakan DZP::InstallCodeResult) [#E]
