* TODO [2015-01-03 Sat] compbashhist: Option to search only for the last N hours/days of history (using timestamp in bash history).
* TODO [2015-01-03 Sat] compbashhist: Find recent subcommands? e.g. git {status,log,commit}
* TODO [2015-01-03 Sat] compbashhist: Parse complex bash commands
