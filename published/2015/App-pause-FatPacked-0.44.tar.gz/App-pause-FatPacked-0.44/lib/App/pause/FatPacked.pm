package App::pause::FatPacked;

our $DATE = '2015-07-28'; # DATE
our $VERSION = '0.44'; # VERSION

our @PACKED_MODULES = @{["Algorithm::Dependency","Algorithm::Dependency::Item","Algorithm::Dependency::Ordered","Algorithm::Dependency::Source","Algorithm::Dependency::Source::File","Algorithm::Dependency::Source::HoA","Algorithm::Dependency::Source::Invert","Algorithm::Dependency::Weight","App::pause::FatPacked","Clone::PP","Color::ANSI::Util","Complete","Complete::Bash","Complete::Fish","Complete::Getopt::Long","Complete::Path","Complete::Tcsh","Complete::Util","Complete::Zsh","Compress::Raw::Bzip2","Compress::Raw::Zlib","Compress::Zlib","Config::IOD::Base","Config::IOD::Expr","Config::IOD::Reader","Data::Check::Structure","Data::Clean::Base","Data::Clean::FromJSON","Data::Clean::JSON","Data::Dmp","Data::Dump","Data::Dump::FilterContext","Data::Dump::Filtered","Data::Dump::Trace","Data::ModeMerge","Data::ModeMerge::Config","Data::ModeMerge::Mode::ADD","Data::ModeMerge::Mode::Base","Data::ModeMerge::Mode::CONCAT","Data::ModeMerge::Mode::DELETE","Data::ModeMerge::Mode::KEEP","Data::ModeMerge::Mode::NORMAL","Data::ModeMerge::Mode::SUBTRACT","Data::Sah","Data::Sah::Compiler","Data::Sah::Compiler::Prog","Data::Sah::Compiler::Prog::TH","Data::Sah::Compiler::Prog::TH::all","Data::Sah::Compiler::Prog::TH::any","Data::Sah::Compiler::TH","Data::Sah::Compiler::TextResultRole","Data::Sah::Compiler::human","Data::Sah::Compiler::human::TH","Data::Sah::Compiler::human::TH::Comparable","Data::Sah::Compiler::human::TH::HasElems","Data::Sah::Compiler::human::TH::Sortable","Data::Sah::Compiler::human::TH::all","Data::Sah::Compiler::human::TH::any","Data::Sah::Compiler::human::TH::array","Data::Sah::Compiler::human::TH::bool","Data::Sah::Compiler::human::TH::buf","Data::Sah::Compiler::human::TH::cistr","Data::Sah::Compiler::human::TH::code","Data::Sah::Compiler::human::TH::date","Data::Sah::Compiler::human::TH::duration","Data::Sah::Compiler::human::TH::float","Data::Sah::Compiler::human::TH::hash","Data::Sah::Compiler::human::TH::int","Data::Sah::Compiler::human::TH::num","Data::Sah::Compiler::human::TH::obj","Data::Sah::Compiler::human::TH::re","Data::Sah::Compiler::human::TH::str","Data::Sah::Compiler::human::TH::undef","Data::Sah::Compiler::js","Data::Sah::Compiler::js::TH","Data::Sah::Compiler::js::TH::all","Data::Sah::Compiler::js::TH::any","Data::Sah::Compiler::js::TH::array","Data::Sah::Compiler::js::TH::bool","Data::Sah::Compiler::js::TH::buf","Data::Sah::Compiler::js::TH::cistr","Data::Sah::Compiler::js::TH::code","Data::Sah::Compiler::js::TH::date","Data::Sah::Compiler::js::TH::float","Data::Sah::Compiler::js::TH::hash","Data::Sah::Compiler::js::TH::int","Data::Sah::Compiler::js::TH::num","Data::Sah::Compiler::js::TH::obj","Data::Sah::Compiler::js::TH::re","Data::Sah::Compiler::js::TH::str","Data::Sah::Compiler::js::TH::undef","Data::Sah::Compiler::perl","Data::Sah::Compiler::perl::TH","Data::Sah::Compiler::perl::TH::all","Data::Sah::Compiler::perl::TH::any","Data::Sah::Compiler::perl::TH::array","Data::Sah::Compiler::perl::TH::bool","Data::Sah::Compiler::perl::TH::buf","Data::Sah::Compiler::perl::TH::cistr","Data::Sah::Compiler::perl::TH::code","Data::Sah::Compiler::perl::TH::date","Data::Sah::Compiler::perl::TH::duration","Data::Sah::Compiler::perl::TH::float","Data::Sah::Compiler::perl::TH::hash","Data::Sah::Compiler::perl::TH::int","Data::Sah::Compiler::perl::TH::num","Data::Sah::Compiler::perl::TH::obj","Data::Sah::Compiler::perl::TH::re","Data::Sah::Compiler::perl::TH::str","Data::Sah::Compiler::perl::TH::undef","Data::Sah::Human","Data::Sah::JS","Data::Sah::Lang","Data::Sah::Lang::fr_FR","Data::Sah::Lang::id_ID","Data::Sah::Lang::zh_CN","Data::Sah::Normalize","Data::Sah::Type::BaseType","Data::Sah::Type::Comparable","Data::Sah::Type::HasElems","Data::Sah::Type::Sortable","Data::Sah::Type::all","Data::Sah::Type::any","Data::Sah::Type::array","Data::Sah::Type::bool","Data::Sah::Type::buf","Data::Sah::Type::cistr","Data::Sah::Type::code","Data::Sah::Type::date","Data::Sah::Type::duration","Data::Sah::Type::float","Data::Sah::Type::hash","Data::Sah::Type::int","Data::Sah::Type::num","Data::Sah::Type::obj","Data::Sah::Type::re","Data::Sah::Type::str","Data::Sah::Type::undef","Data::Sah::Util::Func","Data::Sah::Util::Role","Data::Sah::Util::Type","Data::Sah::Util::Type::Date","Data::Sah::Util::TypeX","Date::Format","Date::Parse","DefHash","Encode::Locale","Exporter::Shiny","Exporter::Tiny","File::GlobMapper","File::Which","Function::Fallback::CoreOrPP","Getopt::Long::Negate::EN","Getopt::Long::Util","HTTP::Config","HTTP::Date","HTTP::Headers","HTTP::Headers::Auth","HTTP::Headers::ETag","HTTP::Headers::Util","HTTP::Message","HTTP::Request","HTTP::Request::Common","HTTP::Response","HTTP::Status","HTTP::Tiny","HTTP::Tiny::UNIX","IO::Compress::Adapter::Bzip2","IO::Compress::Adapter::Deflate","IO::Compress::Adapter::Identity","IO::Compress::Base","IO::Compress::Base::Common","IO::Compress::Bzip2","IO::Compress::Deflate","IO::Compress::Gzip","IO::Compress::Gzip::Constants","IO::Compress::RawDeflate","IO::Compress::Zip","IO::Compress::Zip::Constants","IO::Compress::Zlib::Constants","IO::Compress::Zlib::Extra","IO::HTML","IO::Uncompress::Adapter::Bunzip2","IO::Uncompress::Adapter::Identity","IO::Uncompress::Adapter::Inflate","IO::Uncompress::AnyInflate","IO::Uncompress::AnyUncompress","IO::Uncompress::Base","IO::Uncompress::Bunzip2","IO::Uncompress::Gunzip","IO::Uncompress::Inflate","IO::Uncompress::RawInflate","IO::Uncompress::Unzip","IOD","JSON","LWP::MediaTypes","Lingua::EN::Numbers::Ordinate","Lingua::EN::PluralToSingular","List::MoreUtils","List::MoreUtils::PP","List::MoreUtils::XS","Log::Any","Log::Any::Adapter","Log::Any::Adapter::Base","Log::Any::Adapter::File","Log::Any::Adapter::Null","Log::Any::Adapter::Screen","Log::Any::Adapter::Stderr","Log::Any::Adapter::Stdout","Log::Any::Adapter::Test","Log::Any::Adapter::Util","Log::Any::IfLOG","Log::Any::Manager","Log::Any::Proxy","Log::Any::Proxy::Test","Log::Any::Test","Mo","Mo::Golf","Mo::Inline","Mo::Moose","Mo::Mouse","Mo::build","Mo::builder","Mo::chain","Mo::coerce","Mo::default","Mo::exporter","Mo::import","Mo::importer","Mo::is","Mo::nonlazy","Mo::option","Mo::required","Mo::xs","Module::Path::More","Monkey::Patch::Action","Monkey::Patch::Action::Handle","PERLANCAR::File::HomeDir","Params::Util","Perinci::Access::Lite","Perinci::AccessUtil","Perinci::CmdLine::Base","Perinci::CmdLine::Help","Perinci::CmdLine::Lite","Perinci::CmdLine::Util::Config","Perinci::CmdLine::pause","Perinci::Object","Perinci::Object::EnvResult","Perinci::Object::EnvResultMulti","Perinci::Object::Function","Perinci::Object::Metadata","Perinci::Object::Package","Perinci::Object::ResMeta","Perinci::Object::Variable","Perinci::Sub::ArgEntity","Perinci::Sub::CoerceArgs","Perinci::Sub::Complete","Perinci::Sub::ConvertArgs::Argv","Perinci::Sub::ConvertArgs::Array","Perinci::Sub::GetArgs::Argv","Perinci::Sub::GetArgs::Array","Perinci::Sub::Normalize","Perinci::Sub::To::CLIDocData","Perinci::Sub::Util","Perinci::Sub::Util::ResObj","Perinci::Sub::Util::Sort","Progress::Any","Progress::Any::Output","Progress::Any::Output::Null","Progress::Any::Output::TermProgressBarColor","Regexp::Stringify","Regexp::Wildcards","Riap","Rinci","Role::Tiny","Role::Tiny::With","Sah","Sah::Schema::DefHash","Sah::Schema::Rinci","Sah::Schema::Sah","Scalar::Util::Numeric::PP","String::Elide::Parts","String::Indent","String::LineNumber","String::PerlQuote","String::ShellQuote","String::Trim::More","String::Wildcard::Bash","Sub::Delete","Sub::Install","Term::ReadKey","Test::Config::IOD::Common","Test::Data::Sah","Text::ANSI::Util","Text::Table::Tiny","Text::WideChar::Util","Text::sprintfn","Tie::IxHash","Time::Duration","Time::Zone","Unicode::LineBreak","Version::Util","WWW::PAUSE::Simple","YAML::Old","YAML::Old::Dumper","YAML::Old::Dumper::Base","YAML::Old::Error","YAML::Old::Loader","YAML::Old::Loader::Base","YAML::Old::Marshall","YAML::Old::Mo","YAML::Old::Node","YAML::Old::Tag","YAML::Old::Types","experimental"]}; # PACKED_MODULES
our @PACKED_DISTS = @{["Algorithm-Dependency","App-pause-FatPacked","Clone-PP","Color-ANSI-Util","Complete","Complete-Bash","Complete-Fish","Complete-Getopt-Long","Complete-Path","Complete-Tcsh","Complete-Util","Complete-Zsh","Compress-Raw-Bzip2","Compress-Raw-Zlib","Config-IOD-Reader","Data-Check-Structure","Data-Clean-JSON","Data-Dmp","Data-Dump","Data-ModeMerge","Data-Sah","Data-Sah-Normalize","Data-Sah-Util-Type","DefHash","Encode-Locale","Exporter-Tiny","File-Which","Function-Fallback-CoreOrPP","Getopt-Long-Negate-EN","Getopt-Long-Util","HTTP-Date","HTTP-Message","HTTP-Tiny","HTTP-Tiny-UNIX","IO-Compress","IO-HTML","IOD","JSON","LWP-MediaTypes","Lingua-EN-Numbers-Ordinate","Lingua-EN-PluralToSingular","List-MoreUtils","Log-Any","Log-Any-Adapter-Screen","Log-Any-IfLOG","Mo","Module-Path-More","Monkey-Patch-Action","PERLANCAR-File-HomeDir","Params-Util","Perinci-Access-Lite","Perinci-AccessUtil","Perinci-CmdLine-Help","Perinci-CmdLine-Lite","Perinci-CmdLine-pause","Perinci-Object","Perinci-Sub-ArgEntity","Perinci-Sub-CoerceArgs","Perinci-Sub-Complete","Perinci-Sub-ConvertArgs-Argv","Perinci-Sub-ConvertArgs-Array","Perinci-Sub-GetArgs-Argv","Perinci-Sub-GetArgs-Array","Perinci-Sub-Normalize","Perinci-Sub-To-CLIDocData","Perinci-Sub-Util","Progress-Any","Progress-Any-Output-TermProgressBarColor","Regexp-Stringify","Regexp-Wildcards","Riap","Rinci","Role-Tiny","Sah","Scalar-Util-Numeric-PP","String-Elide-Parts","String-Indent","String-LineNumber","String-PerlQuote","String-ShellQuote","String-Trim-More","String-Wildcard-Bash","Sub-Delete","Sub-Install","TermReadKey","Text-ANSI-Util","Text-Table-Tiny","Text-WideChar-Util","Text-sprintfn","Tie-IxHash","Time-Duration","TimeDate","Unicode-LineBreak","Version-Util","WWW-PAUSE-Simple","YAML-Old","experimental"]}; # PACKED_DISTS

1;
# ABSTRACT: A CLI for PAUSE (fatpacked version)

__END__

=pod

=encoding UTF-8

=head1 NAME

App::pause::FatPacked - A CLI for PAUSE (fatpacked version)

=head1 VERSION

This document describes version 0.44 of App::pause::FatPacked (from Perl distribution App-pause-FatPacked), released on 2015-07-28.

=head1 DESCRIPTION

This distribution is for testing/development purposes. Users should just install
the L<App::pause> distribution.

=head1 SEE ALSO

L<App::pause>

L<App::pause::Unpacked>

L<pause-fatpacked>

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/App-pause-FatPacked>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-App-pause-Fatpacked>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=App-pause-FatPacked>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2015 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
