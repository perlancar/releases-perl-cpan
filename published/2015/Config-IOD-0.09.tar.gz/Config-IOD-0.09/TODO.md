* TODO [2015-03-12 Thu] ciod: delete_section: how about directive lines like !merge, should they be deleted too?
* TODO [2015-03-12 Thu] ciodr, ciod: add attribute: allow_duplicate_section
* TODO [2015-03-12 Kam] ciod: insert_section: option before_section, after_section (right before/after the first occurence of section(s) named ...)
* TODO [2015-03-12 Kam] ciod: insert_key: option encode_json?

  so we can insert undef, array etc more conveniently

* TODO [2015-03-12 Kam] ciod: insert_key: fix implementation of option top
* TODO [2015-03-12 Kam] ciod: update_key

  - will do nothing if key doesn't exist
  - what about multiple occurences?

* TODO [2015-03-12 Kam] ciod: insert_key: option comment

  - not all comments are allowed? depends on encoding?

* TODO [2015-03-12 Kam] ciod: insert_key: option before_key, after_key

  - not all comments are allowed? depends on encoding?

* TODO [2015-03-11 Wed] le, ciod, ciodr: take a look at Math::Calc::Parser, its code has a simple ad-hoc regexp-based parser which can perhaps be used

  the parser can only parse math operations, e.g. + * / % ^ , parenthesis
  functioncall. but we can extend this a bit.
  
  the upside is: the code is simple and startup overhead is low (<0.01s), compared
  to using Marpa or Regexp::Grammars.
  
  it uses Math::Complex, the module should be delay-loaded.

* TODO [2015-01-03 Sat] ciod: Option to only allow include if owner is the same.
