package Module::CoreList::More;

our $DATE = '2015-05-06'; # DATE
our $VERSION = '0.06'; # VERSION

use 5.010001;
use strict;
use warnings;

use Module::CoreList;

sub _firstidx {
    my ($item, $ary) = @_;
    for (0..@$ary-1) {
       return $_ if $ary->[$_] eq $item;
    }
    -1;
}

# construct our own %delta from Module::CoreList's %delta. our version is a
# linear "linked list" (e.g. %delta{5.017} is a delta against %delta{5.016003}
# instead of %delta{5.016}. also, version numbers are cleaned (some versions in
# Module::CoreList has trailing whitespaces or alphas)

# the same for our own %released (version numbers in keys are canonicalized)

our %delta;
our %released;
my %rel_orig_formats;
{
    # first let's only stored the canonical format of release versions
    # (Module::Core stores "5.01" as well as "5.010000"), for less headache
    # let's just store "5.010000"
    my %releases;
    for (sort keys %Module::CoreList::delta) {
        my $canonical = sprintf "%.6f", $_;
        next if $releases{$canonical};
        $releases{$canonical} = $Module::CoreList::delta{$_};
        $released{$canonical} = $Module::CoreList::released{$_};
        $rel_orig_formats{$canonical} = $_;
    }
    my @releases = sort keys %releases;

    for my $i (0..@releases-1) {
        my $reldelta = $releases{$releases[$i]};
        my $delta_from = $reldelta->{delta_from};
        my $changed = {};
        my $removed = {};
        # make sure that %delta will be linear "linked list" by release versions
        if ($delta_from && $delta_from != $releases[$i-1]) {
            $delta_from = sprintf "%.6f", $delta_from;
            my $i0 = _firstidx($delta_from, \@releases);
            #say "D: delta_from jumps from $delta_from (#$i0) -> $releases[$i] (#$i)";
            # accumulate changes between delta at releases #($i0+1) and #($i-1),
            # subtract them from delta at #($i)
            my $changed_between = {};
            my $removed_between = {};
            for my $j ($i0+1 .. $i-1) {
                my $reldelta_between = $releases{$releases[$j]};
                for (keys %{$reldelta_between->{changed}}) {
                    $changed_between->{$_} = $reldelta_between->{changed}{$_};
                    delete $removed_between->{$_};
                }
                for (keys %{$reldelta_between->{removed}}) {
                    $removed_between->{$_} = $reldelta_between->{removed}{$_};
                }
            }
            for (keys %{$reldelta->{changed}}) {
                next if exists($changed_between->{$_}) &&
                    !defined($changed_between->{$_}) && !defined($reldelta->{changed}{$_}) || # both undef
                    defined ($changed_between->{$_}) && defined ($reldelta->{changed}{$_}) && $changed_between->{$_} eq $reldelta->{changed}{$_}; # both defined & equal
                $changed->{$_} = $reldelta->{changed}{$_};
            }
            for (keys %{$reldelta->{removed}}) {
                next if $removed_between->{$_};
                $removed->{$_} = $reldelta->{removed}{$_};
            }
        } else {
            $changed = { %{$reldelta->{changed}} };
            $removed = { %{$reldelta->{removed} // {}} };
        }

        # clean version numbers
        for my $k (keys %$changed) {
            for ($changed->{$k}) {
                next unless defined;
                s/\s+$//; # eliminate trailing space
                # for "alpha" version, turn trailing junk such as letters to _
                # plus a number based on the first junk char
                s/([^.0-9_])[^.0-9_]*$/'_'.sprintf('%03d',ord $1)/e;
            }
        }
        $delta{$releases[$i]} = {
            changed => $changed,
            removed => $removed,
        };
    }
}

sub first_release {
    my $module = shift;
    $module = shift if eval { $module->isa(__PACKAGE__) } && @_ > 0 && defined($_[0]) && $_[0] =~ /^\w/;

    my $ans;
  RELEASE:
    for my $rel (sort keys %delta) {
        my $delta = $delta{$rel};

        # we haven't found the first release where module is included
        if (exists $delta->{changed}{$module}) {
            $ans = $rel_orig_formats{$rel};
            last;
        }
    }

    return wantarray ? ($ans) : $ans;
}

sub first_release_by_date {
    my $module = shift;
    $module = shift if eval { $module->isa(__PACKAGE__) } && @_ > 0 && defined($_[0]) && $_[0] =~ /^\w/;

    my $ans;
  RELEASE:
    for my $rel (sort {$released{$a} cmp $released{$b}} keys %delta) {
        my $delta = $delta{$rel};

        # we haven't found the first release where module is included
        if (exists $delta->{changed}{$module}) {
            $ans = $rel_orig_formats{$rel};
            last;
        }
    }

    return wantarray ? ($ans) : $ans;
};

# Use a private coderef to eliminate code duplication

my $is_core = sub {
    my $all = shift;
    my $module = shift;
    $module = shift if eval { $module->isa(__PACKAGE__) } && @_ > 0 && defined($_[0]) && $_[0] =~ /^\w/;
    my ($module_version, $perl_version);

    $module_version = shift if @_ > 0;
    $perl_version   = @_ > 0 ? shift : $];

    my $mod_exists = 0;
    my $mod_ver; # module version at each perl release, -1 means doesn't exist

  RELEASE:
    for my $rel (sort keys %delta) {
        last if $all && $rel > $perl_version; # this is the difference with is_still_core()

        my $reldelta = $delta{$rel};

        if ($rel > $perl_version) {
            if ($reldelta->{removed}{$module}) {
                $mod_exists = 0;
            } else {
                next;
            }
        }

        if (exists $reldelta->{changed}{$module}) {
            $mod_exists = 1;
            $mod_ver = $reldelta->{changed}{$module};
        } elsif ($reldelta->{removed}{$module}) {
            $mod_exists = 0;
        }
    }

    if ($mod_exists) {
        if (defined $module_version) {
            return 0 unless defined $mod_ver;
            return version->parse($mod_ver) >= version->parse($module_version) ? 1:0;
        }
        return 1;
    } else {
        return 0;
    }
};


my $list_core_modules = sub {
    my $all = shift;
    my $class = shift if @_ && eval { $_[0]->isa(__PACKAGE__) };
    my $perl_version = @_ ? shift : $];

    my %added;
    my %removed;

  RELEASE:
    for my $rel (sort keys %delta) {
        last if $all && $rel > $perl_version; # this is the difference with list_still_core_modules()

        my $delta = $delta{$rel};

        next unless $delta->{changed};
        for my $mod (keys %{$delta->{changed}}) {
            # module has been removed between perl_version..latest, skip
            next if $removed{$mod};

            if (exists $added{$mod}) {
                # module has been added in a previous version, update first
                # version
                $added{$mod} = $delta->{changed}{$mod} if $rel <= $perl_version;
            } else {
                # module is first added after perl_version, skip
                next if $rel > $perl_version;

                $added{$mod} = $delta->{changed}{$mod};
            }
        }
        next unless $delta->{removed};
        for my $mod (keys %{$delta->{removed}}) {
            delete $added{$mod};
            # module has been removed between perl_version..latest, mark it
            $removed{$mod}++ if $rel >= $perl_version;
        }

    }
    %added;
};

sub is_core { $is_core->(1,@_) }

sub is_still_core { $is_core->(0,@_) }

sub list_core_modules { $list_core_modules->(1,@_) }

sub list_still_core_modules { $list_core_modules->(0,@_) }

1;

# ABSTRACT: More functions for Module::CoreList

__END__

=pod

=encoding UTF-8

=head1 NAME

Module::CoreList::More - More functions for Module::CoreList

=head1 VERSION

This document describes version 0.06 of Module::CoreList::More (from Perl distribution Module-CoreList-More), released on 2015-05-06.

=head1 SYNOPSIS

 use Module::CoreList::More;

 # true, this module has always been in core since specified perl release
 Module::CoreList::More->is_still_core("Benchmark", 5.010001);

 # false, since CGI is removed in perl 5.021000
 Module::CoreList::More->is_still_core("CGI");

 # false, never been in core
 Module::CoreList::More->is_still_core("Foo");

 my %modules = list_still_core_modules(5.010001);

=head1 DESCRIPTION

This module is my experiment for providing more functionality to (or related to)
L<Module::CoreList>. Some ideas include: faster functions, more querying
functions, more convenience functions. When I've got something stable and useful
to show for, I'll most probably suggest the appropriate additions to
Module::CoreList.

Below are random notes:

=head1 FUNCTIONS

These functions are not exported. They can be called as function (e.g.
C<Module::CoreList::More::is_still_core($name)> or as class method (e.g. C<<
Module::CoreList::More->is_still_core($name) >>.

=head2 first_release( MODULE )

Like Module::CoreList's C<first_release>, but faster.

=head2 first_release_by_date( MODULE )

Like Module::CoreList's C<first_release_by_date>, but faster.

=head2 is_core( MODULE, [ MODULE_VERSION, [ PERL_VERSION ] ] )

Like Module::CoreList's C<is_core>, but faster (see L</"BENCHMARK">).
Module::CoreList's C<is_core()> is in general unoptimized, so our version can be
much faster.

Ideas for further speeding up (if needed): produce a cached data structure of
list of core modules for a certain Perl release (the data structure in
Module::CoreList are just list of Perl releases + date %released and %delta
which only lists differences of modules between Perl releases).

=head2 is_still_core( MODULE, [ MODULE_VERSION, [ PERL_VERSION ] ] )

Like C<is_core>, but will also check that from PERL_VERSION up to the latest
known version, MODULE has never been removed from core.

Note/idea: could also be implemented by adding a fourth argument
MAX_PERL_VERSION to C<is_core>, defaulting to the latest known version.

=head2 list_core_modules([ PERL_VERSION ]) => %modules

List modules that are in core at specified perl release.

=head2 list_still_core_modules([ PERL_VERSION ]) => %modules

List modules that are (still) in core from specified perl release to the latest.
Keys are module names, while values are versions of said modules in specified
perl release.

=head1 BENCHMARK

                                  Rate MC->first_release(Foo) MC->first_release(CGI) MCM->first_release(Foo) MCM->first_release(CGI)
 MC->first_release(Foo)   159.4+-0.2/s                     --                 -86.0%                  -99.1%                  -99.7%
 MC->first_release(CGI)  1139.1+-2.2/s            614.6+-1.6%                     --                  -93.8%                  -97.6%
 MCM->first_release(Foo)  18394.8+-0/s             11440+-14%           1514.8+-3.1%                      --                  -60.9%
 MCM->first_release(CGI)   47105+-59/s             29452+-52%           4035.2+-9.5%           156.08+-0.32%                      --
 
                              Rate MC->is_core(Foo) is_still_core(Foo) MCM->is_core(Foo)
 MC->is_core(Foo)   159.83+-0.23/s               --             -98.6%            -99.3%
 is_still_core(Foo)    11775+-17/s        7267+-15%                 --            -50.1%
 MCM->is_core(Foo)     23604+-97/s       14668+-64%      100.45+-0.87%                --
 
                                    Rate MC->is_core(Benchmark) is_still_core(Benchmark) MCM->is_core(Benchmark)
 MC->is_core(Benchmark)    577.07+-0.8/s                     --                   -95.0%                  -97.5%
 is_still_core(Benchmark) 11511.4+-3.5/s           1894.8+-2.8%                       --                  -49.4%
 MCM->is_core(Benchmark)     22771+-28/s             3846+-7.3%             97.81+-0.25%                      --
 
                              Rate MC->is_core(CGI) is_still_core(CGI) MCM->is_core(CGI)
 MC->is_core(CGI)     822.8+-1.8/s               --             -92.8%            -96.3%
 is_still_core(CGI) 11394.8+-3.5/s     1284.9+-3.1%                 --            -49.2%
 MCM->is_core(CGI)     22426+-26/s     2625.7+-6.8%       96.81+-0.23%                --
 
                                             Rate list_still_core_modules(5.020002) list_core_modules(5.020002) list_still_core_modules(5.010001) list_core_modules(5.010001)
 list_still_core_modules(5.020002)  246.8+-0.23/s                                --                       -7.6%                            -22.5%                      -63.1%
 list_core_modules(5.020002)       267.09+-0.29/s                       8.22+-0.15%                          --                            -16.1%                      -60.0%
 list_still_core_modules(5.010001)  318.5+-0.53/s                      29.05+-0.25%                19.25+-0.24%                                --                      -52.3%
 list_core_modules(5.010001)       668.41+-0.77/s                      170.82+-0.4%               150.26+-0.39%                     109.86+-0.43%                          --

=head1 SEE ALSO

L<Module::CoreList>

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Module-CoreList-More>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Module-CoreList-More>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Module-CoreList-More>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2015 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
