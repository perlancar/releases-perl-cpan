* BUG [2015-03-24 Tue] computil: complete_file(filter=>"d"), why doesn't it return a hash answer (with path_sep) but instead return a simple array answer?

  this causes bash to add space to single completion result

* TODO [2015-01-09 Fri] compfile, compriap, computil: when Complete's OPT_DIG_LEAF option has been rethought and no longer experimental, expose it
* TODO [2014-12-01 Mon] computil: complete_file: opsi utk suffix atau wildcard (simpler than coderef)
