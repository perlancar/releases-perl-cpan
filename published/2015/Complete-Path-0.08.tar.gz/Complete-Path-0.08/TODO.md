* TODO [2015-01-03 Sat] comppath: recursive matching

  **/Util to match: List/Util, CHI/Util, Class/Factory/Util, and so on
