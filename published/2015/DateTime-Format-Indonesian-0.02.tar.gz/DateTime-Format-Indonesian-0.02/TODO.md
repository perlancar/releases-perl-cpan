* TODO [2015-01-03 Sat] dtformat-id: Recognize more forms

  Try to guess whether 01/02/99 is d/m/y or m/d/y (check if the other one is
  impossible; default to d/m/y but if sees lots of other m/d/y then m/d/y).

      mmm-dd-yy[yy]
* TODO [2015-01-03 Sat] dtformat-id: Autocorrect typo [#E]
* TODO [2015-01-03 Sat] dtformat-id: Formatter [#B]
* TODO [2015-01-03 Sat] dtformat-id: Recognize/parse/ignore day of week names
