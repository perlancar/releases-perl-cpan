* TODO [2015-01-03 Sat] datecalc: tab completion
* TODO [2015-01-03 Sat] datecalc: Support more special date literals: {last,next} {week,month,year,...}, etc.
* IDEA [2015-01-03 Sat] datecalc: Variable assignment?
* IDEA [2015-01-03 Sat] datecalc: Command to print calendar? For convenience.
* IDEA [2015-01-03 Sat] datecalc: Load holiday data, add command to print holidays?
* IDEA [2015-01-03 Sat] datecalc: Default format to color a date with green/red/yellow on whether it's a working date, a Sunday/holiday, or a joint-leave day.
