* TODO [2015-01-03 Sat] strwc-bash: Function to parse string and return all the wildcards (with their types, positions, ...)

  apply also to other strwc-* dists.
* TODO [2015-01-03 Sat] strwc-bash: Function to strip wildcards from string.

  apply also to other strwc-* dists.
* TODO [2015-01-03 Sat] strwc-bash: Function to convert to other types of wildcards (and/or to check whether it can be represented with other types of wildcards).

  apply also to other strwc-* dists.
* TODO [2015-01-03 Sat] strwc-bash: Function to convert a regex pattern to equivalent wildcard?

  apply also to other strwc-* dists.
