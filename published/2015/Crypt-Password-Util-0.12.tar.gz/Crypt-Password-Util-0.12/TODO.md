* TODO [2015-01-31 Sab] cryptpwutil: some bcrypt hash also has $2y$ header (in addition to $2$ and $2a$)
* WISHLIST [2015-01-25 Min] cryptpwutil: support more crypt types

  there are still lots of crypt types supported in Authen::Passphrase which have
  not been recognized (i'm usually adding new types on a as-needed basis).
  
  aside from that, there's also sha224 and sha384, used/supported in postgres.
  
  there's bound to be more.

* WISHLIST [2015-01-25 Min] cryptpwutil: crypt(): try BCRYPT first

  BCRYPT is now the recommended default and should be tried first.
