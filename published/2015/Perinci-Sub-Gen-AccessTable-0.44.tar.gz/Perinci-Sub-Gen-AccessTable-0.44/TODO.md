* IDEA [2014-06-29 Sun] perisgen-acctbl: di table spec, ada tabel yg by default gak dishow saat detail, mis karena terlalu panjang

  contoh di App::ListSoftwareLicenses, fulltext gak dishow saat --detail tapi bisa
  dishow misalnya dengan (imagined, not yet implemented)
  --view-name=with_fulltext, atau bisa juga dnegan --with-FIELD_NAME (mirip
  seperti di Configure script ya). i prefer the second, soalnya yg former bisa
  kompleks.
