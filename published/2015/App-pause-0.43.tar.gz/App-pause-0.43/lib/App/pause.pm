package App::pause;

our $DATE = '2015-07-27'; # DATE
our $DIST = 'App-pause'; # DIST
our $VERSION = '0.43'; # VERSION

1;
# ABSTRACT: A CLI for PAUSE

__END__

=pod

=encoding UTF-8

=head1 NAME

App::pause - A CLI for PAUSE

=head1 VERSION

This document describes version 0.43 of App::pause (from Perl distribution App-pause), released on 2015-07-27.

=head1 DESCRIPTION

=head1 SEE ALSO

L<WWW::PAUSE::Simple>

L<pause>

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/App-pause>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-App-pause>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=App-pause>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2015 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
