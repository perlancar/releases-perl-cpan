* TODO [2015-01-03 Sat] sprintfn: Some sort of caching
