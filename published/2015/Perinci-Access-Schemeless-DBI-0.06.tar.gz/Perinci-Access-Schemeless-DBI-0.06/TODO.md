* TODO [2015-01-03 Sat] perias-dbi: Support other types of entities: variables, ...

  Currently only packages and functions are recognized.
* TODO [2015-01-03 Sat] perias-dbi: Option to get code from database?
* TODO [2015-01-03 Sat] perias-dbi: Make into a role?

  So users can mix and match either one or more of these as they see fit: getting
  list of packages and functions from database, getting metadata from database,
  and getting code from database.
  
  Alternatively, this single class can provide all of those and switch to enable
  each.
