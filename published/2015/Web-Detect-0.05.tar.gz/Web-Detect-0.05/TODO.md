* TODO [2015-01-03 Sat] webdet: Make heuristics even better!
* TODO [2015-01-03 Sat] webdet: More links/description to each HASHREF key.
* TODO [2015-01-03 Sat] webdet: Never enough tests.
