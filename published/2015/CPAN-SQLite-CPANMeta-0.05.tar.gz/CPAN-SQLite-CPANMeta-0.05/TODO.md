* IDEA [2015-01-10 Sab] cpansqlite-cm: create our own db, being independent from CPAN::SQLite?

  - this will allow us to:
    + rename the mod/dist/bin to something shorter, e.g: cpanminidb (preference:
      6/10), localcpan (part of a one-box solution containing CPAN::Mini +
      indexer + querier, even web interface later on)
    + reduce dependency
    + add columns to tables more freely, e.g. abstract+license+release status+resources to dists from META.{json,yml}
    + let user index in a single step, not two

* TODO [2015-01-09 Fri] cpansqlite-cm: recursive/multi-level should be breadth-first and not depth-first

  otherwise the output is slightly weird:
  

      $ cpandb-cpanmeta deps Rinci -l2
      +---------+----------+
      | module  | version  |
      | DefHash | v1.0.6   |
      |   perl  | 5.010001 |
      +---------+----------+
  
  while we would normally want:
  

      $ cpandb-cpanmeta deps Rinci -l2
      +---------+----------+
      | module  | version  |
      | DefHash | v1.0.6   |
      | perl    | 5.010001 |
      +---------+----------+
  

* TODO [2015-01-08 Thu] cpansqlite-cm: deps: numify/normalize version?
* TODO [2015-01-08 Thu] cpansqlite-cm: extract more data: distribution abstract, license, release status, resources.

  Perhaps put it in a separate table dist_infos or something.
