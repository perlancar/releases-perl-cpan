* TODO [2015-01-03 Sat] http-tiny-cli: Support various C<SSL_options> in the attributes.
* TODO [2015-01-03 Sat] http-tiny-cli: Support request options: trailer_callback, data_callback?
* TODO [2015-01-03 Sat] http-tiny-cli: Win32 support.
* TODO [2015-01-03 Sat] http-tiny-cli: Implement max_size.
