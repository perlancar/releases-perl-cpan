* IDEA [2015-04-12 Min] lcpan: update-index -> update --nofiles, update-files -> update --noindex?
* BUG [2015-04-07 Tue] lcpan: rdeps should list the newest release only
* WISHLIST [2015-01-29 Thu] lcpan: configuration: author (tell the program who/which cpan author the user is, this will be used for various purposes)
* WISHLIST [2015-01-29 Thu] lcpan: plugin: after update, alert if there is a new dist that depends/uses on one of my modules
* WISHLIST [2015-01-29 Thu] lcpan: maintain some watchlist for some modules/dists, and alert if there is a new version (or module/dist is deleted from mirror, etc)
* TODO [2015-01-22 Thu] lcpan: write plugin: rank authors by number of other authors prereqs-ing his modules
* TODO [2015-01-22 Thu] lcpan: write plugin: rank authors by ...?
* TODO [2015-01-22 Thu] lcpan: write plugin: rank modules by number of reverse deps
* TODO [2015-01-22 Thu] lcpan: write plugin: rank dists by number of deps (heaviest dists)
* IDEA [2015-01-15 Thu] lcpan: subcommands modinfo, distinfo, authorinfo

  - not really sure yet though what information to put there (aside from those
    that already in modules --detail, dists --detail, authors --detail).

* TODO [2015-01-15 Thu] _cpanm, lcpan: need to refactor the way one uses Perinci::CmdLine::Util::Config

  - it's currently ugly

* TODO [2015-01-13 Tue] lcpan: implement stats --verbose

  - disk_space

* TODO [2015-01-13 Tue] lcpan: offer some choices of minicpan updating

  - default, -c CPAN::Mini::LatestDistVersion, CPAN::Mini::Devel,
    CPAN::Mini::Devel::Recent, with patch
    -MLWP::UserAgent::Patch::FilterMirrorMaxSize=-size,X,-verbose,1,
    CPAN::Mini::Tested,
  - CPAN::Mini::FromList?
  - but not CPAN::Mini::Extract
