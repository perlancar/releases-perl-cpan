* TODO [2015-01-03 Sat] phoneid: parse area code from first digits of mobile phone after operator code

  # TODO: mobile area code, telkomsel (and indosat etc too?)
  #10-14 Jabotabek
  #15-32 Jabar
  #33-38 Jateng
  #39-43 Jatim
  #44-47 BaliNusra
  #48-59 Kalimantan
  #60-68 Sumbagut (Sumatera Bagian Utara)
  #69-74 Sumbagteng (Sumatera Bagian Tengah)
  #75-86 Sumbagsel (Sumatera Bagian Selatan)
  #87-96 Sulawesi
  #97-99 Papua Maluku
* TODO [2015-01-03 Sat] phoneid: cleanup data (especially city names -> city code)
* TODO [2015-01-03 Sat] phoneid: move data to gudangdata project after cleanup
