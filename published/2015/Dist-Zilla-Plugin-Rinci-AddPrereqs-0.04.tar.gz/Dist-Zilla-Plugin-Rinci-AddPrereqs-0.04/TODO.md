* TODO [2015-03-13 Fri] dzp-ri-addprereqs: when requiring module from Riap URL, use latest version?
