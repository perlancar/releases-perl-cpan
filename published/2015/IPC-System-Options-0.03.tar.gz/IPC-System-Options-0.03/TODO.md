* WISHLIST [2015-01-04 Sun] ipcsysopts: option to overload backtick operator (when perl provides the mechanism)

  - currently backtick operator is not overloadable.
