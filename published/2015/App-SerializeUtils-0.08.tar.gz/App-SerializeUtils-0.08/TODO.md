* TODO [2013-10-26 Sab] serializeutils: add pp-yaml
* TODO [2013-10-26 Sab] serializeutils: add --color option to *2yaml *2json & pp-json
* TODO [2013-10-26 Sab] serializeutils: add --yaml-xs --yaml-syck --json-xs --json-pp to yaml2json json2yaml
* TODO [2013-10-26 Sab] serializeutils: add --xs --syck to yaml2** *2yaml
* TODO [2013-10-26 Sab] serializeutils: add --xs --pp to json2* *2json
