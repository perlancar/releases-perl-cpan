* TODO [2014-05-16 Fri] perirf: cari pengganti YAML::Tiny::Color, karena gak support circular references
