* TODO [2015-03-18 Wed] ciod: add method: get_raw_value()

  - this does not do merges or value decoding
  - can return one or multiple result (if there are more than one key lines)
  - return line number information

* TODO [2015-03-18 Wed] ciod: add method: set_raw_value()

  - optional option: line number
  - can also set comment
  - method name? (for adding key lines, we already have insert_key())

* TODO [2015-03-18 Wed] ciod: add method: each_key()

  - iterate method, for every method line found, run supplied code.
  - also give line number information?
  - what if code modifies document?

* TODO [2015-03-18 Wed] ciod: add method: each_section()

  - iterate method
  - also give line number information?
  - what if code modifies document?

* TODO [2015-03-18 Wed] ciod: add method: each_line()

  - iterate method
  - also give line number information
  - what if code modifies document?

* TODO [2015-03-18 Wed] ciod: add method: delete_comment()
* TODO [2015-03-18 Wed] ciod: add method: insert_comment()

  - either to a new line, or to an existing line
  - can add/replace comment in section line, key line
  - will die if line's comment cannot be set (e.g. directive line)
  - ignore option
  - replace option

* TODO [2015-03-18 Wed] ciod: add method: format()

  - make indentation uniform
  - method name?

* TODO ciod: schema agar user hanya bisa masukin valid values, dan juga utk specify defaults.
* TODO ciod: limit ukuran file, jumlah param, jumlah section, ...
* TODO ciod: param: include_root? (gak boleh keluar dari sini). utk ngeceknya, coba

    lihat is_secure_path di: https://www.securecoding.cert.org/confluence/display/perl/IDS00-PL.+Canonicalize+path+names+before+validating+them

* TODO ciod: param: file_extensions (default .ini & .iod)
* TODO ciod: param: disable expressions per file

  atau in general disable some features on a per file basis

* TODO ciod: param: hooks

  utk implement di atas
  
  contoh:
  

      package Spanel::Config::IOD;
      @ISA=qw(Config::IOD);
      sub before_include {
          # set param: ignore jika file inaccessible
          # set param: ignore jika file too big
          # set param: ignore jika ada invalid parameter
          # set param: ignore jika ada error lainnnya
      }
  :

      sub before_include_after_open {
      }
  
    + sebelum include (open) sebuah file
    + begitu udah open included file (tapi belum diproses)
    + saat selesai sebuah section
    + (more in the future when needed)

* TODO ciod: opsi utk include a file under certain section prefix contoh:

  /etc/spanel/password.ini diload under section [password] dan di dalamnya kalau
  ada section tertentu bisa diignore atau error.

* TODO ciod: opsi agar include file tidak boleh mengandung section lines. contoh sama

    dg password tadi, kita ingin agar si file hanya berisi foo=val lines aja.

* TODO ciod: opsi utk tidak usah
* TODO ciod: param: disallow symlink

  agar secure, kita harus open dulu filenya, baru determine lewat stat ke
  filehandle

* TODO ciod: param: path/prefix real path yang diperbolehkan
* TODO ciod: switch to user before opening a file

  ini bisa diimplementasi lewat hooks

* TODO ciod: param: batasi parameter dan/atau section names hanya boleh regex/pass

  check tertentu contoh di spanel kita hanya memperbolehkan parameter itu. kalo
  error kita bisa warn dan ignore parameter tersebut.

* TODO [2012-11-20 Tue] ciod: pakai re2 (mencegah dos attack)
* TODO [2015-03-12 Thu] ciod: delete_section: how about directive lines like !merge, should they be deleted too?
* TODO [2015-03-12 Thu] ciodr, ciod: add attribute: allow_duplicate_section
* TODO [2015-03-12 Kam] ciod: insert_section: option before_section, after_section (right before/after the first occurence of section(s) named ...)
* TODO [2015-03-12 Kam] ciod: insert_key: option encode_json?

  so we can insert undef, array etc more conveniently

* TODO [2015-03-12 Kam] ciod: insert_key: fix implementation of option top

  - should be before other keys so:
  

      [foo]
      ; comment   <--- not before this line
      ; comment
      ;!directive
      a=1   <---- before this line
      b=1
  

* TODO [2015-03-12 Kam] ciod: update_key

  - will do nothing if key doesn't exist
  - what about multiple occurences?

* TODO [2015-03-12 Kam] ciod: insert_key: option comment

  - must validate value first whether comment can be added or not, for example
    value must not contain ';' or '#'. unless it's encoded/quoted.

* TODO [2015-03-12 Kam] ciod: insert_key: option before_key, after_key

  - not all comments are allowed? depends on encoding?

* TODO [2015-03-11 Wed] le, ciod, ciodr: take a look at Math::Calc::Parser, its code has a simple ad-hoc regexp-based parser which can perhaps be used

  the parser can only parse math operations, e.g. + * / % ^ , parenthesis
  functioncall. but we can extend this a bit.
  
  the upside is: the code is simple and startup overhead is low (<0.01s), compared
  to using Marpa or Regexp::Grammars.
  
  it uses Math::Complex, the module should be delay-loaded.

* TODO [2015-01-03 Sat] ciod: Option to only allow include if owner is the same.
