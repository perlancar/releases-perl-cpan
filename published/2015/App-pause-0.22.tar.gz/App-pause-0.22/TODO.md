* TODO [2015-04-11 Sat] pause-app: tweak fatten options

  - replace DateTime::Format::DateParse with Date::Parse directly
  - exclude Rinci, DefHash and other spec that never actually use-d.
