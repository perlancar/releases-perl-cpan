* IDEA [2015-01-03 Sat] compbash: format_completion(): Accept regex for path_sep?

  - currently there is no real need for this though.
