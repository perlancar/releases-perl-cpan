* IDEA [2014-12-23 Sel] orgutils: list-org-todos: option to snooze some notification for X days
