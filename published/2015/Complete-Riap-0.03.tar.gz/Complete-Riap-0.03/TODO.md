* TODO [2015-01-09 Fri] compfile, compriap, computil: when Complete's OPT_DIG_LEAF option has been rethought and no longer experimental, expose it
