* IDEA [2015-01-15 Thu] lcpan: subcommands modinfo, distinfo, authorinfo

  - not really sure yet though what information to put there (aside from those
    that already in modules --detail, dists --detail, authors --detail).

* TODO [2015-01-15 Thu] _cpanm, lcpan: need to refactor the way one uses Perinci::CmdLine::Util::Config

  - it's currently ugly

* TODO [2015-01-13 Tue] lcpan: implement stats --verbose

  - disk_space

* TODO [2015-01-13 Tue] lcpan: offer some choices of minicpan updating

  - default, -c CPAN::Mini::LatestDistVersion, CPAN::Mini::Devel,
    CPAN::Mini::Devel::Recent, with patch
    -MLWP::UserAgent::Patch::FilterMirrorMaxSize=-size,X,-verbose,1,
    CPAN::Mini::Tested,
  - CPAN::Mini::FromList?
  - but not CPAN::Mini::Extract
