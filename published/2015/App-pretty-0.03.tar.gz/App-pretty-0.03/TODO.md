* TODO [2015-01-03 Sat] pretty: Pass formatting option to formatter modules.
* TODO [2015-01-03 Sat] pretty: Autodetect input format.
