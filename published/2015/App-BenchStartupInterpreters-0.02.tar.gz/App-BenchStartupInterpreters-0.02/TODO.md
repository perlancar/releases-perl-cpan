* WISHLIST [2015-04-09 Thu] bench-interp: add more interpreters

  - various versions of perl
  - various versions of python
  - various versions of ruby
  - other scripting languages: tcl/tk, ...
  - various shells: zsh, fish (make sure config files are not read)
