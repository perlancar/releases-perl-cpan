* TODO [2015-02-07 Sab] ipcsysopts, ipcsysloc: add tests, including allowing default opts in 'use'
