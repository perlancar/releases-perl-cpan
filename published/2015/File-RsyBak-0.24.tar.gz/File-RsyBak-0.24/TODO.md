* TODO [2015-03-16 Mon] rsybak: list backups (with their mtime, etc; or perhaps even with the full log of last backup, duration)
* TODO [2015-03-16 Mon] rsybak: manipulate backups (delete some/all; do something else?)
* TODO [2015-03-16 Mon] rsybak: a single command to check general status of backups

  - including whether backup process is running
  - when backup process last run, its exit status, its duration
  - when next backup process will run (this requires scheduler info)

* TODO [2015-03-16 Mon] rsybak: subcommand to check whether backup process is currently running
* WISHLIST [2015-03-16 Mon] rsybak: eta for next backup?
* IDEA [2014-12-03 Wed] rsybak: add ability to list local filesystems

  - by default backup all local filesystems, except "backup filesystem"
  - deduce/heuristics which is the backup filesystem (e.g. from mount point)
  - of course, the functionality will be delivered in the form of separate module
    (or use existing module)

* IDEA [2014-12-03 Wed] rsybak: add ability to detect btrfs/zfs/lvm which can create snapshots, and use it
* IDEA [2014-12-03 Wed] rsybak: calculate free space and estimate completion time

  - at each run, collect run time and other statistics to be able to estimate
    future backup times

* TODO [2015-01-03 Sat] rsybak: Allow ionice etc instead of just nice -n19
* IDEA [2015-01-03 Sat] rsybak: Run with govprov --load-watch?

  This is quite dangerous because if the system is rather high (almost) all the
  time, then backup will never got done because it keeps stopping itself.
