* BUG [2014-12-27 Sab] perialite: gak bisa find metadata for /Complete/Util/?


      % complete-program
      ERROR 500: No metadata for '/Complete/Util/complete_program'
  
  tapi kalo pake Perinci::CmdLine (bukan pericmd-lite), bisa:
  

      % PERINCI_CMDLINE_ANY=Perinci::CmdLine complete-program fat
      fatlabel   fatpack   fatten
