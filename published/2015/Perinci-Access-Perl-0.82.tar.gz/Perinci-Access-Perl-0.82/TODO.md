* TODO [2015-01-20 Tue] periap: update to Rinci 1.1.71 (streaming input & output using coderef only)
