* TODO [2015-01-04 Sun] ipcsysopts: add option log=>1

  move feature from la4builtins

* TODO [2015-01-04 Sun] ipcsysopts: add option die=>1

  so it behaves like IPC::System::Simple's system(), die-ing on failure.

* TODO [2015-01-04 Sun] ipcsysopts: option to overload backtick operator (when perl provides the mechanism)

  - currently backtick operator is not overloadable.
