* TODO [2015-01-03 Sat] strwc-sql: Support other variants.

  Transact-SQL supports character class, though I'm not sure how the escaping
  mechanism works. Access supports DOS-style wildcard (C<*> and C<?>) instead, and
  I'm also not sure whether there's something akin to backslash escape mechanism
  there.
