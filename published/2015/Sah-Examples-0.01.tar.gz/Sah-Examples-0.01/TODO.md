* TODO [2015-03-26 Thu] sah-eg: add more examples

  - str password with errlevel=warn
