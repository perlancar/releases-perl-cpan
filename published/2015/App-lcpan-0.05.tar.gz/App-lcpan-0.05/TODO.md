* TODO [2015-01-14 Wed] lcpan: probably remove the code that does 'Makefile.PL/Build.PL' extracting, because this means running untrusted code

  - also, metacpan doesn't do this (it probably will use data from cpancover, but
    this hasn't happend yet)
  - we want to be returning similar results to
  - newer and proper releases include META.* anyway, the problem is older releases
  - i don't need to strive for 90+% anyway

* TODO [2015-01-14 Wed] lcpan: use 'perl Makefile.PL/Build.PL' and get info from the generated MYMETA.* instead of monkey-patching

  - this has the benefit of not requiring extra modules
  - after that: "delete EUMM::Dump and MB::Dump"
  - use Dist::Requires!

* TODO [2015-01-14 Wed] lcpan: when executing 'perl Makefile.PL', make sure we set non-interactive mode


         dolmenperlancar, at least you should ensure that $ENV{NON_INTERACTIVE}=1 and STDIN is closed (or not directed to a terminal) to avoid interactive questions
         dolmen... from Makefile.PL
         perlancarso far i use the alarm() trick
         perlancarbut that's not the correct way, i know
         dolmenthere is just no correct way: install tools were just not designed for that
         dolmenthis is why MYMETA has been invented
         haargPERL_MM_USE_DEFAULT=1
  - use Dist::Requires!

* TODO [2015-01-13 Tue] lcpan: stats: last update

  - just get mtime of 02packages.details.txt.gz, convert it to ISO8601 date

* TODO [2015-01-13 Tue] lcpan: implement stats --verbose

  - disk_space

* TODO [2015-01-13 Tue] lcpan: offer some choices of minicpan updating

  - default, -c CPAN::Mini::LatestDistVersion, CPAN::Mini::Devel,
    CPAN::Mini::Devel::Recent, with patch
    -MLWP::UserAgent::Patch::FilterMirrorMaxSize=-size,X,-verbose,1,
    CPAN::Mini::Tested,
  - CPAN::Mini::FromList?
  - but not CPAN::Mini::Extract
