* IDEA [2015-01-03 Sat] compdist: $OPT_SHORTCUT_PREFIXES like in Complete::Module?
