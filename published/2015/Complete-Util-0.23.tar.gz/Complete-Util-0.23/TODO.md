* BUG [2015-02-27 Fri] computil: completion of file/dir results in error


      % mycomp --str2 ~/tmp/<tab><tab>
  Can't use an undefined value as an ARRAY reference at /home/s1/perl5/perlbrew/perls/perl-5.18.4/lib/site_perl/5.18.4/Complete/Path.pm line 22.
  - happens on my office PC
  - also happens when i use /home/s1/tmp/, so this is not an issue with '~' but
    with things inside ~.
  - ~/tmp is not a symlink, it contains quite a lot of files

* TODO [2015-01-09 Fri] compfile, compriap, computil: when Complete's OPT_DIG_LEAF option has been rethought and no longer experimental, expose it
* TODO [2014-12-01 Mon] computil: complete_file: opsi utk suffix atau wildcard (simpler than coderef)
