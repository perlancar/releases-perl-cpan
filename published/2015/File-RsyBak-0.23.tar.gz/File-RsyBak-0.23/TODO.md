* TODO [2015-01-03 Sat] rsybak: Allow ionice etc instead of just nice -n19
* IDEA [2015-01-03 Sat] rsybak: Run with govprov --load-watch?

  This is quite dangerous because if the system is rather high (almost) all the
  time, then backup will never got done because it keeps stopping itself.
