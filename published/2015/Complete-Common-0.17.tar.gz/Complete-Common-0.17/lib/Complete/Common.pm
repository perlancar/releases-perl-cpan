package Complete::Common;

1;
# ABSTRACT: Common stuffs for various Common::* implementation modules

__END__

=pod

=encoding UTF-8

=head1 NAME

Complete::Common - Common stuffs for various Common::* implementation modules

=head1 VERSION

This document describes version 0.17 of Complete::Common (from Perl distribution Complete-Common), released on 2015-11-28.

=head1 SEE ALSO

L<Complete>

The various C<Complete::*> modules.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Complete-Common>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Complete-Common>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Complete-Common>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2015 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
