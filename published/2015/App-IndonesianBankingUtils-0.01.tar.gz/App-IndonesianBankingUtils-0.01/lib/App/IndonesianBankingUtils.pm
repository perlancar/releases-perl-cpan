package App::IndonesianBankingUtils;

use 5.010001;

our $DATE = '2015-04-28'; # DATE
our $VERSION = '0.01'; # VERSION

1;
# ABSTRACT: CLIs related to Indonesian banking

__END__

=pod

=encoding UTF-8

=head1 NAME

App::IndonesianBankingUtils - CLIs related to Indonesian banking

=head1 VERSION

This document describes version 0.01 of App::IndonesianBankingUtils (from Perl distribution App-IndonesianBankingUtils), released on 2015-04-28.

=head1

This distribution contains several CLI's related to Indonesian banking:

=over

=item * L<download-bca>

=item * L<download-mandiri>

=item * L<parse-bca-statement>

=item * L<parse-bprks-statement>

=item * L<parse-mandiri-statement>

=back

=head1 SEE ALSO

L<Finance::Bank::ID::BCA>

L<Finance::Bank::ID::BPRKS>

L<Finance::Bank::ID::Mandiri>

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/App-IndonesianBankingUtils>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-App-IndonesianBankingUtils>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=App-IndonesianBankingUtils>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2015 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
