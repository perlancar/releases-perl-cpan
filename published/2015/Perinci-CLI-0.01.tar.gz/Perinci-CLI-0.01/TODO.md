* TODO [2015-01-04 Min] pericli: add options to pass other arguments to new()
