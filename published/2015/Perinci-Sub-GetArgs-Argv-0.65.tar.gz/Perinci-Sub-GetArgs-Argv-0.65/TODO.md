* IDEA [2012-08-22 Wed] pl: periga-argv: expand wildcards (for windows)? [#C]

  - or for certain args only

* TODO [2012-08-02 Thu] periga-argv: refactor (needs sah)

  - sah should have a parse_from_string() method for each data type. for example,
    the 'date' type should be able to parse unix time stamp, YYYY-MM-DD, etc.
    there should be some configurable options for parsing, but some appropriate
    defaults. this will make it easy for periga-argv/pericmd to parse cmdline
    opts:
  

      --start-date 1999-12-31 --duration 1h
  
  will automatically parsed and become DateTime object and DateTime::Duration
  object.
  

* TODO [2013-10-24 Thu] riap, pericmd, periga-argv: encoding binary data in json

  - riap http:
    - header X-riap-jb- & -riap-j- artinya JSON + base64 encoding.
    - GET/POST param: arg:jb=TWFuIGlzIGRpc3Rpbmd1aXNoZWQsIG5vdCBvbmx5IGJ5I...
    - tapi bagaimana jika salah satu args ada yang ingin binary?
      x-riap-args-j-: {"foo":1,"bindata:b":"TWFuIGlzIGRpc3Rpbmd1aXNoZWQsIG5vdCBvbmx5IGJ5I..."}
    - perlu cek dulu apakah ":b" bisa dipake? atau prefiks aja?
  - riap simple:
  - pericmd/periga-argv:
  - tetap bermasalah jika kita ingin mengirimkan binary data tapi bagian dari data
    structure, mis: array/hash of icons.
  - atau konvensi aja, semua binary data di json harus base64, nanti saat decode
    dari json baru convert lagi (yang berarti harus liat schema). untuk simplenya,
    bisa dibuat dulu hanya purely binary data (buf*) yang diconvert.
  - cara paling simpelnya saat ini adalah dg avoid JSON aja. periga-argv (pericmd)
    bisa pake yaml, riap::http juga bisa. yg ga bisa adalah riap::simple (hanya
    json). utk spanel, ga terlalu jadi concern.

* TODO [2015-03-01 Sun] pericmd-lite, periswrap, periga-argv: (base class) implement args_groups
* TODO [2015-02-07 Sab] periga-argv, pericmd: should 'deps' and 'args_groups' checking be done (only) in periga-argv, or (also) in pericmd after cmdline_src handling?
* TODO [2015-01-03 Sat] periga-argv: Option to enable json/yaml for nullable simple scalar (to enable C<--str-json '~'>).
* IDEA [2014-11-01 Sat] ri, periga-argv, pericmd: suppress accepting --foo-json/--foo-yaml even though arg is array etc

  contoh, gw ingin accept file sebagai --file F1 --file F2 saja, gak mau user bisa
  --file-json '["F1","F2"]'. terutama utk array of simple scalar, gw hanya ingin
  itu.
  
  tentu saja kita bisa matikan per_arg_json, per_arg_yaml. mungkin perlu ada
  per-arg optionnya. dan belum ada cara utk specify ini dari pericmd.
