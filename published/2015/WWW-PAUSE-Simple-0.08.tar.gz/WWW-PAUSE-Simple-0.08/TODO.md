* IDEA [2015-02-26 Thu] pausesimple: subcommand to count the number of dists on cpan via counting the number of *.readme? *.meta?

  - don't forget to note that this is not the proper way and might not be correct,
    but this is another way to check

* TODO [2015-02-05 Thu] pausesimple: list: add sorting options
* WISHLIST [2015-02-06 Fri] pausesimple: add completion for delete & undelete & reindex: file argument (perform list_files then cache it for a few minutes)

  - CHECKSUMS need not be included because it's not deleteable
  - for reindex, ~*.readme~ are also not included.

* TODO [2015-02-06 Fri] pausesimple: add delete-dist subcommand which will delete all Dist-Name-*.{tar.gz,meta,readme} files
* TODO [2015-02-05 Thu] pausesimple: implement the rest of the functions: delete_files, undelete_files, reindex, set_password, set_account_info

  - log ::
    + [2015-02-06 Fri] done: delete, undelete, reindex

* TODO [2015-02-05 Thu] pausesimple: implement clean_old_releases function ('pause clean')

  - provide an option: number of old releases to keep, or maximum age of old
    releases to keep.

* TODO [2015-02-05 Thu] pausesimple: implement (get_)?account_info function
* TODO [2015-02-05 Thu] pausesimple: implement permission-related functions [#E]

  i seldom use this though
