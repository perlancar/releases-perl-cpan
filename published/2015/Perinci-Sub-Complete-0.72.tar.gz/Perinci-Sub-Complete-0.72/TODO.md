* IDEA [2015-02-28 Sab] periscomp: an arg can have 'x.schema.entity', read Complete::Arg::ENTITY something on how to complete this

  of course, when there is no 'completion' routine
  
  thus we can just mark arguments as being entity such and such (a riap URL, a
  filename, a username, etc) instead of having to install a custom completion
  routine everytime.

* TODO [2015-02-24 Tue] periscomp: complete arg value: date

  - use iso8601
  - 2015-<tab> -> 01 s.d. 12
  - 2015-01-<tab> -> 01 s.d. 31
  - date as well as datetime

* TODO [2015-02-07 Sab] periscomp: be smarter with help from 'args_groups'

  - if [aa,bb,cc] is a one_of group, when --aa has been specified, no longer
    provide bb and cc in list of options even though they have not been mentioned
    yet.
  - that's it for now :)

* IDEA [2014-06-27 Fri] periscomp: complete_from_schema: completion for number with prefix, e.g. 30G/30T/30K/30M (lihat dari range min-max mana yg possible/most likely)
* BUG [2014-12-13 Sat] periscomp, compgl: completion of short option belum benar

  - harusnya -a -> -ap -> -apq (semua short option yang belum dimention dan tidak
    require args), ini langsung complete -a <spasi>.

* BUG [2014-12-05 Fri] pmutils/periscomp: saat complete module, direktori (yg bukan valid module prefix) juga terinclude?

  di pmdoc etc, dir keinclude juga, contoh ada foo/ dan foo-bar/ di curdir, kenapa
  pmdoc foo<tab> tetep complete foo-bar/ ya?, tapi kalo pake foo-, gak.
  
  trus kalo pmdoc <tab> dan di curdir ada direktori2x seperti -a, +b, (c, itu
  semua diinclude! sebenernya nyampe sampe complete_file gak sih?

* TODO [2014-11-06 Kam] periscomp: don't convert wildcard when completing filenames

  - e.g. bash lets you do this:
  

      cmd ~/Doc*/Pic*/foo<tab>
  
  can complete 'foo' in ~/Documents/Pictures/ when that is the only directory that
  matches. the wildcard doesn't get converted. currently periscomp does this:
  

      cmd Doc*
  
  either will complete to ['Documents'] or (if there is more than one match
  ['Documents','Docopt'], will change the word from 'Doc*' to 'Doc' (the *
  disappears).
