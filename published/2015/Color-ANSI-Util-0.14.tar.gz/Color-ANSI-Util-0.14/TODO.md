* TODO [2015-01-03 Sat] cautil: Routine to convert ANSI escape code, e.g. C<\e[31;1m> into RGB value (ff0000).
