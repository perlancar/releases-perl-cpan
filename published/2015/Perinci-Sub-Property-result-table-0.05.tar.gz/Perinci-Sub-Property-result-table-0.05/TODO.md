* BUG [2015-01-07 Wed] pericmd, perisprop-result-table: help about table data is now not displayed

  - try: list-id-holidays -h --verbose
