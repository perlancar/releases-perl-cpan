* IDEA [2014-12-14 Sun] dzilutils, weaverutils: list plugins on cpan, install & uninstall

  - idenya sama seperti di wordlist, berbasiskan modul dengan namespace tertentu.
  - bisa juga diterapkan di ansitable colortheme/borderstyle modules.
  - mungkin fungsionalitas ini bisa diekstrak ke dalam role.
  - gunakan xpan!
