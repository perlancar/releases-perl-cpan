* TODO [2015-01-03 Sat] sqlschema: Configurable meta table name?
* TODO [2015-01-03 Sat] sqlschema: Reversion/downgrade?

  Something which does not come up often yet in my case.
