* TODO [2015-01-03 Sat] marpax-simple: Allow customizing error message/behavior.
* TODO [2015-01-03 Sat] marpax-simple: Support more grammar (L<Marpa::R2::Scanless::G>) options

  e.g.: C<trace_file_handle>.
* TODO [2015-01-03 Sat] marpax-simple: Support more recognizer (L<Marpa::R2::Scanless::R>) options

  e.g.: C<max_parses>, C<trace_file_handle>.
