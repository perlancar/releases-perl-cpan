package Module::CoreList::More;

our $DATE = '2015-04-23'; # DATE
our $VERSION = '0.05'; # VERSION

use 5.010001;
use strict;
use warnings;

use Module::CoreList;

sub is_core {
    no warnings; # temporary, some version strings in %Module::CoreList::delta contain trailing space, e.g. "1.15 " which cause warning in version->parse()

    my $module = shift;
    $module = shift if eval { $module->isa(__PACKAGE__) } && @_ > 0 && defined($_[0]) && $_[0] =~ /^\w/;
    my ($module_version, $perl_version);

    $module_version = shift if @_ > 0;
    $perl_version   = @_ > 0 ? shift : $];

    my $first_rel; # first perl version where module is in core

  RELEASE:
    for my $rel (sort keys %Module::CoreList::delta) {
        last if $rel > $perl_version; # this is the difference with is_still_core()

        my $delta = $Module::CoreList::delta{$rel};
        if ($first_rel) {
            # we have found the first release where module is included, check if
            # module is removed
            return 0 if $delta->{removed}{$module};
        } else {
            # we haven't found the first release where module is included
            if (exists $delta->{changed}{$module}) {
                my $modver = $delta->{changed}{$module};
                if (defined $module_version) {
                    if (version->parse($modver) >= version->parse($module_version)) {
                        $first_rel = $rel;
                    }
                } else {
                    $first_rel = $rel;
                }
                if ($first_rel) {
                    return 0 if $first_rel > $perl_version;
                }
            }
        }
    }

    # module has been included and never removed
    return 1 if $first_rel;

    # we never found the first release where module is first included
    0;
}

sub is_still_core {
    no warnings; # temporary, some version strings in %Module::CoreList::delta contain trailing space, e.g. "1.15 " which cause warning in version->parse()

    my $module = shift;
    $module = shift if eval { $module->isa(__PACKAGE__) } && @_ > 0 && defined($_[0]) && $_[0] =~ /^\w/;
    my ($module_version, $perl_version);

    $module_version = shift if @_ > 0;
    $perl_version   = @_ > 0 ? shift : $];

    my $first_rel; # first perl version where module is in core

  RELEASE:
    for my $rel (sort keys %Module::CoreList::delta) {
        my $delta = $Module::CoreList::delta{$rel};
        if ($first_rel) {
            # we have found the first release where module is included, check if
            # module is removed
            return 0 if $delta->{removed}{$module};
        } else {
            # we haven't found the first release where module is included
            if (exists $delta->{changed}{$module}) {
                my $modver = $delta->{changed}{$module};
                if (defined $module_version) {
                    if (version->parse($modver) >= version->parse($module_version)) {
                        $first_rel = $rel;
                    }
                } else {
                    $first_rel = $rel;
                }
                if ($first_rel) {
                    return 0 if $first_rel > $perl_version;
                }
            }
        }
    }

    # module has been included and never removed
    return 1 if $first_rel;

    # we never found the first release where module is first included
    0;
}

sub list_core_modules {
    my $class = shift if @_ && eval { $_[0]->isa(__PACKAGE__) };
    my $perl_version = @_ ? shift : $];

    my %added;
    my %removed;

  RELEASE:
    for my $rel (sort keys %Module::CoreList::delta) {
        last if $rel > $perl_version; # this is the difference with list_still_core_modules()

        my $delta = $Module::CoreList::delta{$rel};

        next unless $delta->{changed};
        for my $mod (keys %{$delta->{changed}}) {
            # module has been removed between perl_version..latest, skip
            next if $removed{$mod};

            if (exists $added{$mod}) {
                # module has been added in a previous version, update first
                # version
                $added{$mod} = $delta->{changed}{$mod} if $rel <= $perl_version;
            } else {
                # module is first added after perl_version, skip
                next if $rel > $perl_version;

                $added{$mod} = $delta->{changed}{$mod};
            }
        }
        next unless $delta->{removed};
        for my $mod (keys %{$delta->{removed}}) {
            delete $added{$mod};
            # module has been removed between perl_version..latest, mark it
            $removed{$mod}++ if $rel >= $perl_version;
        }

    }
    %added;
}

sub list_still_core_modules {
    my $class = shift if @_ && eval { $_[0]->isa(__PACKAGE__) };
    my $perl_version = @_ ? shift : $];

    my %added;
    my %removed;

  RELEASE:
    for my $rel (sort keys %Module::CoreList::delta) {
        my $delta = $Module::CoreList::delta{$rel};

        next unless $delta->{changed};
        for my $mod (keys %{$delta->{changed}}) {
            # module has been removed between perl_version..latest, skip
            next if $removed{$mod};

            if (exists $added{$mod}) {
                # module has been added in a previous version, update first
                # version
                $added{$mod} = $delta->{changed}{$mod} if $rel <= $perl_version;
            } else {
                # module is first added after perl_version, skip
                next if $rel > $perl_version;

                $added{$mod} = $delta->{changed}{$mod};
            }
        }
        next unless $delta->{removed};
        for my $mod (keys %{$delta->{removed}}) {
            delete $added{$mod};
            # module has been removed between perl_version..latest, mark it
            $removed{$mod}++ if $rel >= $perl_version;
        }

    }
    %added;
}

1;

# ABSTRACT: More functions for Module::CoreList

__END__

=pod

=encoding UTF-8

=head1 NAME

Module::CoreList::More - More functions for Module::CoreList

=head1 VERSION

This document describes version 0.05 of Module::CoreList::More (from Perl distribution Module-CoreList-More), released on 2015-04-23.

=head1 SYNOPSIS

 use Module::CoreList::More;

 # true, this module has always been in core since specified perl release
 Module::CoreList::More->is_still_core("Benchmark", 5.010001);

 # false, since CGI is removed in perl 5.021000
 Module::CoreList::More->is_still_core("CGI");

 # false, never been in core
 Module::CoreList::More->is_still_core("Foo");

 my %modules = list_still_core_modules(5.010001);

=head1 DESCRIPTION

This module is my experiment for providing more functionality to (or related to)
L<Module::CoreList>. Some ideas include: faster functions, more querying
functions, more convenience functions. When I've got something stable and useful
to show for, I'll most probably suggest the appropriate additions to
Module::CoreList.

Below are random notes:

=head1 FUNCTIONS

These functions are not exported. They can be called as function (e.g.
C<Module::CoreList::More::is_still_core($name)> or as class method (e.g. C<<
Module::CoreList::More->is_still_core($name) >>.

=head2 is_core( MODULE, [ MODULE_VERSION, [ PERL_VERSION ] ] )

Like Module::CoreList's C<is_core>, but faster (see L</"BENCHMARK">).
Module::CoreList's C<is_core()> is in general unoptimized, so our version can be
much faster.

Ideas for further speeding up (if needed): produce a cached data structure of
list of core modules for a certain Perl release (the data structure in
Module::CoreList are just list of Perl releases + date %released and %delta
which only lists differences of modules between Perl releases).

=head2 is_still_core( MODULE, [ MODULE_VERSION, [ PERL_VERSION ] ] )

Like C<is_core>, but will also check that from PERL_VERSION up to the latest
known version, MODULE has never been removed from core.

Note/idea: could also be implemented by adding a fourth argument
MAX_PERL_VERSION to C<is_core>, defaulting to the latest known version.

=head2 list_core_modules([ PERL_VERSION ]) => %modules

List modules that are in core at specified perl release.

=head2 list_still_core_modules([ PERL_VERSION ]) => %modules

List modules that are (still) in core from specified perl release to the latest.
Keys are module names, while values are versions of said modules in specified
perl release.

=head1 BENCHMARK

                              Rate MC->is_core(Foo) is_still_core(Foo) MCM->is_core(Foo)
 MC->is_core(Foo)   163.13+-0.33/s               --             -98.8%            -99.3%
 is_still_core(Foo)    13718+-20/s        8309+-21%                 --            -38.6%
 MCM->is_core(Foo)     22360+-27/s       13607+-32%          63+-0.31%                --
 
                                  Rate MC->is_core(Benchmark) is_still_core(Benchmark) MCM->is_core(Benchmark)
 MC->is_core(Benchmark)   584.6+-1.5/s                     --                   -96.4%                  -97.5%
 is_still_core(Benchmark)  16181+-28/s           2667.8+-8.4%                       --                  -30.3%
 MCM->is_core(Benchmark)   23211+-29/s              3870+-11%              43.45+-0.3%                      --
 
                            Rate MC->is_core(CGI) is_still_core(CGI) MCM->is_core(CGI)
 MC->is_core(CGI)   845.9+-2.5/s               --             -95.0%            -96.3%
 is_still_core(CGI)  16826+-28/s     1889.1+-6.7%                 --            -25.9%
 MCM->is_core(CGI)   22700+-27/s     2583.5+-8.6%       34.91+-0.27%                --
 
                                             Rate list_still_core_modules(5.020002) list_core_modules(5.020002) list_still_core_modules(5.010001) list_core_modules(5.010001)
 list_still_core_modules(5.020002) 221.55+-0.17/s                                --                       -7.5%                            -22.2%                      -64.0%
 list_core_modules(5.020002)       239.43+-0.23/s                       8.07+-0.13%                          --                            -16.0%                      -61.1%
 list_still_core_modules(5.010001) 284.86+-0.27/s                      28.58+-0.16%                18.98+-0.16%                                --                      -53.8%
 list_core_modules(5.010001)       616.14+-0.91/s                     178.11+-0.46%               157.34+-0.45%                     116.29+-0.38%                          --

=head1 SEE ALSO

L<Module::CoreList>

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Module-CoreList-More>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Module-CoreList-More>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Module-CoreList-More>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2015 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
