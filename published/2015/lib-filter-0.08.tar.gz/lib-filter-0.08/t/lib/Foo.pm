# just an empty module to test loading from non-core dir
package
    Foo;

1;
