* TODO [2015-02-25 Wed] pericmd-classic, pericmd-lite: show summary in help and 'cmd --subcommands'

  - summary from subcommand spec should be shown [done]
  - summary from function meta should also be shown if url is local

* TODO [2014-12-03 Wed] [#E] pericmd-classic: --help: underline entity in --opt=entity

  - di pericmd-lite agak ribet karena color codes membuat alignment string agak
    ribet dan harus pake Text::ANSI::Util dsb, skip aja dulu di pericmd-lite.
