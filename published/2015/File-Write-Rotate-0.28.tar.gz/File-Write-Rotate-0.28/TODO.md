* IDEA [2015-01-03 Sat] fwr: Perhaps an option to disable locking?
