* TODO [2015-01-31 Sab] eta2zero: make sleep/delay configurable, automatically pick appropriate value
* TODO [2015-01-31 Sab] eta2zero: allow specifying progress bar width?
* TODO [2015-01-31 Sab] eta2zero: allow disabling color (i think it already can, we just need to document how)
