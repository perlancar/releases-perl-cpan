* BUG [2015-04-10 Fri] sahutils, pericmd-classic: 'validate-with-sah -h' fails with pericmd-classic

  - gitbunch, fatten ok

* TODO [2015-04-03 Fri] sahutils: script to generate human message (just a compiler option to validate-with-sah perhaps?)
