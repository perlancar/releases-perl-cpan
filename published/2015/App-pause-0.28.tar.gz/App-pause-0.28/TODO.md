* TODO [2015-04-11 Sat] [#B] pause-app: tweak fatten options to minimize size

  - exclude Rinci, DefHash and other spec that never actually use-d.
  - exclude Date::Language, are they used?
