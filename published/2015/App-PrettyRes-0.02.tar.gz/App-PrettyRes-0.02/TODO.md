* TODO [2015-01-03 Sat] pretty-res: Autodetect input format.
