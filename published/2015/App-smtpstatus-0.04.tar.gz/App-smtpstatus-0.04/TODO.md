* TODO [2015-01-03 Sat] smtpstatus: Add implementation-specific codes (from Sendmail, qmail, Postfix, Exim, Spanel)
* TODO [2015-01-03 Sat] smtpstatus: Formatting

  Use --format=text-pretty by default for interactive, set description's
  table_column_orders (after summary, not before) and table_column_formats ([[wrap
  => {columns=>40}]]).
