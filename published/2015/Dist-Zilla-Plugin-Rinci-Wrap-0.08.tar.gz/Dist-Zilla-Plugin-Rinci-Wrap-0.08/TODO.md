* TODO [2015-01-03 Sat] dzp-ri-wrap: Use L<PPI> instead of fragile regex.
* TODO [2015-01-03 Sat] dzp-ri-wrap: Option to reuse validation code for the same schema.
* TODO [2015-01-03 Sat] dzp-ri-wrap: Option to exclude some subroutines from being wrapped.
* TODO [2015-01-03 Sat] dzp-ri-wrap: Option to specify different wrap_args for different subroutines.
