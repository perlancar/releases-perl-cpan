* TODO [2015-01-10 Sab] pwr-addtext: use it in the rest of my pws/pwp dists
