* TODO [2015-01-03 Sat] colrgbutil: Support mixing several colors in mix_rgb_colors().

  Args might be $rgb1, $rgb2, ... or $rgb1, $part1, $rgb2, $part2, ... (e.g.
  'ffffff', 1, 'ff0000', 1, '00ff00', 2).
