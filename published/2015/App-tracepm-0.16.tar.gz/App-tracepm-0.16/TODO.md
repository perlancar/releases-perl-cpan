* TODO [2015-01-03 Sat] tracepm: 'use' arg not yet respected if 'method' =~ /prereqscanner/
* TODO [2015-01-03 Sat] tracepm: Add option to silent STDOUT and/or STDERR output of script?
