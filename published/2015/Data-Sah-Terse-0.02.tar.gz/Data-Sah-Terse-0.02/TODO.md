* TODO [2015-01-03 Sat] dsah-terse: Provide more options, e.g. allow showing some clauses (.e.g "int>10").
* TODO [2015-01-03 Sat] dsah-terse: Show hash as "hash[str=>array]" or just "hash[array]"?

  Consider that we will allow subschemas in the future, e.g.
  "hash[filename=>filespec]".
* TODO [2015-01-03 Sat] dsah-terse: Handle '!of' (of.op=not), 'of&' (of.op=and), 'of!' (of.op=or).
