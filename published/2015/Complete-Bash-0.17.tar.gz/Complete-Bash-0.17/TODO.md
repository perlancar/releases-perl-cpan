* TODO [2014-12-03 Wed] compbash, compbashhist: C version of parse_cmdline n parse_options because they have to be called thousands of time in compbashhist for each tab completion! [#D]
* IDEA [2014-12-19 Jum] compbash: how to emulate description entries on bash?
* IDEA [2015-01-03 Sat] compbash: format_completion(): Accept regex for path_sep?

  - currently there is no real need for this though.
