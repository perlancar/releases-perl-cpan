* TODO [2015-01-03 Sat] twutil: Split wrap() to another dist

  So C<Unicode::GCString> is not pulled if not needed.
