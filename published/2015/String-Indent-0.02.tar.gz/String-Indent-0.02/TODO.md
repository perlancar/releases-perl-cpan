* TODO [2015-01-03 Sat] strindent: Option 'first_line_indent'.
* TODO [2015-01-03 Sat] strindent: 'dedent' function.
* TODO [2015-01-03 Sat] strindent: Option to trim blank lines.
