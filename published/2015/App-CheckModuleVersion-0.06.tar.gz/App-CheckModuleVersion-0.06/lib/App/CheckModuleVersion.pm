package App::CheckModuleVersion;

our $DATE = '2015-07-30'; # DATE
our $VERSION = '0.06'; # VERSION

1;
# ABSTRACT: Check module (e.g. check latest version) with CPAN (or equivalent repo)

__END__

=pod

=encoding UTF-8

=head1 NAME

App::CheckModuleVersion - Check module (e.g. check latest version) with CPAN (or equivalent repo)

=head1 VERSION

This document describes version 0.06 of App::CheckModuleVersion (from Perl distribution App-CheckModuleVersion), released on 2015-07-30.

=head1 DESCRIPTION

This distribution contains L<check-module-version> utility.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/App-CheckModuleVersion>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-App-CheckModuleVersion>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=App-CheckModuleVersion>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2015 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
