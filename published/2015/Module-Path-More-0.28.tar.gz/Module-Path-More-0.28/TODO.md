* IDEA [2015-02-25 Wed] mpathmore: handle coderef in @INC

  This is just an idea which I jotted down for Module::Path::More. Haven't had a
  need for it myself.
  
  Someone might need a behavior that's closer to what require() does and need
  coderef in @INC handled. See the require section in perlfunc.
  
  (Also posted as issue in Module::Path's github).
