* TODO [2015-04-11 Sat] pause-app: tweak fatten options

  - exclude Rinci, DefHash and other spec that never actually use-d.
  - exclude Date::Language, are they used?
