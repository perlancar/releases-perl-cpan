* TODO [2015-01-03 Sat] fsql: Allow customizable CSV separator and quoting character.
