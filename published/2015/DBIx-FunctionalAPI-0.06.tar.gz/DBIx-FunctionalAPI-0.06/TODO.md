* TODO [2015-01-03 Sat] dbix-funcapi: Option to select specific catalog and schema (table namespace).
* TODO [2015-01-03 Sat] dbix-funcapi: implement more functions

  # TODO: delete_row, delete_rows
  # TODO: delete_table, delete_tables
  # TODO: create_row, create_table
  # TODO: modify_row, modify_table
  # TODO: rename_column, rename_table
  # TODO: get_table_schema
  # TODO: get_db_schema
