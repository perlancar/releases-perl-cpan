* TODO [2015-01-03 Sat] dzp-ri-sffunc: logging

  In Synopsis, add an example on how to enable debugging/tracing.
* TODO [2015-01-03 Sat] dzp-ri-sffunc: completion

  If C<completion=1>, add instruction on how to enable bash completion in
  Synopsis.
* TODO [2015-01-03 Sat] dzp-ri-sffunc: link to corresponding module

  Link to corresponding Perl module in See Also (the Version POD section already
  mentions the dist name though).
* TODO [2015-01-03 Sat] dzp-ri-sffunc: customize See Also

  Allow specifying links
* TODO [2015-01-03 Sat] dzp-ri-sffunc: fatpacker-friendly

  Add 'use MODULE' (if function URL points to local module) so dependencies can be
  detected more easily (more fatpacker-friendly).
