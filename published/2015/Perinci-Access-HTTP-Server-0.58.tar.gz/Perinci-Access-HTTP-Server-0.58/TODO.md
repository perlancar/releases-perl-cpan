* TODO [2012-01-19 Thu] periahs: pass psgi env ke functions, for leaky abstractions

  agar fungsi tahu bahwa dia run under psgi, dan bisa deteksi cookie-lah, http
  headers lah, whatever.

* WISHLIST [2014-03-29 Sab] periahs: logger: redact passwords in function argument
* TODO [2012-06-13 Wed] periahs: what to do with cors (Access-Control-Allow-Origin header)

  pada dasarnya kita tinggal ngirimin header ini sih. lihat contoh/demo di
  ~notes/coba/cors/~.
  
  di ga misalnya, kita bisa set aja kirim 'Access-Control-Allow-Origin: *' agar
  fungsi2x api dapat dipakai/dimesh di semua halaman web manapun. fungsi2x milik
  klien dapat disetting oleh klien utk direstrict hanya diakses dari url tertentu.
  nah bagaimana dg paying client? dari API token, kita bisa mengeset agar fungsi2x
  api tersebut bisa muncul di website milik si klien.

* TODO [2012-03-27 Tue] pericmd, periahs: how to specify result filtering?

  for example:
  

      % calendar --result-filter '{date: epoch}'
      % calendar --result-filter '{date: ymd, re: str}'
  
  dan ini perlu diteruskan ke server, untuk remote entity. so periahs (or riap)
  needs to support this too.
  

      curl 'http://gudangapi.com/ga/some_mod/some_func?-riap-result-filter:j={"date":"epoch"}'
  

* TODO [2012-08-30 Thu] periahs, periats: sudah clean JSON utk metadata dan result? dicache gak utk metadata? [#C]

  - seharusnya request ke metadata gak sebanyak call, jadi belum terlalu penting
    dicache.

* TODO [2012-07-31 Tue] periahs, periats: add option: when failing on coderefs, just remove/exclude the property instead of dying

  this is a more graceful degradation way for many cases.

* TODO [2012-11-09 Fri] periahs: option to allow/disallow passing special argument (or, specify list of allowed, list of disallowed)

  diperlukan untuk security, misalnya di spanel

* IDEA [2012-10-24 Wed] progany: format khusus untuk progany-la; periahs: parse format ini dan turn to $progress->update call instead of $log->{debug,...} calls

  agar nanti dapat ditampilkan oleh pericmd.

* TODO [2013-12-19 Thu] periahs, ri: beri informasi rate-limiting di riap, riap HTTP, spanel-sendmail, spanel-smtpd...

  - biar user tau, berapa lagi limitnya dalam 1 jam dan 24 jam
  - DONE utk spanel-smtpd (tapi baru di log akses doang, mestinya di http header
    jg kan ya, utk memberitahu user)
  - ref:
  - biasanya utk implementasinya (utk API calls) pake redis, pake mysql gitu berat
    di write-nya, ini sangat write intensive soalnya (per request).
  - http status jika over: 429 (too many requests). 503 (service unavailable)
    kayaknya kurang pas.
  - di twitter: 350/hour. google compute: 50k/day, 20/sec.
  - utk header http yg diberikan ke klien, github/vimeo pake x-ratelimit-limit &
    x-ratelimit-remaining. twitter pake x-rate-limit-{limit,remaining,reset} (yg
    reset adalah waktu sebelum limitnya direset). imgur pake
    x-ratelimit-user{limit,remaining,reset} dan
    x-ratelimit-client{limit,remaining}.

* TODO [2014-03-29 Sab] periahs: action2x yg gak penting seperti info, list, meta, child_metas gak perlu dilog complete responsenya, menuh2in log aja

  - yang penting sebenernya cuma call.

* TODO [2015-01-20 Tue] periahs, periahc: update to Rinci 1.1.71 (streaming input & output using coderef only)
* TODO [2015-01-03 Sat] periahs: peri-htserve: Pass more Plackup options.
* TODO [2015-01-03 Sat] periahs: peri-htserve: Pass more PSGI server options.
* TODO [2014-10-30 Thu] periahs: support partial input data

  - in ParseRequest middleware, check Content-Range HTTP req header and set
    arg_{len,part_start,part_len} Riap request keys
  - in Respond, when calling riap client, pass it to client

* TODO [2014-10-30 Thu] periahs: support partial result

  - pass HTTP Range (request range to server) to Riap request keys:
    res_part_{start,len}
  - translate result metadata property len, part_start, part_len to

* TODO [2014-10-30 Thu] periahs: support streaming input

  - dengan membaca request client dengan header Transfer-Encoding: chunked, lalu
    call function, dengan nilai argumen adalah objek yang dapat menerima method
    get() utk get data. method ini akan membaca psgi.in for more data (more
    chunks) dan baru undef jika dapat chunk dengan size 0 (yang berarti chunked
    transfer berakhir).

* TODO [2014-10-30 Thu] periahs: support streaming output

  - fungsi menghasilkan [200, OK, $fh, {stream=>1}]. ini ditranslate oleh server
    dengan return satu chunk dulu (dengan some marker?) [200, OK, "stream",
    {stream=>1}] lalu di chunk2x berikutnya mengirimkan data stream. riap::http
    client akan menerjemahkan "stream" menjadi objek yang dapat dipanggil utk get
    more data from chunk responses.
  - note: chunked transfer juga digunakan oleh logging, jangan sampe bentrok.

* TODO [2014-09-11 Thu] periahs: when logging, redact function arguments which has is_password property value of true
