* TODO [2015-01-08 Thu] cpansqlitemeta: deps: add option recursive
* TODO [2015-01-08 Thu] cpansqlitemeta: deps: numify/normalize version?
* TODO [2015-01-08 Thu] cpansqlitemeta: finish implementation of revdeps
* TODO [2015-01-08 Thu] cpansqlitemeta: extract more data: distribution abstract, license, release status, resources.

  Perhaps put it in a separate table dist_infos or something.
