* IDEA [2015-01-10 Sat] pmutils: pmuninst: option to uninstall prereqs when uninstalling a module?

  like in most linux package managers. for example, i'm uninstalling XPAN::Query.
  this should automatically uninstall App::XPANQueryUtils since it depends on
  that.

* TODO [2014-08-24 Sun] pmutils: pmdist utk find out dist of module (via remote request ke metacpan etc, tapi ada trik utk skip jika kita bisa search di pod mis utk my dists or cjm's)
* TODO [2014-08-24 Sun] pmutils: pmchanges utk liat changes file
