* TODO [2015-01-03 Sat] relpath: Option to set pwd.
* TODO [2015-01-03 Sat] relpath: Option to actually check the existence of files.
