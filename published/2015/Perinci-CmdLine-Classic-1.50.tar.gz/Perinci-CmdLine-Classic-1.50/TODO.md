* BUG [2015-04-10 Fri] sahutils, pericmd-classic: 'validate-with-sah -h' fails with pericmd-classic

  - gitbunch, fatten ok

* TODO [2015-03-26 Thu] pericmd-classic: what if we want to customize cleanser?

  example is in parse-ledger, where we want to customize cleanser with: -circular
  => [clone=>0]. in pericmd-lite 1.01 this is already possible because we expose
  'cleanser' as attribute. but pericmd-classic uses perirf to format result.
  
  so dfpj should perhaps observe some environment variable to configure dc-json.

* TODO [2015-03-11 Wed] pericmd-classic, pericmd-lite: put base classes' {attributes, methods} POD to our POD, using DZP:InsertBlock
* TODO [2015-02-25 Wed] pericmd-classic, pericmd-lite: show summary in help and 'cmd --subcommands'

  - summary from subcommand spec should be shown [done]
  - summary from function meta should also be shown if url is local

* TODO [2014-12-03 Wed] [#C] pericmd-classic: --help: underline entity in --opt=entity

  - di pericmd-lite agak ribet karena color codes membuat alignment string agak
    ribet dan harus pake Text::ANSI::Util dsb, skip aja dulu di pericmd-lite.
