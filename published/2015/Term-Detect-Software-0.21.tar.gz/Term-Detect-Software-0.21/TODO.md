* TODO [2015-01-03 Sat] termdetsw: Better detection of terminal emulator's background color

  By peeking into its configuration.
