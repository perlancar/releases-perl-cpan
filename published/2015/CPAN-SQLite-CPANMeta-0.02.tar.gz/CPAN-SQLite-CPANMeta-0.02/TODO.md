* TODO [2015-01-08 Thu] cpansqlite-cm: deps: add option recursive
* TODO [2015-01-08 Thu] cpansqlite-cm: deps: numify/normalize version?
* TODO [2015-01-08 Thu] cpansqlite-cm: finish implementation of revdeps
* TODO [2015-01-08 Thu] cpansqlite-cm: extract more data: distribution abstract, license, release status, resources.

  Perhaps put it in a separate table dist_infos or something.
