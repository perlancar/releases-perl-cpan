* TODO [2015-01-03 Sat] games-arrnum: Record and save high scores
* TODO [2015-01-03 Sat] games-arrnum: Save unfinished game
* TODO [2015-01-03 Sat] games-arrnum: Add some animation when moving tiles
