* TODO [2015-01-17 Sab] periswrap: support check_arg (Rinci 1.1.59)
* TODO [2015-01-17 Sab] periswrap: test argument validation for when stream=1 and there is submeta/element meta

  - i think stream should be ignored/assumed to be 0 for submetadata, this has not
    been done in the code.

* TODO [2014-10-07 Tue] periswrap: handler: lakukan extra processing spt trim space n typo hanya jika flag on. buat web form only for human error tp tdk jika lewat http api.
* IDEA [2015-01-06 Tue] periswrap, ri: args_as => 'scalar+hash' or 'hash+list'

  often we have one scalar main argument (or a list of arguments) but also have
  other arguments as options (though they are optional). examples:
  

      kill PID1, PID2, ...
      kill {signal=>'KILL'}, PID1, PID2, ...
  :

      module_path($module)
      module_path({find_pod=>1}, $module)
      module_path($module, {find_pod=>1, find_pmc=>1})
  
  this will make the simple case simpler (e.g. instead of
  module_path(module=>$module) which is to be honest a bit less DRY.
  
  the main argument(s) must be declared req=>1, pos=>0, (and greedy=>1 for list).

* TODO [2014-10-11 Sab] periswrap: pesan error belum translate, e.g.


      % LANG=id_ID.UTF-8 peri-run /Perinci/Examples/SubMeta/register_donors --date 2014-10-11
      ERROR 400: Invalid value for argument 'donor': Panjang harus minimal 1
  
  pesan error dari Data::Sah sudah translated, tapi periswrap belum translate
  pesan error. kalo pericmd ingin jadi fully translated library, periswrap juga
  harus generate translated error message.
