* IDEA [2014-08-08 Jum] game: word: ubah satu kata menjadi kata lain (mis: CORPS jadi PARTY dengan transform satu huruf satu huruf, mis: CORPS -> CORDS -> CARDS -> CARTS -> PARTS -> PARTY

  - di level yang rendah, kita kasih tau huruf2x yg terlibat, dan jumlah step-nya dikit.
