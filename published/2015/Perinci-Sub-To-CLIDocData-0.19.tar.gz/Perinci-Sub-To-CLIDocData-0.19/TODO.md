* TODO [2015-02-07 Sab] peris2clidocdata: improve/tweak usage line

  - instead of just: 'prog [options] <pos0> <pos1> ...'
  - list require options: 'prog --reqopt1 1 --reqopt2 2 [other options]'
  - from arg spec 'deps' property, e.g. (force depends on delete): 'prog [--delete [--force]]'
  - from func prop 'args_groups', rel=one_of: 'prog [--delete | --add | --edit]'
  - from func prop 'args_groups', rel=all: 'prog [--red=i --green=i --blue=i] --otheropts ...'

* TODO [2015-01-08 Thu] peris2clidocdata: include required options in usage line

  - example:

      cpandb-cpanmeta deps [options] <module>
  should be (because --cpan option is required)

      cpandb-cpanmeta deps --cpan <path> [options] <module>

* TODO [2014-12-02 Sel] peris2clidocdata: pakai altprop() & by default search for alt.env.cmdline summaries and descriptions, but if those do not exist revert to default

  - setelah periobj punya altprop().
  - jadi pertama nyari summary ke summary.alt.env.cmdline, baru summary. jika yang
    not, maka pertama cari di summary.alt.bool_env.not.cmdline, jika gak ada baru
    cari di summary.alt.bool.not.

* TODO [2014-11-22 Sab] peris2clidocdata, ri: provide category sorting options

  - kategori tertentu yang lebih penting bisa ditampilkan di awal, gak harus
    selalu alfabetikal. contoh di fatten:
  

      Debugging options
      Module selection options
      Options
      Output options
  
    sebaiknya (other terakhir, output duluan baru module selection, dsb):
  

      Output options
      Debugging options
      Module selection options
      Other options
  
  - demikian juga opsi tertentu contoh di fatten:

      --stripper
      --no-stripper-comment
      --no-stripper-pod
      --no-stripper-ws
  
    harusnya (opsi --stripper dulu dong ya disebutkan, baru )
  
    ini bisa pakai links misalnya, jadi stripper_comment, stripper_pod,
    stripper_ws kan link ke 'stripper'. pakai sorting berdasarkan dependency.
