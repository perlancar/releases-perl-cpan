* TODO [2015-01-04 Sun] gb: turn on logging if ipcsysopts gets logging feature
* TODO [2015-01-03 Sat] gb: Handle bare source repos (currently can't)
* TODO [2015-01-03 Sat] gb: Sync-ing to bare repos (e.g. with --backup) still produces error messages

  Although the sync process succeeds, the error messages (like C<< fatal: Not a
  git repository >>) might be confusing.
