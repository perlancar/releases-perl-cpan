* TODO [2015-02-07 Sab] ipcsysopts, ipcsysloc: add tests, including allowing default opts in 'use'
* WISHLIST [2015-01-04 Sun] ipcsysopts: option to overload backtick operator (when perl provides the mechanism)

  - currently backtick operator is not overloadable.
