* TODO [2015-02-25 Wed] pericmd-classic, pericmd-lite: show summary in help and 'cmd --subcommands'

  - summary from subcommand spec should be shown
  - summary from function meta should also be shown if url is local
