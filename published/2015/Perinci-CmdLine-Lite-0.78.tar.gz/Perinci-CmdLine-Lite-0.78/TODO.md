* TODO [2015-01-14 Wed] pericmd, pericmd-lite: perhaps an attribute to regulate whether error in config file result in fatal/abort or ignore the config?

  - currently it will die because error in Config::IOD::Reader is not trapped
  - perhaps the attribute/configuration should be put in Config::IOD::Reader?

* TODO [2015-01-11 Sun] pericmd, pericmd-lite: streaming output: support object with getitem() method (currently only getline() is supported)

  - according to Rinci spec, it should be supported

* IDEA [2015-01-09 Fri] pericmd, pericmd-lite: read per-subcommand environment variable? [#E]

  For subcommand, the default environment name is like above but before C<_OPT>,
  subcommand name is added (with the same conversion as program name). So for
  C<cpandb-cpanmeta index> the default environment name is
  C<CPANDB_CPANMETA_INDEX_OPT>.
  
  This setting can be overriden by the C<env_name> key for each subcommand.

* PENDING [2015-01-09 Fri] pericmd, pericmd-lite: add --no-env (like --no-config) to disable reading env vars? [#D]

  - it's a bit tricky, because the way it is now implemented, the env is prepended
    to the command-line *before* parsing arguments.

* TODO [2015-01-07 Wed] pericmd, pericmd-lite: Change config backend from IOD to Config::Tree (when Config::Tree is done)
* TODO [2014-08-27 Wed] pericmd-lite: support table data (TableDef) like in pericmd

  - the formatting routine in pericmd-lite also needs to read result metadata
    property result_format_options -> text, then see the table_column_types and
    table_column_orders keys.

* IDEA [2014-12-03 Wed] pericmd, pericmd-lite, glcomp, glsubc: autocorrect subcommand name, like in git etc ('gitbunch chek' -> 'Did you mean gitbunch check?)
* IDEA [2014-11-16 Sun] pericmd-lite: tutorial: how to show debugging (early)?


      PERL5OPT=-MLog::Any::Adapter=ScreenColoredLevel,min_level,trace

* TODO [2014-12-19 Fri] pericmd-lite: complete --config-path dengan dir atau *.conf saja
* TODO [2014-12-19 Fri] pericmd-lite: refactor: cara menampilkan usage disamakan dengan pericmd (ditarik ke pericmd-base)

  - di tiap common_opts ada key usage dan order

* TODO [2014-11-09 Sun] pericmd-lite: support logging to file

  - nanti jadi bisa switch: rsybak pake pericmd-lite
  - utk fb-mand, fb-bca perlu support logging to dir too
