* BUG [2015-01-07 Wed] pwp-ri, pleg: can't build because pwp-ri inserts OPTIONS POD section to bin/perl-example-die even though it should not (it's not a Getopt::Long::Complete or Perinci::CmdLine script)
* IDEA [2014-11-22 Sab] pwp-ri: OPTIONS for script: show example for each arg

  - nah ini gw agak2x torn between naruh di function's examples atau di arg spec?
  - kalo user ingin naruh per-arg examples juga harusnya diperbolehkan.
  - perlu ada modul utk process/display examples, karena dipake juga selain di
    POD, di pericmd --help.

* IDEA [2014-11-22 Sab] pwp-ri: OPTIONS for script: show See <other_arg> from arg's links.
* TODO [2014-12-16 Tue] dzp-ri-absfmeta, pwp-ri, shcompgen, app-genbashcompleter: recognize NO_PERICMD_SCRIPT tag
* TODO [2014-11-22 Sab] pwp-ri: OPTIONS for script: tweak: default jika pendek inline

  instead of selalu menampilkan verbatim paragraph:
  
   Default:
  
    "-"
  
  jika default pendek dan tidak mengandung karakter "<<" atau ">>", inlinekan aja.
  
   Default: C<<"-">>.
  
  dan jika default berupa string yang tidak mengandung 'karakter aneh', gak usah
  pake quote (gak usah didump sekalian):
  
   Default: C<->.
   Default: C</usr/bin/perl>
   Default: C<foo bar>
  

* TODO [2014-11-22 Sab] pwp-ri: OPTIONS for script: tweak: 'in' jika pendek (atau jika berupa list of scalars dengan bukan karakter aneh)

  - tanpa quotes
  - dan sort?
  - ini nanti dipake juga saat produce html/web-based help
