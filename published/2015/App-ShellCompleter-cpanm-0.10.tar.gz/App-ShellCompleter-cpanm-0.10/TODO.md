* TODO [2015-01-15 Thu] _cpanm, lcpan: need to refactor the way one uses Perinci::CmdLine::Util::Config

  - it's currently ugly

* TODO [2015-01-08 Thu] _cpanm: add query to external service (probably need to setup this service)

  - log ::
    + [2015-01-18 Sun] we have used lcpan for local, but for remote sources we
      also need a service. MetaCPAN::Client and CPANDB are not ideal because of
      slow response.
