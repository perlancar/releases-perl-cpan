* TODO [2015-03-03 Sel] periga-ary, pericmd-lite: ux: Improve error message when there are extra unassigned command-line arguments

  - probably by periga-ary providing func.err_type and pericmd reformat/re-word
    that error message

* TODO [2015-03-01 Sun] pericmd-lite, periswrap, periga-argv: (base class) implement args_groups
* WISHLIST [2015-02-28 Sab] pericmd-lite: do deps checking

  - perhaps move to

* TODO [2015-02-25 Wed] pericmd-classic, pericmd-lite: show summary in help and 'cmd --subcommands'

  - summary from subcommand spec should be shown
  - summary from function meta should also be shown if url is local

* IDEA [2015-01-21 Wed] pericmd, pericmd-lite: cli app that can receive json stream/stream input or json (table: aos, aohos)

  - on the function side, i think i still want function to just accept coderef, to
    be simple. pericmd framework is the one that converts the table to stream of
    records.
  - needs an input to select which we want: --input-format json-stream (the
    default) or --input-format. so --format should be --output-format? but this
    breaks compatibility.

* IDEA [2015-01-20 Tue] pericmd-lite: refactor: extract formatting functionality to a module

  - so it can be reused by fsql and 'table'

* BUG [2015-01-25 Min] pericmd, pericmd-lite: annoying: die message that are references are not displayed properly yet

  - for example, if i forgot to add 'result_naked=>1' to bin/pllines, it'll die:

      ERROR HASH(0x1b69d48):

* TODO [2015-01-14 Wed] pericmd, pericmd-lite: perhaps an attribute to regulate whether error in config file result in fatal/abort or ignore the config?

  - currently it will die because error in Config::IOD::Reader is not trapped
  - perhaps the attribute/configuration should be put in Config::IOD::Reader?

* TODO [2015-01-11 Sun] pericmd, pericmd-lite: streaming output: support object with getitem() method (currently only getline() is supported)

  - according to Rinci spec, it should be supported

* IDEA [2015-01-09 Fri] pericmd, pericmd-lite: read per-subcommand environment variable? [#E]

  For subcommand, the default environment name is like above but before C<_OPT>,
  subcommand name is added (with the same conversion as program name). So for
  C<cpandb-cpanmeta index> the default environment name is
  C<CPANDB_CPANMETA_INDEX_OPT>.
  
  This setting can be overriden by the C<env_name> key for each subcommand.

* PENDING [2015-01-09 Fri] pericmd, pericmd-lite: add --no-env (like --no-config) to disable reading env vars? [#D]

  - it's a bit tricky, because the way it is now implemented, the env is prepended
    to the command-line *before* parsing arguments.

* TODO [2015-01-07 Wed] pericmd, pericmd-lite: Change config backend from IOD to Config::Tree (when Config::Tree is done)
* IDEA [2014-12-03 Wed] pericmd, pericmd-lite, glcomp, glsubc: autocorrect subcommand name, like in git etc ('gitbunch chek' -> 'Did you mean gitbunch check?)
* IDEA [2014-11-16 Sun] pericmd-lite: tutorial: how to show debugging (early)?


      PERL5OPT=-MLog::Any::Adapter=ScreenColoredLevel,min_level,trace

* TODO [2014-12-19 Fri] pericmd-lite: complete --config-path dengan dir atau *.conf saja
* TODO [2014-12-19 Fri] pericmd-lite: refactor: cara menampilkan usage disamakan dengan pericmd (ditarik ke pericmd-base)

  - di tiap common_opts ada key usage dan order

* TODO [2014-11-09 Sun] pericmd-lite: support logging to file

  - nanti jadi bisa switch: rsybak pake pericmd-lite
  - utk fb-mand, fb-bca perlu support logging to dir too
