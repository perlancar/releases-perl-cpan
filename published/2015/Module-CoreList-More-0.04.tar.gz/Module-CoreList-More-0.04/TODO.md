* TODO [2015-04-14 Sel] corelist-more: reimplement is_core (faster)
