* TODO [2015-01-03 Sat] games-wordguess: Write statistics file
* TODO [2015-01-03 Sat] games-wordguess: Colors
* TODO [2015-01-03 Sat] games-wordguess: Add timeout for each guess
