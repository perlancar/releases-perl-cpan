* TODO [2015-01-03 Sat] tchart: More chart types
* TODO [2015-01-03 Sat] tchart: Colors
* TODO [2015-01-03 Sat] tchart: Resampling

  Reduce data points, for example I have 1000 numbers that I want to display in a
  80-column chart or sparkline.
* TODO [2015-01-03 Sat] tchart: Formatting of data (or label)

  Using L<Data::Unixish> (like in L<Text::ANSITable>), and specifiable from an
  environment variable.
