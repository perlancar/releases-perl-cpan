* IDEA [2014-12-03 Wed] pericmd, pericmd-lite, glcomp, glsubc: autocorrect subcommand name, like in git etc ('gitbunch chek' -> 'Did you mean gitbunch check?)
