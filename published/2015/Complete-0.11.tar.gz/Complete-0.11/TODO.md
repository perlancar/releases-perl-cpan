* IDEA [2014-12-03 Wed] pericmd, pericmd-lite, glcomp, glsubc: autocorrect subcommand name, like in git etc ('gitbunch chek' -> 'Did you mean gitbunch check?)
* IDEA [2014-12-03 Wed] perl module/pod: Complete::Tutorial
* TODO [2015-01-05 Sen] compzsh, peris2zshcomp: zsh also supports description on completion entries (like fish), how to show this?

  - putting it in STDOUT, prefixed with tab after each entry, a la fish, does not
    work. that's if we are using this mechanism:
  

       $func_name() { read -l; local cl="\$REPLY"; read -ln; local cp="\$REPLY"; reply=(`COMP_SHELL=zsh COMP_LINE="\$cl" COMP_POINT="\$cp" $command_name`) }
  :

       compctl -K $func_name $command_name
  
  - but it might work with other mechanism
  - the way description is added in zsh is via the 'compadd' builtin command
    (documented in 'zshcompwid' manpage). we need to call 'compadd' in our
    completion function.

* IDEA [2015-01-03 Sat] compdist: $OPT_SHORTCUT_PREFIXES like in Complete::Module?
* IDEA [2015-01-02 Fri] perl module: Complete::File

  - maybe pindahkan Complete::Util::complete_file ke sini (tapi tetap provide stub
    di computil utk tidak break backward compat)
  - provide more options/shortcuts, e.g. hanya provide archive saja (dan tipe
    archive tertentu), compressed file saja, images saja, videos saja, audio saja,
    dsb.

* IDEA [2014-12-15 Mon] wordlist: implement opsi -U, -L, -I (pake xpan or later Complete::CPAN utk provide completion)
* IDEA [2014-12-15 Mon] ekstrak rutin list cpan modules ke Complete::CPAN

  - selain pake XPAN (kelemahannya adalah lambat di awal), bisa juga pake cara
    lain

* IDEA [2014-12-04 Thu] genbashcomp: alternatif lebih mudah daripada Getopt::Long::Complete

  - kita tambahin direktif mis:
  
  masih belum decide gimana exact syntax-nya, biar fleksibel dan precise tanpa
  parsing sendiri
  
  # OPT: --flag
  # OPT: --file=s, -f    complete: file(*.exe) | dir
  # OPT: --module=s      complete: perlmod(namespace=Foo)
  # OPT: --dist=s        complete: perldist
  # OPT: --url=s, -u     complete: riap_url
  # ARG: complete: perlmod
  
  # ARG: complete: perlmod
  
  - program parse its own options (dengan Getopt::Long, whatever)

* IDEA [2014-11-30 Sun] perl module: Complete::Module::XXX (name? Project?) - complete dengan nama module yang dipake di sebuah project

  - biar cepet, search dengan regex aja (atau pake Compiler::Lexer), ada limit
    batas waktu atau jumlah file, ada caching.

* IDEA [2014-11-29 Sab] perl module: Complete::Package::Debian

  - complete package
  - ada pilihan installed package atau search di repos

* IDEA [2014-11-29 Sab] perl module: Complete::Package::FreeBSD [#E]

  - complete package
  - ada pilihan installed package atau search di repos

* IDEA [2014-11-29 Sab] perl module: Complete::Package::Ubuntu [#D]

  - complete package
  - ada pilihan installed package atau search di repos

* IDEA [2014-11-29 Sab] perl module: Complete::Package::LinuxMint [#E]

  - complete package
  - ada pilihan installed package atau search di repos

* IDEA [2014-11-29 Sab] perl module: Complete::Perl (name? sebab udah ada Complete::Module)

  - complete perl builtins
  - complete perl functions in a certain package
  - complete perl variables or other stuffs in a certain package
  - complete open filehandles?

* IDEA [2014-11-14 Jum] genbashcomp: parse pod or manpage

  - di section OPTIONS.
  - kalo ada yg kayak gini (contoh wget): '-i file', '--input-file=file' maka kita
    bisa complete value adalah filename. '-t number' maka hanya complete dengan
    number (periscomp sih udah bisa otomatis complete integer digit by digit, tapi
    di sini kita perlu add similar routine for GetOptionsWithCompletion).

* IDEA [2014-07-02 Wed] perl module: Complete::DBI

  - complete table names, field names, row value, ...
  - diekstrak dari DBIx::FunctionalAPI

* IDEA [2014-07-02 Wed] perl module: Complete::CPAN::Mini (name? Complete::CPAN::Local? Complete::CPAN::Packages?)

  - complete by parsing from 02packages.details.txt.gz, harusnya cuma 1-2 detik
    kok, setelah itu kita cache.

* IDEA [2014-07-02 Wed] perl module: Complete::CPAN

  - complete module name, dist name, author name, ...

* IDEA [2014-07-02 Wed] perl module: Complete::Debian

  - complete installed package name (deb), complete availbalbe package name (dari
    apt-cache search),

* IDEA [2014-06-27 Fri] periscomp: complete_from_schema: completion for number with prefix, e.g. 30G/30T/30K/30M (lihat dari range min-max mana yg possible/most likely)
* TODO [2014-12-23 Sel] genshcomp: terima hint bahwa ini getopt-long-based or pericmd-based, walaupun di skripnya ga ada use Getopt::Long atau use Perinci::CmdLine

  - contoh: riap (di bin/riap cuma ada: use App::riap; $shell=App::riap->new;
    $shell->cmdloop; ini tetep bisa kita dump kok.

* BUG [2014-12-13 Sat] periscomp, compgl: completion of short option belum benar

  - harusnya -a -> -ap -> -apq (semua short option yang belum dimention dan tidak
    require args), ini langsung complete -a <spasi>.

* TODO [2014-12-09 Tue] peris2{fish,zsh,bash}comp: support cli with subcommands?
* BUG [2014-12-05 Fri] pmutils/periscomp: saat complete module, direktori (yg bukan valid module prefix) juga terinclude?

  di pmdoc etc, dir keinclude juga, contoh ada foo/ dan foo-bar/ di curdir, kenapa
  pmdoc foo<tab> tetep complete foo-bar/ ya?, tapi kalo pake foo-, gak.
  
  trus kalo pmdoc <tab> dan di curdir ada direktori2x seperti -a, +b, (c, itu
  semua diinclude! sebenernya nyampe sampe complete_file gak sih?

* TODO [2014-12-01 Mon] perl module: Complete::Hostname
* TODO [2014-12-01 Mon] perl module: Complete::Net::Interface
* TODO [2014-12-01 Mon] perl module: Complete::Path? (dari daftar item di PATH)

  - log ::
    + [2014-12-28 Sun] rename dari Complete::Path jadi Complete::Var::PATH?

* TODO [2014-11-06 Kam] periscomp: don't convert wildcard when completing filenames

  - e.g. bash lets you do this:
  

      cmd ~/Doc*/Pic*/foo<tab>
  
  can complete 'foo' in ~/Documents/Pictures/ when that is the only directory that
  matches. the wildcard doesn't get converted. currently periscomp does this:
  

      cmd Doc*
  
  either will complete to ['Documents'] or (if there is more than one match
  ['Documents','Docopt'], will change the word from 'Doc*' to 'Doc' (the *
  disappears).
