* TODO [2015-01-03 Sat] setop: Add option --record-separator
