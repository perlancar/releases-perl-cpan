* TODO [2015-01-28 Wed] progany-ts, progany-tpc: only do fixups when fh is STDOUT/STDERR, there's no need to do fixups/patches if one/both is not to screen [#D]
* TODO [2015-01-28 Wed] progany-ts: support colors (including color change during spinning)
* TODO [2015-01-28 Wed] progany-ts: support wide characters
