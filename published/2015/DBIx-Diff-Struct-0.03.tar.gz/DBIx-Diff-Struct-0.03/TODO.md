* TODO [2015-01-03 Sat] dbix-diffs: Support more extensive column diff-ing

  Beside just type name, nullable, and octet length/decimal digits.
* TODO [2015-01-03 Sat] dbix-diffs: Options to compare column ordinal position?
* TODO [2015-01-03 Sat] dbix-diffs: Support views
* TODO [2015-01-03 Sat] dbix-diffs: Compare indices
