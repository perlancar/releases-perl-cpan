* TODO [2015-03-19 Thu] short: add tab completion, this is the main feature
