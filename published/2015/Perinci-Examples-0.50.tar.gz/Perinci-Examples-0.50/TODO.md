* TODO [2015-01-03 Sat] perieg: Example for argument submetadata and element submetadata.
* TODO [2015-01-03 Sat] perieg: Example for C<stream> property.
* TODO [2015-01-03 Sat] perieg: Example for C<partial> property.
