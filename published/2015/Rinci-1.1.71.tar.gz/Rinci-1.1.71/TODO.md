* IDEA [2015-01-16 Fri] ri: when streaming input, function should accept coderef (only); when streaming output, function should produce coderef (only)

  - this is cleaner and much simpler on the function side, then having to deal
    with glob, filehandle, object that accept getline/getitem, or tied array
  - caller needs only to call coderef to repeatedly get the data.
  - in the future if we want to support async? caller can pass an argument, e.g.
    1, then coderef can return array [$can_read, $data] or whatever.
  - log ::
    + [2015-01-16 Fri] done, i've implemented this in pericmd-base, but haven't
      updated the spec yet.

* BUG [2015-01-07 Wed] pwp-ri, pleg: can't build because pwp-ri inserts OPTIONS POD section to bin/perl-example-die even though it should not (it's not a Getopt::Long::Complete or Perinci::CmdLine script)
* TODO [2014-12-19 Jum] ri: add perisprop-validation to use perl code to validate.

  in the POD, add note that this is only when needed. we still encourage 'schema'
  property instead.

* IDEA [2015-01-06 Tue] periswrap, ri: args_as => 'scalar+hash' or 'hash+list'

  often we have one scalar main argument (or a list of arguments) but also have
  other arguments as options (though they are optional). examples:
  

      kill PID1, PID2, ...
      kill {signal=>'KILL'}, PID1, PID2, ...
  :

      module_path($module)
      module_path({find_pod=>1}, $module)
      module_path($module, {find_pod=>1, find_pmc=>1})
  
  this will make the simple case simpler (e.g. instead of
  module_path(module=>$module) which is to be honest a bit less DRY.
  
  the main argument(s) must be declared req=>1, pos=>0, (and greedy=>1 for list).

* IDEA [2014-12-19 Jum] perl module: App::GenPerinciCmdLineCLI [#D] (basically Dist::Zilla::Plugin::Rinci::ScriptFromFunc, but outside of dzil)

  - blurb: a CLI framework where you don't have to write a CLI :)

* TODO [2015-01-03 Sat] testri: Add option -l (like prove)?
* IDEA [2014-11-28 Fri] ri: summary.alt.{plural,singular,singplural}

  - sama seperti pasangan summary.alt.{pos,neg,posneg}
  - opsi --arrayofstr (mis: --file) menggunakan summary singular.
    --arrayofstr-json menggunakan summary plural (atau summary aja, jika gak ada).
  - log ::
    + [2014-12-02 Sel] implemented in peris2cliospec

* IDEA [2014-11-22 Sab] ri: per-arg examples [#D]

  contoh:

      exclude_dist => {
          summary => 'Exclude all modules of a dist',
          schema => ['array*' => of => 'str*'],
          examples => [
              # bisa pake argv atau args, seperti function's examples:
              {
                  argv => [qw/--exclude-dist Foo::Bar --exclude-dist Baz-Qux/],
                  summary => 'Blah',
              },
              # bisa juga cuma specify value
              {
                  value => ['Foo::Bar', 'Baz-Qux'],
                  summary => 'Blah',
              },
          ],
      }
  
  nanti yang value bisa disediakan untuk --exclude-dist juga utk
  --exclude-dist-json.

* IDEA [2014-11-22 Sab] pwp-ri: OPTIONS for script: show example for each arg

  - nah ini gw agak2x torn between naruh di function's examples atau di arg spec?
  - kalo user ingin naruh per-arg examples juga harusnya diperbolehkan.
  - perlu ada modul utk process/display examples, karena dipake juga selain di
    POD, di pericmd --help.

* IDEA [2014-11-22 Sab] pwp-ri: OPTIONS for script: show See <other_arg> from arg's links.
* IDEA [2014-11-01 Sat] ri, periga-argv, pericmd: suppress accepting --foo-json/--foo-yaml even though arg is array etc

  contoh, gw ingin accept file sebagai --file F1 --file F2 saja, gak mau user bisa
  --file-json '["F1","F2"]'. terutama utk array of simple scalar, gw hanya ingin
  itu.
  
  tentu saja kita bisa matikan per_arg_json, per_arg_yaml. mungkin perlu ada
  per-arg optionnya. dan belum ada cara utk specify ini dari pericmd.

* IDEA [2014-04-04 Fri] pericmd, ri: how to specify default is dry_run?

  - so, to actually do stuffs, cmd --nodry-run, or func(-dry_run=>0).

* IDEA [2014-08-15 Fri] ri: cmdline: untuk fungsi yang return bool status false/true, ada opsi utk set exit code non-zero jika false


      result => {
          schema => 'bool',
      }
  

       % check-palindrome foo; # dan exit 1
       Not a palindrome
       % check-palindrome apa; # exit 0
       Palindrome
  
  instead of:
  

       % check-palindrome foo; # exit 0, karena [200,"OK",0]
       0
       % check-palindrome apa; # exit 0, karena [200,"OK",1]
       1
  
  bisa juga di result metadata sih, tapi gw sedikit lebih prefer di function
  metadata, mis:
  

      x.perinci.cmdline.whatever => 1

* IDEA [2014-08-15 Fri] ri: cmdline: result metadata prop: text to display instead of result

  contoh, fungsi seperti check_palindrome() kalo dipake di perl baiknya return
  bool:
  

       check_palindrome("foo"); # -> 0
       check_palindrome("apa"); # -> 1
  
  tapi cmdline enaknya show nicer message and status kali ya (seperti grep, supaya
  skrip shell bisa do something accordingly)?
  

       % check-palindrome foo; # dan exit 1
       Not a palindrome
       % check-palindrome apa; # exit 0
       Palindrome
  
  instead of:
  

       % check-palindrome foo; # exit 0, karena [200,"OK",0]
       0
       % check-palindrome apa; # exit 0, karena [200,"OK",1]
       1
  
  tadinya gw berpikir result metadata seperti ini:
  

       [200, "OK", $is_palindrome, {"cmdline.result" => ($is_palindrome ? "Palindrome" : "Not a palindrome")}]
  
  sementara kalo mau melakukan hal ini, bisa menggunakan "cara manual":
  

       if ($args{-cmdline}) { # running under CLI
           return ...;
       } else {
           return ...;
       }

* IDEA [2014-04-09 Rab] ri: func: deps property: exec: accept array? [#E]

  cuma utk mempersingkat sintaks aja sih.
  

          deps => {
              all => [
                  {exec => 'cpanm'},
                  {exec => 'dzil'},
                  {exec => 'git'},
                  {exec => 'lint-prereqs'},
                  {exec => 'rm'},
              ],
  
  bisa jadi:
  

          deps => {
              exec => [qw/cpanm dzil git lint-prereqs rm/],
          },
  
  atau, bikin dep clause baru: execs?

* TODO [2014-12-16 Tue] dzp-ri-absfmeta, pwp-ri, shcompgen, app-genbashcompleter: recognize NO_PERICMD_SCRIPT tag
* TODO [2014-11-22 Sab] peris2clidocdata, ri: provide category sorting options

  - kategori tertentu yang lebih penting bisa ditampilkan di awal, gak harus
    selalu alfabetikal. contoh di fatten:
  

      Debugging options
      Module selection options
      Options
      Output options
  
    sebaiknya (other terakhir, output duluan baru module selection, dsb):
  

      Output options
      Debugging options
      Module selection options
      Other options
  
  - demikian juga opsi tertentu contoh di fatten:

      --stripper
      --no-stripper-comment
      --no-stripper-pod
      --no-stripper-ws
  
    harusnya (opsi --stripper dulu dong ya disebutkan, baru )
  
    ini bisa pakai links misalnya, jadi stripper_comment, stripper_pod,
    stripper_ws kan link ke 'stripper'. pakai sorting berdasarkan dependency.

* TODO [2014-11-22 Sab] pwp-ri: OPTIONS for script: tweak: default jika pendek inline

  instead of selalu menampilkan verbatim paragraph:
  
   Default:
  
    "-"
  
  jika default pendek dan tidak mengandung karakter "<<" atau ">>", inlinekan aja.
  
   Default: C<<"-">>.
  
  dan jika default berupa string yang tidak mengandung 'karakter aneh', gak usah
  pake quote (gak usah didump sekalian):
  
   Default: C<->.
   Default: C</usr/bin/perl>
   Default: C<foo bar>
  

* TODO [2014-11-22 Sab] pwp-ri: OPTIONS for script: tweak: 'in' jika pendek (atau jika berupa list of scalars dengan bukan karakter aneh)

  - tanpa quotes
  - dan sort?
  - ini nanti dipake juga saat produce html/web-based help
