* TODO [2015-03-19 Thu] ledgerp: tasks

  - parse historical price (P line)
  - parse (ignore?) some directives:
    + account? + subdirectives
    + apply account
    + alias?
    + bucket (default account to balance transaction)
  - spectest: test round-trip when parser gets as_string() capability

* BUG [2013-08-07 Wed] ledgerp: gagal mengenali commodity (CT report)

  - karena belum compliant sih, harus reimplement yg lebih bener, plus gw mau
    ganti jadi line-based dan handwritten biar lebih cepet. dan gak perlu
    array-based karena gak terlalu save memory.
