* TODO [2015-01-03 Sat] perisgen-acctbl-dbi: Generate table_spec from database schema, if unspecified
