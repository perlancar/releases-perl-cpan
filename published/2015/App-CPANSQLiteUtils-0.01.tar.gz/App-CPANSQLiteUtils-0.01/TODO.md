* TODO [2015-01-09 Fri] cpansqliteutils: share config file with cpandb-cpanmeta
