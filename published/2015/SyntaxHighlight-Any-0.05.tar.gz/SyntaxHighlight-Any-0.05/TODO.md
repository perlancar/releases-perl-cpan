* TODO [2015-01-03 Sat] synh-any: Option to select preferred (or change choosing order of) backends
* TODO [2015-01-03 Sat] synh-any: Option: color theme
* TODO [2015-01-03 Sat] synh-any: Function to detect/list available backends
