* TODO [2015-01-03 Sat] ciodr: Add attribute: C<allow_dupe_section> (default: 1).

  Add attribute to set behaviour when encountering duplicate key name? Default is
  create array, but we can also croak, replace, ignore.
