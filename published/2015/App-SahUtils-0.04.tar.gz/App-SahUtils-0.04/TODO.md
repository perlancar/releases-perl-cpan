* TODO [2015-04-03 Fri] sahutils: script to generate human message (just a compiler option to validate-with-sah perhaps?)
* TODO [2015-04-03 Fri] sahutils: validate-with-sah: --data-file, --multiple-data-file
