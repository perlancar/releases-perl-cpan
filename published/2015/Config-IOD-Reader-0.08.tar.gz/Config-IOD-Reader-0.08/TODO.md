* TODO [2015-03-11 Wed] le, ciod, ciodr: take a look at Math::Calc::Parser, its code has a simple ad-hoc regexp-based parser which can perhaps be used

  the parser can only parse math operations, e.g. + * / % ^ , parenthesis
  functioncall. but we can extend this a bit.
  
  the upside is: the code is simple and startup overhead is low (<0.01s), compared
  to using Marpa or Regexp::Grammars.
  
  it uses Math::Complex, the module should be delay-loaded.

* TODO [2015-01-03 Sat] ciodr: Add attribute: C<allow_dupe_section> (default: 1).

  Add attribute to set behaviour when encountering duplicate key name? Default is
  create array, but we can also croak, replace, ignore.
