* IDEA [2014-11-16 Sun] pericmd-lite: tutorial: how to show debugging (early)?


      PERL5OPT=-MLog::Any::Adapter=ScreenColoredLevel,min_level,trace

* TODO [2014-12-19 Fri] pericmd-lite: complete --config-path dengan dir atau *.conf saja
* TODO [2014-12-19 Fri] pericmd-lite: refactor: cara menampilkan usage disamakan dengan pericmd (ditarik ke pericmd-base)

  - di tiap common_opts ada key usage dan order

* TODO [2014-11-09 Sun] pericmd-lite: support logging to file

  - nanti jadi bisa switch: rsybak pake pericmd-lite
  - utk fb-mand, fb-bca perlu support logging to dir too
