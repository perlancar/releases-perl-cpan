* IDEA t[2015-01-08 Thu] comppath: something like github file viewer, if there is only a single subdir, complete directly with it

  - for example:

      % foo CPA<tab>
    if there is only CPAN/ (single completion), CPAN/Critic/ (single completion),
    CPAN/Critic/Module/ and CPAN/Critic/Module/Abstract then directly show it
    instead of user having to press Tab four times.

* TODO [2015-01-03 Sat] comppath: recursive matching

  **/Util to match: List/Util, CHI/Util, Class/Factory/Util, and so on
