* TODO [2015-01-03 Sat] compman: read/parse index.db?
