* TODO [2015-01-03 Sat] tautil: ta_split($re, $text)
* TODO [2015-01-03 Sat] tautil: ta_match($re, $text)

  Regex search.
* TODO [2015-01-03 Sat] tautil: ta_replace($re, $str, $text) (and ta_replace_all)

  Regex substitution.
