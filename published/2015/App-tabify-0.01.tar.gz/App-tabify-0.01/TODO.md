* TODO [2015-01-31 Sab] tabify: -i and -i.ext (like perl) doesn't work yet
* TODO [2015-01-31 Sab] tabify: implement --(no)indent-only
