* TODO [2015-01-03 Sat] nauniq: Add option: --record-separator
* TODO [2015-01-03 Sat] nauniq: Support more C<uniq> options: --skip-fields (-f), --zero-terminated (-z).
* TODO [2015-01-03 Sat] nauniq: Allow specifying memory limit?

  Using Tie::Cache's MaxBytes option.
* IDEA [2015-01-03 Sat] nauniq: Add debugging option: print memory usage at the end of run
* IDEA [2015-01-03 Sat] nauniq: Add debugging option: print whenever forget pattern matches
