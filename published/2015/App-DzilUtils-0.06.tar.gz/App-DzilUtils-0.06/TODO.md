* IDEA [2014-12-15 Mon] dzilutils: list-dzil-plugins: tambahkan opsi --detail utk tampilkan role dari tiap plugin
* IDEA [2014-12-15 Mon] dzilutils: list-dzil-roles: add opsi --detail utk menampilkan plugin mana aja yg pake sebuah role
* IDEA [2014-12-14 Sun] dzilutils, weaverutils: list plugins on cpan, install & uninstall

  - idenya sama seperti di wordlist, berbasiskan modul dengan namespace tertentu.
  - bisa juga diterapkan di ansitable colortheme/borderstyle modules.
  - mungkin fungsionalitas ini bisa diekstrak ke dalam role.
  - gunakan xpan!
