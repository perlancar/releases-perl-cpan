* TODO [2014-06-12 Thu] orgp: parse statistics/progress cookies

  ref: http://orgmode.org/manual/Checkboxes.html
  - ada 2 macam ([0/0] dan [0%])
  - bisa muncul di headline maupun di list item
  - bisa muncul lebih dari sekali, gak perlu spasi, bisa di mana aja)

      * headline [/]
      * headline [%]
      * headline[0/2]
      * [/]headline[19%]

* TODO [2014-08-28 Thu] orgp: support parallel todo sets [#C]

  - saat ini sih gak terlalu pengaruh, hanya pengaruh utk cycling aja.

      #+TODO: A B | C
      #+TODO: D E | F
  
  orgp sudah bisa memparsing semua ini dan hasilnya todo_states => [A,B,D,E] dan
  done_states=>[C,F]. karena kita tidak menyediakan method utk cycling, maka gak
  ada gunanya juga tau sets dari mana.
