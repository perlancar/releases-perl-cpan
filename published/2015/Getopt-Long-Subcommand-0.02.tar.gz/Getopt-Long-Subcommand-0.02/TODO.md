* IDEA [2014-12-03 Wed] pericmd, pericmd-lite, glcomp, glsubc: autocorrect subcommand name, like in git etc ('gitbunch chek' -> 'Did you mean gitbunch check?)
* TODO [2015-01-03 Sat] glsubc: Hooks

  Hooks (when there is missing subcommand, when Getopt::Long::GetOptions fails,
  ...).

* TODO [2015-01-03 Sat] glsubc: Autohelp.

  With summaries already in the spec, it's easy to generate useful help
  message.

* TODO [2015-01-03 Sat] glsubc: autoversion.
* TODO [2015-01-03 Sat] glsubc: Suggest correction for misspelled subcommand ('Did you mean foo?').
