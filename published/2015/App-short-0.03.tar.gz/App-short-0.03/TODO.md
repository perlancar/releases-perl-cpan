* TODO [2015-03-19 Thu] short: rename short AND long name all at once
* WISHLIST [2015-03-19 Thu] short: 'rename' subcommand to rename short name, and help when there is a rename of short name

  - rename in todo list
  - rename in other places?
