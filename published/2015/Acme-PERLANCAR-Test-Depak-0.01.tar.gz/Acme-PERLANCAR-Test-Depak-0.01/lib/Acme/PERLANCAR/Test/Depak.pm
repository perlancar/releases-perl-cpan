package Acme::PERLANCAR::Test::Depak;

our $DATE = '2015-10-21'; # DATE
our $VERSION = '0.01'; # VERSION

1;
# ABSTRACT: Test module

__END__

=pod

=cut
