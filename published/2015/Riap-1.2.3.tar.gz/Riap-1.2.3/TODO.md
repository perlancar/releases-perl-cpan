* TODO [2015-01-20 Tue] periap: update to Rinci 1.1.71 (streaming input & output using coderef only)
* TODO [2015-01-09 Fri] compfile, compriap, computil: when Complete's OPT_DIG_LEAF option has been rethought and no longer experimental, expose it
* TODO [2014-07-02 Wed] pericmd: opsi utk daemonize diri di akhir run, listen di unix socket riap::http

  uri (bisa diatur, default '/pericmd' masih belum mantep):
  /pericmd/list_subcommands ; gak bener2x perlu
  /pericmd/list_common_opts ; gak bener2x perlu
  /pericmd/run       argv=(client ngirim @ARGV)
  /pericmd/complete  cmdline=(client ngirim COMP_LINE), point=(client ngirim COMP_POINT, hasilnya json)
  
  - package dan %SPEC digenerate dynamically
  - client adalah Perinci::CmdLine::Client, a very lightweight containing just
    HTTP::Tiny::UNIX (and JSON + Complete::Bash utk completion).
  - kalo perlu (perlu!) formatting juga dilakukan di sisi server, klien sudah
    menerima hasilnya saja.
  - tapi bagaimana dengan streaming interface?
