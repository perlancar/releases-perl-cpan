* TODO [2015-01-03 Sat] pfind: Option to sort result.
* TODO [2015-01-03 Sat] pfind: Search by PPID.
* TODO [2015-01-03 Sat] pfind: Search by GID (what about additional/extra groups?).
* TODO [2015-01-03 Sat] pfind: Search by priority.
* TODO [2015-01-03 Sat] pfind: Search by start time.
* TODO [2015-01-03 Sat] pfind: Search by memory size.
* TODO [2015-01-03 Sat] pfind: Search by controlling terminal.
* TODO [2015-01-03 Sat] pfind: Search all descendants of a process.
* TODO [2015-01-03 Sat] pfind: Search all parent processes of a process

  Thus subsuming the functionality of and rendering L<SHARYANTO::Proc::Util>
  unnecessary.
* TODO [2015-01-03 Sat] pfind: Write CLI utility C<pfind>, similar to C<pgrep>.

  - Just as a proof-of-concept.
  - Like C<pgrep>, Can also send signal in addition to listing processes.
