# just an empty module for testing
package Bar;

1;
