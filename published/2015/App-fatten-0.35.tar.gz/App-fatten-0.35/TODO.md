* TODO [2015-04-12 Min] fatten: solve XS problems
* TODO [2015-04-11 Sab] fatten: add --test-perl-path?_
* TODO [2015-04-12 Min] fatten: test: allow some modules

  e.g. LWP::UserAgent (and all modules that it loads) + LWP::Protocol::https
  (because XS modules can't be fatpacked anyway)

* TODO [2015-03-24 Tue] fatten: add tests!
* TODO [2014-12-19 Jum] fatten: create default profile for pericmd, pericmd-lite apps (if detected script is using one of those)
* TODO [2014-12-19 Jum] fatten: option (subcommand?) to test result

  allow specifying args (already there), allow specifying expected result and
  expected exit code.
  
  note that we can use lib::core::only for this.
  
  option to fatpack *and* test.

* IDEA [2014-04-14 Mon] fatten: (or perhaps fatpacker?) option to do text compression first

  - tapi line number jadi kacau, biarin lah ya, ini pilihan.
  - alternatif:
    + Compress::LZF_PP
