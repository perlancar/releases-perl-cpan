* IDEA [2015-03-30 Mon] orgutils: complete --has-tags with tags found in org document (but this could take some time for larger docs)
* IDEA [2015-03-30 Mon] orgutils: complete --state with todo states found in org document (but this could take some time for larger docs)
* BUG [2015-03-28 Sab] orgutils: offset showing is off for anniversary/todo

  for example, if today is [2015-03-28 ] and there is an anniversary for
  [2015-03-29 ], it will show 'Today (Sun)' even though today is Sat and the
  anniversary is for tomorrow.

* IDEA [2012-10-04 Thu] orgutils: list-org-contacts

  mencari dari headline ataupun bulletted list, coba parsing2x. nama, tag, phones
  (/cell/, /hp/, /phone/, values resembling phone number; parse the phone
  numbers), birthdays, address, notes. output dalam bentuk array.

* IDEA [2012-10-04 Thu] orgutils: convert array/list to org headlines
* IDEA [2012-10-04 Thu] orgutils: convert list/table data to org contact

  formatnya standar sesuai org-contacts bikinan julien danjou? format gw sendiri?

* IDEA [2013-08-17 Sab] orgutils: (list-org-todos): reminder dengan kondisi tertentu (mis: stok obat papa mau abis)

  - contoh (remmod=reminder module):

      * TODO refill obat papa   :remmod_obat:
      - stok irbesartan :: 20
      - stok coralan :: 5
      - stok coralan ::
      * TODO refill piracetam
      - note: harga Rp xxx/tablet di apotik andir, Rp xxx di apotik eureka, biasanya suka abis kalo di apotik eureka
  di mana nanti ada App::ListOrgTodos::Reminder::obat di mana ada fungsi
  remind($headline_object) yang return true jika ada field /^stok .+/ yang
  nilainya numerik di bawah 10.
  
  - atau (directly embed perl code in the org document), mis:

      * TODO refill obat papa   :remmod_obat:
      - :remind (code translation) :: ada children berupa list dan ada description list yg desc_term nya /^stoc?k .+/ dan nilainya numerik di bawah 10, return "stok X < 10"
      - :remind :: grep { $_-> }
      - stok irbesartan :: 20
      - stok coralan :: 5
      - stok coralan ::
  

* IDEA [2014-12-23 Sel] orgutils: list-org-todos: option to snooze some notification for X days
