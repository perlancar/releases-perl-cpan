* BUG [2014-12-19 Fri] trash-u: completion bug: trash-u <tab> belum complete files

  - kemungkinan karena pake default_subcommand
  - completion-nya masih menampilkan option + subcommands, berarti belum ngeh
    dengan default_subcommand
