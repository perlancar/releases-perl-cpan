* TODO [2015-04-01 Rab] pause-simple: add proxy support

  - aside from $ua->env_proxy, accept a common argument

* IDEA [2015-03-25 Wed] pause-simple: register subcommand

  - user/pass not required
  - just submit to https://pause.perl.org/pause/query?ACTION=request_id

* TODO [2015-02-05 Thu] pause-simple: list: add sorting options
* WISHLIST [2015-03-18 Wed] pause-simple: subcommand to delete all dev releases?
* WISHLIST [2015-02-06 Fri] pause-simple: add completion for delete & undelete & reindex: file argument (perform list_files then cache it for a few minutes)

  - CHECKSUMS need not be included because it's not deleteable
  - for reindex, ~*.readme~ are also not included.

* TODO [2015-02-06 Fri] pause-simple: add delete-dist subcommand which will delete all Dist-Name-*.{tar.gz,meta,readme} files
* TODO [2015-02-05 Thu] pause-simple: implement the rest of the functions: set_password, set_account_info

  - log ::
    + [2015-02-06 Fri] done: delete, undelete, reindex.

* TODO [2015-02-05 Thu] pause-simple: implement (get_)?account_info function
* TODO [2015-02-05 Thu] pause-simple: implement permission-related functions [#C]

  i seldom use this though
