* WISHLIST [2015-01-29 Thu] lcpan: configuration: author (tell the program who/which cpan author the user is, this will be used for various purposes)
* WISHLIST [2015-01-29 Thu] lcpan: plugin: after update, alert if there is a new dist that depends/uses on one of my modules
* WISHLIST [2015-01-29 Thu] lcpan: maintain some watchlist for some modules/dists, and alert if there is a new version (or module/dist is deleted from mirror, etc)
* WISHLIST [2015-01-29 Thu] lcpan:
* TODO [2015-01-22 Thu] lcpan: write plugin: rank authors by number of dists
* TODO [2015-01-22 Thu] lcpan: write plugin: rank authors by number of modules
* TODO [2015-01-22 Thu] lcpan: write plugin: rank authors by number of releases
* TODO [2015-01-22 Thu] lcpan: write plugin: rank authors by number of other authors prereqs-ing his modules
* TODO [2015-01-22 Thu] lcpan: write plugin: rank authors by ...?
* TODO [2015-01-22 Thu] lcpan: write plugin: rank modules by number of reverse deps
* TODO [2015-01-22 Thu] lcpan: write plugin: rank dists by number of deps (heaviest dists)
* TODO [2015-01-17 Sat] lcpan, pericmd: --cpan should really be a "common" arg

  - in the doc they should belong to common options instead of being repeated for
    every subcommand.
  - as well as in --help message.
  - this is perhaps just an issue of peris2clidocdata. perhaps add tag :common to
    this arg?

* TODO [2015-01-16 Jum] lcpan: plugin system

  subcommand names need to be expressed in module name, so we never have to load
  them first (remember how slow dzil is), e.g.:
  

      App::lcpan::Cmd::foo
      App::lcpan::Cmd::FooBar -> turns into foo-bar? or ::foo_bar?
  
  i tend to the later because the first one will have trouble with uniqueness
  later, e.g. fooBar
  
  inside the module, there's handle_subcommand() so the main app can later add
  them to pericmd-lite via:
  

      $subcommands{"foo-bar"} = {url=>"/App/lcpan/Cmd/foo_bar"};
  
  Cmds to write:
  
  - rdeps-by-others SHARYANTO
  - rdeps-by-others SHARYANTO PERLANCAR; # dists that need these modules published
    by these guys but not by these guys
  
  hooks, e.g. plugin to support
  
  configuration can regulate which plugins are disabled, or only activate certain
  plugins only. the default is to include all plugins, but if there is:
  

      include_plugin=["Cmd::foo_bar", "Cmd::baz", "Cmd::a*"]
  
  then only include those plugins. or if there is only:
  

      exclude_plugin=["Plugin::MakefilePL"]
  
  then by default load all plugins but exclude those.

* TODO [2015-01-15 Thu] lcpan: write cli queries shown in More Example Queries in bin/lcpan

  - log ::
    + [2015-01-17 Sab] i'll write them as plugins instead

* IDEA [2015-01-15 Thu] lcpan: subcommands modinfo, distinfo, authorinfo

  - not really sure yet though what information to put there (aside from those
    that already in modules --detail, dists --detail, authors --detail).

* TODO [2015-01-15 Thu] _cpanm, lcpan: need to refactor the way one uses Perinci::CmdLine::Util::Config

  - it's currently ugly

* TODO [2015-01-13 Tue] lcpan: implement stats --verbose

  - disk_space

* TODO [2015-01-13 Tue] lcpan: offer some choices of minicpan updating

  - default, -c CPAN::Mini::LatestDistVersion, CPAN::Mini::Devel,
    CPAN::Mini::Devel::Recent, with patch
    -MLWP::UserAgent::Patch::FilterMirrorMaxSize=-size,X,-verbose,1,
    CPAN::Mini::Tested,
  - CPAN::Mini::FromList?
  - but not CPAN::Mini::Extract
