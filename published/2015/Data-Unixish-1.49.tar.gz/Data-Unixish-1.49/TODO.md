* TODO [2015-01-03 Sat] dux: randstr: More choices in character sets: full ASCII, Unicode, etc.
* TODO [2015-01-03 Sat] dux: randstr: Allow users to specify their own charset.
* TODO [2014-04-20 Sun] dux: tweak: in -h, exclude --in and --out

  - perlu module peridocutil dulu, extract functionality ke sana.
* TODO [2014-04-20 Sun] dux: fungsi utk tabify dan untabify

  - ada opsi utk specify offset
  - ada opsi utk just replace tab with a number of spaces
  - log:
    + [2014-04-28 Mon] btw, untuk apa ya?
