* BUG [2015-04-05 Sun] pericmd-classic: can't run filter-org-by-headlines (through list-dist-todos), but ok if using pericmd-lite

  weird error message:
  

      Unrecognized escape \Q passed through in regex; marked by <-- HERE in m//(\Q <-- HERE Log-Any-IfLOG\E|\Qla-iflog\E)(, \S+)*:// at (eval 237) line 158, <> line 1.
      Unrecognized escape \E passed through in regex; marked by <-- HERE in m//(\QLog-Any-IfLOG\E <-- HERE |\Qla-iflog\E)(, \S+)*:// at (eval 237) line 158, <> line 1.
      Unrecognized escape \Q passed through in regex; marked by <-- HERE in m//(\QLog-Any-IfLOG\E|\Q <-- HERE la-iflog\E)(, \S+)*:// at (eval 237) line 158, <> line 1.
      Unrecognized escape \E passed through in regex; marked by <-- HERE in m//(\QLog-Any-IfLOG\E|\Qla-iflog\E <-- HERE )(, \S+)*:// at (eval 237) line 158, <> line 1.

* TODO [2015-03-26 Thu] pericmd-classic: what if we want to customize cleanser?

  example is in parse-ledger, where we want to customize cleanser with: -circular
  => [clone=>0]. in pericmd-lite 1.01 this is already possible because we expose
  'cleanser' as attribute. but pericmd-classic uses perirf to format result.
  
  so dfpj should perhaps observe some environment variable to configure dc-json.

* TODO [2015-03-11 Wed] pericmd-classic, pericmd-lite: put base classes' {attributes, methods} POD to our POD, using DZP:InsertBlock
* TODO [2015-02-25 Wed] pericmd-classic, pericmd-lite: show summary in help and 'cmd --subcommands'

  - summary from subcommand spec should be shown [done]
  - summary from function meta should also be shown if url is local

* TODO [2014-12-03 Wed] [#C] pericmd-classic: --help: underline entity in --opt=entity

  - di pericmd-lite agak ribet karena color codes membuat alignment string agak
    ribet dan harus pake Text::ANSI::Util dsb, skip aja dulu di pericmd-lite.
