* TODO [2015-01-13 Tue] lcpan: stats: last update

  - just get mtime of 02packages.details.txt.gz, convert it to ISO8601 date

* TODO [2015-01-13 Tue] lcpan: implement stats --verbose

  - disk_space

* TODO [2015-01-13 Tue] lcpan: offer some choices of minicpan updating

  - default, -c CPAN::Mini::LatestDistVersion, CPAN::Mini::Devel,
    CPAN::Mini::Devel::Recent, with patch
    -MLWP::UserAgent::Patch::FilterMirrorMaxSize=-size,X,-verbose,1,
    CPAN::Mini::Tested,
  - CPAN::Mini::FromList?
  - but not CPAN::Mini::Extract
