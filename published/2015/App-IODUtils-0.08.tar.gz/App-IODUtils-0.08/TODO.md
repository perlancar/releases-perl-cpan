* TODO [2015-03-18 Wed] iodutils: add script: insert-iod-section
* TODO [2015-03-18 Wed] iodutils: add script: delete-iod-key
* TODO [2015-03-18 Wed] iodutils: add script: delete-iod-section
* TODO [2015-03-18 Wed] iodutils: option to do file locking when modifying file
