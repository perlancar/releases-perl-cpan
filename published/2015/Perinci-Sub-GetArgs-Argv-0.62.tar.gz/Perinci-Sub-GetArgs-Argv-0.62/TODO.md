* TODO [2015-02-07 Sab] periga-argv, pericmd: should 'deps' and 'args_groups' checking be done (only) in periga-argv, or (also) in pericmd after cmdline_src handling?
* TODO [2015-02-07 Sab] periga-argv: implement checking for arg spec property 'deps'
* TODO [2015-02-07 Sab] periga-argv: implement checking for func property 'args_groups'
* TODO [2015-01-03 Sat] periga-argv: Option to enable json/yaml for nullable simple scalar (to enable C<--str-json '~'>).
* IDEA [2014-11-01 Sat] ri, periga-argv, pericmd: suppress accepting --foo-json/--foo-yaml even though arg is array etc

  contoh, gw ingin accept file sebagai --file F1 --file F2 saja, gak mau user bisa
  --file-json '["F1","F2"]'. terutama utk array of simple scalar, gw hanya ingin
  itu.
  
  tentu saja kita bisa matikan per_arg_json, per_arg_yaml. mungkin perlu ada
  per-arg optionnya. dan belum ada cara utk specify ini dari pericmd.
