* TODO [2015-01-03 Sat] ioprompt-i18n: Option to stty off (e.g. when prompting password).
* TODO [2015-01-03 Sat] ioprompt-i18n: Validation using coderef

  Probably with a C<validation> key which can be regex or coderef, and then
  deprecate C<regex>).
* TODO [2015-01-03 Sat] ioprompt-i18n: Timeout, like L<Prompt::Timeout>.
