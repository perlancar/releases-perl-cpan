* TODO [2015-01-22 Thu] http-tiny-progany, lwp-ua-progany: refactor: combine common code to avoid duplication
