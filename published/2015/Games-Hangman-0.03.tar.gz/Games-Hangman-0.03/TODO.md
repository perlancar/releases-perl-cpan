* TODO [2015-01-03 Sat] games-hangman: Record and save high scores
* TODO [2015-01-03 Sat] games-hangman: Add some animation
