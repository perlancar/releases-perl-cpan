* BUG [2015-03-30 Mon] compbash: completion works under testcomp but not under pericmd directly if argument contains ~

  e.g. 'testcomp list-org-todos ~/o/todos.org --has-tags ^' works, but trying it
  under bash directly: 'list-org-todos ~/o/todos.org --has-tags <tab>' doesn't
  work. this probably has got to do with the way COMP_LINE and COMP_POINT is
  passed by bash.
  
  UPDATE: yup, i was right. bash passes COMP_LINE and COMP_POINT before expanding
  things like $HOME and ~/. which means we'll have to do this ourselves (in
  compbash).

* TODO [2014-12-03 Wed] compbash, compbashhist: C version of parse_cmdline n parse_options because they have to be called thousands of time in compbashhist for each tab completion! [#C]
* IDEA [2014-12-19 Jum] compbash: how to emulate description entries on bash?
* IDEA [2015-01-03 Sat] compbash: format_completion(): Accept regex for path_sep?

  - currently there is no real need for this though.
