* TODO [2015-01-03 Sat] dzp-ri-validate: Support argument's submetadata and argument element's submetadata
* TODO [2015-01-03 Sat] dzp-ri-validate: Use L<PPI> instead of fragile regex.
* TODO [2015-01-03 Sat] dzp-ri-validate: Option to not compress validator code to a single line.
* TODO [2015-01-03 Sat] dzp-ri-validate: Option to configure variable name to store validation (C<$arg_err>).
* TODO [2015-01-03 Sat] dzp-ri-validate: Option to reuse code for the same schema.
