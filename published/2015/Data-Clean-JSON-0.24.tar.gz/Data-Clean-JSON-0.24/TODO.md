* IDEA [2013-07-26 Fri] dc-json: integrate clone_circular_refs

  - sempet mo nyoba dengan dimasukin inline, tapi agak ribet. coba aja nanti
    langsung manggil SHARYANTO::Data::Util::clone_circular_refs().
