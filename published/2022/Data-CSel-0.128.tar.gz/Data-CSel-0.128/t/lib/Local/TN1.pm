package # hide from PAUSE
    Local::TN1;

use parent 'Local::TN';

1;
