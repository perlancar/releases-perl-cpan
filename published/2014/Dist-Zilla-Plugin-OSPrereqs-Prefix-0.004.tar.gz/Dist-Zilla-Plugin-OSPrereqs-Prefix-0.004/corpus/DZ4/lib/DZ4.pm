use strict;
use warnings;
package DZ4;
# ABSTRACT: this is a sample package for testing Dist::Zilla;

sub main {
  return 1;
}

1;
