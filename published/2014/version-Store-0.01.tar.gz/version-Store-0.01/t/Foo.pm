package Foo;
use version::Store;
our $VERSION = 0.12;
#our %USER_PACKAGES;

1;
