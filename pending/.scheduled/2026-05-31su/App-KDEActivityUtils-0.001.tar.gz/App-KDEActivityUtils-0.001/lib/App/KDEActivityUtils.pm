package App::KDEActivityUtils;

use 5.010001;
use strict 'subs', 'vars';
use warnings;
use Log::ger;

use Exporter qw(import);
use IPC::System::Options 'system', -log=>1;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2026-03-26'; # DATE
our $DIST = 'App-KDEActivityUtils'; # DIST
our $VERSION = '0.001'; # VERSION

our @EXPORT_OK = qw(
                       set_current_kde_activity
                       list_kde_activities
               );

our %SPEC;

$SPEC{':package'} = {
    v => 1.1,
    summary => 'Utilities related to KDE Activities',
};

$SPEC{list_kde_activities} = {
    v => 1.1,
    summary => "List all known KDE activities",
    args => {
        detail => {
            schema => 'bool*',
            cmdline_aliases => {l=>{}},
        },
    },
    deps => {
        prog => 'kactivities-cli',
    },
};
sub list_kde_activities {
    my %args = @_;

    system({capture_stdout => \my $stdout}, "kactivities-cli", "--list-activities");
    return [500, "Can't run kactivities-cli"] if $?;
    my @rows;

    for my $line (split /^/m, $stdout) {
        my ($status, $guid, $name, $icon) = $line =~ /^\[(.+?)\] ([0-9a-f-]+) (.+?) \((.*?)\)/;
        push @rows, {
            is_running => ($status =~ /RUNNING|CURRENT/ ? 1:0),
            is_current => ($status =~ /CURRENT/ ? 1:0),
            guid => $guid,
            name => $name,
            icon => $icon,
        };
    }

    unless ($args{detail}) {
        @rows = map { $_->{name} } @rows;
    }

    return [200, "OK", \@rows];
}

my $_comp_kde_activity_name = sub {
    require Complete::Util;

    my %args = @_;
    my $word = $args{word};

    my $res = list_kde_activities(detail => 1);
    return unless $res->[0] == 200;

    Complete::Util::complete_array_elem(word => $word, array=>[ map { $_->{name} } @{$res->[2] }]);
};

sub _push_activity_stack {
    require IPC::ShareLite;
    require List::Util::Uniq;

    my $name = shift;

    my $share = IPC::ShareLite->new(
        -key     => 6001,
        -create  => 'yes',
        -destroy => 'no',
    );
    my @stack = split /\|/, ($share->fetch // '');
    unshift @stack, $name;
    @stack = List::Util::Uniq::uniq_adj(@stack);
    $share->store(join "|", @stack);
}

sub _get_activity_stack {
    my $name = shift;

    require IPC::ShareLite;
    my $share = IPC::ShareLite->new(
        -key     => 6001,
        -create  => 'yes',
        -destroy => 'no',
    );
    split /\|/, ($share->fetch // '');
}

$SPEC{set_current_kde_activity} = {
    v => 1.1,
    summary => 'Set KDE current activity',
    description => <<'MARKDOWN',

Features:
- Specifying activity by name (kactivities-cli wants GUID)
- Tab completion

MARKDOWN
    args => {
        name => {
            schema => 'str*',
            req => 1,
            pos => 0,
            completion => $_comp_kde_activity_name,
        },
        # TODO: guid as alternative way to specify the activity
    },
    deps => {
        prog => 'qdbus',
    },
};
sub set_current_kde_activity {
    my %args = @_;
    defined(my $name = $args{name}) or return [400, "Please specify name"];

    my $res = list_kde_activities(detail => 1);
    return $res unless $res->[0] == 200;

    my $guid;
    for my $row (@{ $res->[2] }) {
        do { $guid = $row->{guid}; last } if $row->{name} eq $name;
    }
    return [404, "Cannot find activity named '$name'"] unless $guid;

    system({capture_stdout => \my $dummy}, "qdbus", "org.kde.ActivityManager", "/ActivityManager/Activities", "SetCurrentActivity", $guid);
    return [500, "Can't run qdbus"] if $?;

    _push_activity_stack($name);
    [200];
}

$SPEC{return_to_previously_set_kde_activity} = {
    v => 1.1,
    summary => 'Return to previously set KDE activity',
    description => <<'MARKDOWN',

MARKDOWN
    args => {
        num => {
            schema => 'uint*',
            default => 1,
            pos => 0,
        },
    },
};
sub return_to_previously_set_kde_activity {
    my %args = @_;
    my $num = $args{num} // 1;

    my @stack = _get_activity_stack();
    return [304] if $num >= @stack;

    set_current_kde_activity(name => $stack[$num]);
}

$SPEC{list_kde_activities_stack} = {
    v => 1.1,
    summary => 'List KDE activities in the order of set()',
    description => <<'MARKDOWN',

MARKDOWN
    args => {
    },
};
sub list_kde_activities_stack {
    [200, "OK", [ _get_activity_stack()]];
}

1;
# ABSTRACT: Utilities related to KDE Activities

__END__

=pod

=encoding UTF-8

=head1 NAME

App::KDEActivityUtils - Utilities related to KDE Activities

=head1 VERSION

This document describes version 0.001 of App::KDEActivityUtils (from Perl distribution App-KDEActivityUtils), released on 2026-03-26.

=head1 SYNOPSIS

=head1 DESCRIPTION

This distribution includes several utilities related to KDE activities as
alternatives/wrappers to L<kactivities-cli>:

=over

=item * L<list-kde-activities>

=item * L<list-kde-activities-stack>

=item * L<return-to-previously-set-kde-activity>

=item * L<set-current-kde-activity>

=back

=head1 FUNCTIONS


=head2 list_kde_activities

Usage:

 list_kde_activities(%args) -> [$status_code, $reason, $payload, \%result_meta]

List all known KDE activities.

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<detail> => I<bool>

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 list_kde_activities_stack

Usage:

 list_kde_activities_stack() -> [$status_code, $reason, $payload, \%result_meta]

List KDE activities in the order of set().

This function is not exported.

No arguments.

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 return_to_previously_set_kde_activity

Usage:

 return_to_previously_set_kde_activity(%args) -> [$status_code, $reason, $payload, \%result_meta]

Return to previously set KDE activity.

This function is not exported.

Arguments ('*' denotes required arguments):

=over 4

=item * B<num> => I<uint> (default: 1)

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 set_current_kde_activity

Usage:

 set_current_kde_activity(%args) -> [$status_code, $reason, $payload, \%result_meta]

Set KDE current activity.

Features:
- Specifying activity by name (kactivities-cli wants GUID)
- Tab completion

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<name>* => I<str>

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/App-KDEActivityUtils>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-App-KDEActivityUtils>.

=head1 SEE ALSO

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2026 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=App-KDEActivityUtils>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
